﻿/*
  Copyright (c) 2011+, HL7, Inc.
  All rights reserved.
  
  Redistribution and use in source and binary forms, with or without modification, 
  are permitted provided that the following conditions are met:
  
   * Redistributions of source code must retain the above copyright notice, this 
     list of conditions and the following disclaimer.
   * Redistributions in binary form must reproduce the above copyright notice, 
     this list of conditions and the following disclaimer in the documentation 
     and/or other materials provided with the distribution.
   * Neither the name of HL7 nor the names of its contributors may be used to 
     endorse or promote products derived from this software without specific 
     prior written permission.
  
  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND 
  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
  WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
  IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
  INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT 
  NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR 
  PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
  WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
  POSSIBILITY OF SUCH DAMAGE.
  

 * Generated on Tue, Dec 30, 2014 10:55+0000 for FHIR v0.4.0
 */
/*
 * A clinical assessment performed when planning treatments and management strategies for a patient
 *
 * [FhirReference("ClinicalAssessment")]
 * [Serializable]
 */

#import "FHIRDomainResource.h"


@class FHIRReference;
@class FHIRDateTime;
@class FHIRString;
@class FHIRClinicalAssessmentInvestigationsComponent;
@class FHIRUri;
@class FHIRClinicalAssessmentDiagnosisComponent;
@class FHIRCodeableConcept;
@class FHIRClinicalAssessmentRuledOutComponent;

@interface FHIRClinicalAssessment : FHIRDomainResource

/*
 * The patient being asssesed
 */
@property (nonatomic, strong) FHIRReference *patient;

/*
 * The clinicial performing the assessment
 */
@property (nonatomic, strong) FHIRReference *assessor;

/*
 * When the assessment occurred
 */
@property (nonatomic, strong) FHIRDateTime *dateElement;

@property (nonatomic, strong) NSString *date;

/*
 * Why/how the assessment was performed
 */
@property (nonatomic, strong) FHIRString *descriptionElement;

@property (nonatomic, strong) NSString *description;

/*
 * Reference to last assessment
 */
@property (nonatomic, strong) FHIRReference *previous;

/*
 * General assessment of patient state
 */
@property (nonatomic, strong) NSArray/*<Reference>*/ *problem;

/*
 * A specific careplan that prompted this assessment
 */
@property (nonatomic, strong) FHIRReference *careplan;

/*
 * A specific referral that lead to this assessment
 */
@property (nonatomic, strong) FHIRReference *referral;

/*
 * One or more sets of investigations (signs, symptions, etc)
 */
@property (nonatomic, strong) NSArray/*<ClinicalAssessmentInvestigationsComponent>*/ *investigations;

/*
 * Clinical Protocol followed
 */
@property (nonatomic, strong) FHIRUri *protocolElement;

@property (nonatomic, strong) NSString *protocol;

/*
 * Summary of the assessment
 */
@property (nonatomic, strong) FHIRString *summaryElement;

@property (nonatomic, strong) NSString *summary;

/*
 * Possible or likely diagnosis
 */
@property (nonatomic, strong) NSArray/*<ClinicalAssessmentDiagnosisComponent>*/ *diagnosis;

/*
 * Diagnosies/conditions resolved since previous assessment
 */
@property (nonatomic, strong) NSArray/*<CodeableConcept>*/ *resolved;

/*
 * Diagnosis considered not possible
 */
@property (nonatomic, strong) NSArray/*<ClinicalAssessmentRuledOutComponent>*/ *ruledOut;

/*
 * Estimate of likely outcome
 */
@property (nonatomic, strong) FHIRString *prognosisElement;

@property (nonatomic, strong) NSString *prognosis;

/*
 * Plan of action after assessment
 */
@property (nonatomic, strong) FHIRReference *plan;

/*
 * Actions taken during assessment
 */
@property (nonatomic, strong) NSArray/*<Reference>*/ *action;

- (FHIRErrorList *)validate;

@end
