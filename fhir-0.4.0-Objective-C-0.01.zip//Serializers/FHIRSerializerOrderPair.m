﻿/*
  Copyright (c) 2011+, HL7, Inc.
  All rights reserved.
  
  Redistribution and use in source and binary forms, with or without modification, 
  are permitted provided that the following conditions are met:
  
   * Redistributions of source code must retain the above copyright notice, this 
     list of conditions and the following disclaimer.
   * Redistributions in binary form must reproduce the above copyright notice, 
     this list of conditions and the following disclaimer in the documentation 
     and/or other materials provided with the distribution.
   * Neither the name of HL7 nor the names of its contributors may be used to 
     endorse or promote products derived from this software without specific 
     prior written permission.
  
  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND 
  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
  WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
  IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
  INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT 
  NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR 
  PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
  WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
  POSSIBILITY OF SUCH DAMAGE.
  

 * Generated on Tue, Dec 30, 2014 10:55+0000 for FHIR v0.4.0
 */

/*
 * Order of dictionaries
 */

#import "FHIRSerializerOrderPair.h"

@interface FHIRSerializerOrderPair()

+ (NSArray *)orderPairArrayForFHIRAddress;
+ (NSArray *)orderPairArrayForFHIRAttachment;
+ (NSArray *)orderPairArrayForFHIRBackboneElement;
+ (NSArray *)orderPairArrayForFHIRCodeableConcept;
+ (NSArray *)orderPairArrayForFHIRCoding;
+ (NSArray *)orderPairArrayForFHIRContactPoint;
+ (NSArray *)orderPairArrayForFHIRElement;
+ (NSArray *)orderPairArrayForFHIRElementDefinition;
+ (NSArray *)orderPairArrayForFHIRElementDefinitionSlicingComponent;
+ (NSArray *)orderPairArrayForFHIRTypeRefComponent;
+ (NSArray *)orderPairArrayForFHIRElementDefinitionMappingComponent;
+ (NSArray *)orderPairArrayForFHIRElementDefinitionBindingComponent;
+ (NSArray *)orderPairArrayForFHIRElementDefinitionConstraintComponent;
+ (NSArray *)orderPairArrayForFHIRExtension;
+ (NSArray *)orderPairArrayForFHIRHumanName;
+ (NSArray *)orderPairArrayForFHIRIdentifier;
+ (NSArray *)orderPairArrayForFHIRNarrative;
+ (NSArray *)orderPairArrayForFHIRPeriod;
+ (NSArray *)orderPairArrayForFHIRQuantity;
+ (NSArray *)orderPairArrayForFHIRRange;
+ (NSArray *)orderPairArrayForFHIRRatio;
+ (NSArray *)orderPairArrayForFHIRReference;
+ (NSArray *)orderPairArrayForFHIRSampledData;
+ (NSArray *)orderPairArrayForFHIRTiming;
+ (NSArray *)orderPairArrayForFHIRTimingRepeatComponent;
+ (NSArray *)orderPairArrayForFHIRBase64Binary;
+ (NSArray *)orderPairArrayForFHIRBoolean;
+ (NSArray *)orderPairArrayForFHIRCode;
+ (NSArray *)orderPairArrayForFHIRDate;
+ (NSArray *)orderPairArrayForFHIRDateTime;
+ (NSArray *)orderPairArrayForFHIRDecimal;
+ (NSArray *)orderPairArrayForFHIRId;
+ (NSArray *)orderPairArrayForFHIRInstant;
+ (NSArray *)orderPairArrayForFHIRInteger;
+ (NSArray *)orderPairArrayForFHIROid;
+ (NSArray *)orderPairArrayForFHIRString;
+ (NSArray *)orderPairArrayForFHIRTime;
+ (NSArray *)orderPairArrayForFHIRUri;
+ (NSArray *)orderPairArrayForFHIRUuid;
+ (NSArray *)orderPairArrayForFHIRXhtml;
+ (NSArray *)orderPairArrayForFHIRDomainResource;
+ (NSArray *)orderPairArrayForFHIRParameters;
+ (NSArray *)orderPairArrayForFHIRParametersParameterComponent;
+ (NSArray *)orderPairArrayForFHIRParametersParameterPartComponent;
+ (NSArray *)orderPairArrayForFHIRBaseResource;
+ (NSArray *)orderPairArrayForFHIRResourceMetaComponent;
+ (NSArray *)orderPairArrayForFHIRAlert;
+ (NSArray *)orderPairArrayForFHIRAllergyIntolerance;
+ (NSArray *)orderPairArrayForFHIRAllergyIntoleranceEventComponent;
+ (NSArray *)orderPairArrayForFHIRAppointment;
+ (NSArray *)orderPairArrayForFHIRAppointmentParticipantComponent;
+ (NSArray *)orderPairArrayForFHIRAppointmentResponse;
+ (NSArray *)orderPairArrayForFHIRBasic;
+ (NSArray *)orderPairArrayForFHIRBinary;
+ (NSArray *)orderPairArrayForFHIRBundle;
+ (NSArray *)orderPairArrayForFHIRBundleEntryDeletedComponent;
+ (NSArray *)orderPairArrayForFHIRBundleEntryComponent;
+ (NSArray *)orderPairArrayForFHIRBundleLinkComponent;
+ (NSArray *)orderPairArrayForFHIRCarePlan;
+ (NSArray *)orderPairArrayForFHIRCarePlanGoalComponent;
+ (NSArray *)orderPairArrayForFHIRCarePlanParticipantComponent;
+ (NSArray *)orderPairArrayForFHIRCarePlanActivityComponent;
+ (NSArray *)orderPairArrayForFHIRCarePlanActivitySimpleComponent;
+ (NSArray *)orderPairArrayForFHIRCarePlan2;
+ (NSArray *)orderPairArrayForFHIRCarePlan2ParticipantComponent;
+ (NSArray *)orderPairArrayForFHIRClaimResponse;
+ (NSArray *)orderPairArrayForFHIRNotesComponent;
+ (NSArray *)orderPairArrayForFHIRItemsComponent;
+ (NSArray *)orderPairArrayForFHIRItemSubdetailComponent;
+ (NSArray *)orderPairArrayForFHIRAddedItemDetailAdjudicationComponent;
+ (NSArray *)orderPairArrayForFHIRAddedItemAdjudicationComponent;
+ (NSArray *)orderPairArrayForFHIRDetailAdjudicationComponent;
+ (NSArray *)orderPairArrayForFHIRErrorsComponent;
+ (NSArray *)orderPairArrayForFHIRAddedItemComponent;
+ (NSArray *)orderPairArrayForFHIRItemAdjudicationComponent;
+ (NSArray *)orderPairArrayForFHIRAddedItemsDetailComponent;
+ (NSArray *)orderPairArrayForFHIRSubdetailAdjudicationComponent;
+ (NSArray *)orderPairArrayForFHIRItemDetailComponent;
+ (NSArray *)orderPairArrayForFHIRClinicalAssessment;
+ (NSArray *)orderPairArrayForFHIRClinicalAssessmentRuledOutComponent;
+ (NSArray *)orderPairArrayForFHIRClinicalAssessmentInvestigationsComponent;
+ (NSArray *)orderPairArrayForFHIRClinicalAssessmentDiagnosisComponent;
+ (NSArray *)orderPairArrayForFHIRCommunication;
+ (NSArray *)orderPairArrayForFHIRCommunicationPayloadComponent;
+ (NSArray *)orderPairArrayForFHIRCommunicationRequest;
+ (NSArray *)orderPairArrayForFHIRCommunicationRequestPayloadComponent;
+ (NSArray *)orderPairArrayForFHIRComposition;
+ (NSArray *)orderPairArrayForFHIRSectionComponent;
+ (NSArray *)orderPairArrayForFHIRCompositionEventComponent;
+ (NSArray *)orderPairArrayForFHIRCompositionAttesterComponent;
+ (NSArray *)orderPairArrayForFHIRConceptMap;
+ (NSArray *)orderPairArrayForFHIRConceptMapElementComponent;
+ (NSArray *)orderPairArrayForFHIRConceptMapElementMapComponent;
+ (NSArray *)orderPairArrayForFHIROtherElementComponent;
+ (NSArray *)orderPairArrayForFHIRCondition;
+ (NSArray *)orderPairArrayForFHIRConditionEvidenceComponent;
+ (NSArray *)orderPairArrayForFHIRConditionDueToComponent;
+ (NSArray *)orderPairArrayForFHIRConditionOccurredFollowingComponent;
+ (NSArray *)orderPairArrayForFHIRConditionStageComponent;
+ (NSArray *)orderPairArrayForFHIRConditionLocationComponent;
+ (NSArray *)orderPairArrayForFHIRConformance;
+ (NSArray *)orderPairArrayForFHIRConformanceRestComponent;
+ (NSArray *)orderPairArrayForFHIRConformanceSoftwareComponent;
+ (NSArray *)orderPairArrayForFHIRConformanceMessagingComponent;
+ (NSArray *)orderPairArrayForFHIRConformanceDocumentComponent;
+ (NSArray *)orderPairArrayForFHIRConformanceRestResourceComponent;
+ (NSArray *)orderPairArrayForFHIRConformanceImplementationComponent;
+ (NSArray *)orderPairArrayForFHIRConformanceMessagingEventComponent;
+ (NSArray *)orderPairArrayForFHIRSystemInteractionComponent;
+ (NSArray *)orderPairArrayForFHIRResourceInteractionComponent;
+ (NSArray *)orderPairArrayForFHIRConformanceRestSecurityComponent;
+ (NSArray *)orderPairArrayForFHIRConformanceRestSecurityCertificateComponent;
+ (NSArray *)orderPairArrayForFHIRConformanceRestOperationComponent;
+ (NSArray *)orderPairArrayForFHIRConformanceRestResourceSearchParamComponent;
+ (NSArray *)orderPairArrayForFHIRContract;
+ (NSArray *)orderPairArrayForFHIRContractSignerComponent;
+ (NSArray *)orderPairArrayForFHIRContractTermComponent;
+ (NSArray *)orderPairArrayForFHIRContraindication;
+ (NSArray *)orderPairArrayForFHIRContraindicationMitigationComponent;
+ (NSArray *)orderPairArrayForFHIRCoverage;
+ (NSArray *)orderPairArrayForFHIRDataElement;
+ (NSArray *)orderPairArrayForFHIRDataElementMappingComponent;
+ (NSArray *)orderPairArrayForFHIRDataElementBindingComponent;
+ (NSArray *)orderPairArrayForFHIRDevice;
+ (NSArray *)orderPairArrayForFHIRDeviceComponent;
+ (NSArray *)orderPairArrayForFHIRDeviceComponentProductionSpecificationComponent;
+ (NSArray *)orderPairArrayForFHIRDeviceMetric;
+ (NSArray *)orderPairArrayForFHIRDeviceMetricCalibrationInfoComponent;
+ (NSArray *)orderPairArrayForFHIRDeviceUseRequest;
+ (NSArray *)orderPairArrayForFHIRDeviceUseStatement;
+ (NSArray *)orderPairArrayForFHIRDiagnosticOrder;
+ (NSArray *)orderPairArrayForFHIRDiagnosticOrderItemComponent;
+ (NSArray *)orderPairArrayForFHIRDiagnosticOrderEventComponent;
+ (NSArray *)orderPairArrayForFHIRDiagnosticReport;
+ (NSArray *)orderPairArrayForFHIRDiagnosticReportImageComponent;
+ (NSArray *)orderPairArrayForFHIRDocumentManifest;
+ (NSArray *)orderPairArrayForFHIRDocumentReference;
+ (NSArray *)orderPairArrayForFHIRDocumentReferenceContextComponent;
+ (NSArray *)orderPairArrayForFHIRDocumentReferenceRelatesToComponent;
+ (NSArray *)orderPairArrayForFHIRDocumentReferenceServiceParameterComponent;
+ (NSArray *)orderPairArrayForFHIRDocumentReferenceServiceComponent;
+ (NSArray *)orderPairArrayForFHIREligibilityRequest;
+ (NSArray *)orderPairArrayForFHIREligibilityResponse;
+ (NSArray *)orderPairArrayForFHIREncounter;
+ (NSArray *)orderPairArrayForFHIREncounterHospitalizationComponent;
+ (NSArray *)orderPairArrayForFHIREncounterStatusHistoryComponent;
+ (NSArray *)orderPairArrayForFHIREncounterLocationComponent;
+ (NSArray *)orderPairArrayForFHIREncounterParticipantComponent;
+ (NSArray *)orderPairArrayForFHIREnrollmentRequest;
+ (NSArray *)orderPairArrayForFHIREnrollmentResponse;
+ (NSArray *)orderPairArrayForFHIREpisodeOfCare;
+ (NSArray *)orderPairArrayForFHIREpisodeOfCareStatusHistoryComponent;
+ (NSArray *)orderPairArrayForFHIREpisodeOfCareCareTeamComponent;
+ (NSArray *)orderPairArrayForFHIRExplanationOfBenefit;
+ (NSArray *)orderPairArrayForFHIRExtensionDefinition;
+ (NSArray *)orderPairArrayForFHIRExtensionDefinitionMappingComponent;
+ (NSArray *)orderPairArrayForFHIRFamilyHistory;
+ (NSArray *)orderPairArrayForFHIRFamilyHistoryRelationConditionComponent;
+ (NSArray *)orderPairArrayForFHIRFamilyHistoryRelationComponent;
+ (NSArray *)orderPairArrayForFHIRGoal;
+ (NSArray *)orderPairArrayForFHIRGroup;
+ (NSArray *)orderPairArrayForFHIRGroupCharacteristicComponent;
+ (NSArray *)orderPairArrayForFHIRHealthcareService;
+ (NSArray *)orderPairArrayForFHIRServiceTypeComponent;
+ (NSArray *)orderPairArrayForFHIRHealthcareServiceAvailableTimeComponent;
+ (NSArray *)orderPairArrayForFHIRHealthcareServiceNotAvailableTimeComponent;
+ (NSArray *)orderPairArrayForFHIRImagingObjectSelection;
+ (NSArray *)orderPairArrayForFHIRStudyComponent;
+ (NSArray *)orderPairArrayForFHIRInstanceComponent;
+ (NSArray *)orderPairArrayForFHIRSeriesComponent;
+ (NSArray *)orderPairArrayForFHIRImagingStudy;
+ (NSArray *)orderPairArrayForFHIRImagingStudySeriesComponent;
+ (NSArray *)orderPairArrayForFHIRImagingStudySeriesInstanceComponent;
+ (NSArray *)orderPairArrayForFHIRImmunization;
+ (NSArray *)orderPairArrayForFHIRImmunizationVaccinationProtocolComponent;
+ (NSArray *)orderPairArrayForFHIRImmunizationExplanationComponent;
+ (NSArray *)orderPairArrayForFHIRImmunizationReactionComponent;
+ (NSArray *)orderPairArrayForFHIRImmunizationRecommendation;
+ (NSArray *)orderPairArrayForFHIRImmunizationRecommendationRecommendationDateCriterionComponent;
+ (NSArray *)orderPairArrayForFHIRImmunizationRecommendationRecommendationProtocolComponent;
+ (NSArray *)orderPairArrayForFHIRImmunizationRecommendationRecommendationComponent;
+ (NSArray *)orderPairArrayForFHIRInstitutionalClaim;
+ (NSArray *)orderPairArrayForFHIRItemsComponent;
+ (NSArray *)orderPairArrayForFHIRDetailComponent;
+ (NSArray *)orderPairArrayForFHIRCoverageComponent;
+ (NSArray *)orderPairArrayForFHIRPayeeComponent;
+ (NSArray *)orderPairArrayForFHIRDiagnosisComponent;
+ (NSArray *)orderPairArrayForFHIRSubDetailComponent;
+ (NSArray *)orderPairArrayForFHIRList;
+ (NSArray *)orderPairArrayForFHIRListEntryComponent;
+ (NSArray *)orderPairArrayForFHIRLocation;
+ (NSArray *)orderPairArrayForFHIRLocationPositionComponent;
+ (NSArray *)orderPairArrayForFHIRMedia;
+ (NSArray *)orderPairArrayForFHIRMedication;
+ (NSArray *)orderPairArrayForFHIRMedicationPackageContentComponent;
+ (NSArray *)orderPairArrayForFHIRMedicationPackageComponent;
+ (NSArray *)orderPairArrayForFHIRMedicationProductIngredientComponent;
+ (NSArray *)orderPairArrayForFHIRMedicationProductComponent;
+ (NSArray *)orderPairArrayForFHIRMedicationAdministration;
+ (NSArray *)orderPairArrayForFHIRMedicationAdministrationDosageComponent;
+ (NSArray *)orderPairArrayForFHIRMedicationDispense;
+ (NSArray *)orderPairArrayForFHIRMedicationDispenseDispenseDosageComponent;
+ (NSArray *)orderPairArrayForFHIRMedicationDispenseSubstitutionComponent;
+ (NSArray *)orderPairArrayForFHIRMedicationDispenseDispenseComponent;
+ (NSArray *)orderPairArrayForFHIRMedicationPrescription;
+ (NSArray *)orderPairArrayForFHIRMedicationPrescriptionDosageInstructionComponent;
+ (NSArray *)orderPairArrayForFHIRMedicationPrescriptionSubstitutionComponent;
+ (NSArray *)orderPairArrayForFHIRMedicationPrescriptionDispenseComponent;
+ (NSArray *)orderPairArrayForFHIRMedicationStatement;
+ (NSArray *)orderPairArrayForFHIRMedicationStatementDosageComponent;
+ (NSArray *)orderPairArrayForFHIRMessageHeader;
+ (NSArray *)orderPairArrayForFHIRMessageDestinationComponent;
+ (NSArray *)orderPairArrayForFHIRMessageSourceComponent;
+ (NSArray *)orderPairArrayForFHIRMessageHeaderResponseComponent;
+ (NSArray *)orderPairArrayForFHIRNamingSystem;
+ (NSArray *)orderPairArrayForFHIRNamingSystemContactComponent;
+ (NSArray *)orderPairArrayForFHIRNamingSystemUniqueIdComponent;
+ (NSArray *)orderPairArrayForFHIRNutritionOrder;
+ (NSArray *)orderPairArrayForFHIRNutritionOrderItemSupplementComponent;
+ (NSArray *)orderPairArrayForFHIRNutritionOrderItemOralDietTextureComponent;
+ (NSArray *)orderPairArrayForFHIRNutritionOrderItemComponent;
+ (NSArray *)orderPairArrayForFHIRNutritionOrderItemEnteralFormulaComponent;
+ (NSArray *)orderPairArrayForFHIRNutritionOrderItemOralDietComponent;
+ (NSArray *)orderPairArrayForFHIRNutritionOrderItemOralDietNutrientsComponent;
+ (NSArray *)orderPairArrayForFHIRObservation;
+ (NSArray *)orderPairArrayForFHIRObservationReferenceRangeComponent;
+ (NSArray *)orderPairArrayForFHIRObservationRelatedComponent;
+ (NSArray *)orderPairArrayForFHIROperationDefinition;
+ (NSArray *)orderPairArrayForFHIROperationDefinitionParameterPartComponent;
+ (NSArray *)orderPairArrayForFHIROperationDefinitionParameterComponent;
+ (NSArray *)orderPairArrayForFHIROperationOutcome;
+ (NSArray *)orderPairArrayForFHIROperationOutcomeIssueComponent;
+ (NSArray *)orderPairArrayForFHIROralHealthClaim;
+ (NSArray *)orderPairArrayForFHIRItemsComponent;
+ (NSArray *)orderPairArrayForFHIROrthodonticPlanComponent;
+ (NSArray *)orderPairArrayForFHIRDetailComponent;
+ (NSArray *)orderPairArrayForFHIRCoverageComponent;
+ (NSArray *)orderPairArrayForFHIRPayeeComponent;
+ (NSArray *)orderPairArrayForFHIRDiagnosisComponent;
+ (NSArray *)orderPairArrayForFHIRProsthesisComponent;
+ (NSArray *)orderPairArrayForFHIRSubDetailComponent;
+ (NSArray *)orderPairArrayForFHIRMissingTeethComponent;
+ (NSArray *)orderPairArrayForFHIROrder;
+ (NSArray *)orderPairArrayForFHIROrderWhenComponent;
+ (NSArray *)orderPairArrayForFHIROrderResponse;
+ (NSArray *)orderPairArrayForFHIROrganization;
+ (NSArray *)orderPairArrayForFHIROrganizationContactComponent;
+ (NSArray *)orderPairArrayForFHIROther;
+ (NSArray *)orderPairArrayForFHIRPatient;
+ (NSArray *)orderPairArrayForFHIRContactComponent;
+ (NSArray *)orderPairArrayForFHIRAnimalComponent;
+ (NSArray *)orderPairArrayForFHIRPatientLinkComponent;
+ (NSArray *)orderPairArrayForFHIRPaymentNotice;
+ (NSArray *)orderPairArrayForFHIRPaymentReconciliation;
+ (NSArray *)orderPairArrayForFHIRNotesComponent;
+ (NSArray *)orderPairArrayForFHIRDetailsComponent;
+ (NSArray *)orderPairArrayForFHIRPendedRequest;
+ (NSArray *)orderPairArrayForFHIRPerson;
+ (NSArray *)orderPairArrayForFHIRPersonLinkComponent;
+ (NSArray *)orderPairArrayForFHIRPharmacyClaim;
+ (NSArray *)orderPairArrayForFHIRItemsComponent;
+ (NSArray *)orderPairArrayForFHIRDetailComponent;
+ (NSArray *)orderPairArrayForFHIRCoverageComponent;
+ (NSArray *)orderPairArrayForFHIRPayeeComponent;
+ (NSArray *)orderPairArrayForFHIRDiagnosisComponent;
+ (NSArray *)orderPairArrayForFHIRSubDetailComponent;
+ (NSArray *)orderPairArrayForFHIRPractitioner;
+ (NSArray *)orderPairArrayForFHIRPractitionerQualificationComponent;
+ (NSArray *)orderPairArrayForFHIRProcedure;
+ (NSArray *)orderPairArrayForFHIRProcedureRelatedItemComponent;
+ (NSArray *)orderPairArrayForFHIRProcedurePerformerComponent;
+ (NSArray *)orderPairArrayForFHIRProcedureRequest;
+ (NSArray *)orderPairArrayForFHIRProfessionalClaim;
+ (NSArray *)orderPairArrayForFHIRItemsComponent;
+ (NSArray *)orderPairArrayForFHIRDetailComponent;
+ (NSArray *)orderPairArrayForFHIRCoverageComponent;
+ (NSArray *)orderPairArrayForFHIRPayeeComponent;
+ (NSArray *)orderPairArrayForFHIRDiagnosisComponent;
+ (NSArray *)orderPairArrayForFHIRSubDetailComponent;
+ (NSArray *)orderPairArrayForFHIRProfile;
+ (NSArray *)orderPairArrayForFHIRConstraintComponent;
+ (NSArray *)orderPairArrayForFHIRProfileMappingComponent;
+ (NSArray *)orderPairArrayForFHIRProvenance;
+ (NSArray *)orderPairArrayForFHIRProvenanceAgentComponent;
+ (NSArray *)orderPairArrayForFHIRProvenanceEntityComponent;
+ (NSArray *)orderPairArrayForFHIRQuestionnaire;
+ (NSArray *)orderPairArrayForFHIRQuestionComponent;
+ (NSArray *)orderPairArrayForFHIRGroupComponent;
+ (NSArray *)orderPairArrayForFHIRQuestionnaireAnswers;
+ (NSArray *)orderPairArrayForFHIRQuestionAnswerComponent;
+ (NSArray *)orderPairArrayForFHIRQuestionComponent;
+ (NSArray *)orderPairArrayForFHIRGroupComponent;
+ (NSArray *)orderPairArrayForFHIRReadjudicate;
+ (NSArray *)orderPairArrayForFHIRItemsComponent;
+ (NSArray *)orderPairArrayForFHIRReferralRequest;
+ (NSArray *)orderPairArrayForFHIRRelatedPerson;
+ (NSArray *)orderPairArrayForFHIRReversal;
+ (NSArray *)orderPairArrayForFHIRPayeeComponent;
+ (NSArray *)orderPairArrayForFHIRReversalCoverageComponent;
+ (NSArray *)orderPairArrayForFHIRRiskAssessment;
+ (NSArray *)orderPairArrayForFHIRRiskAssessmentPredictionComponent;
+ (NSArray *)orderPairArrayForFHIRSchedule;
+ (NSArray *)orderPairArrayForFHIRSearchParameter;
+ (NSArray *)orderPairArrayForFHIRSecurityEvent;
+ (NSArray *)orderPairArrayForFHIRSecurityEventObjectDetailComponent;
+ (NSArray *)orderPairArrayForFHIRSecurityEventObjectComponent;
+ (NSArray *)orderPairArrayForFHIRSecurityEventSourceComponent;
+ (NSArray *)orderPairArrayForFHIRSecurityEventEventComponent;
+ (NSArray *)orderPairArrayForFHIRSecurityEventParticipantNetworkComponent;
+ (NSArray *)orderPairArrayForFHIRSecurityEventParticipantComponent;
+ (NSArray *)orderPairArrayForFHIRSlot;
+ (NSArray *)orderPairArrayForFHIRSpecimen;
+ (NSArray *)orderPairArrayForFHIRSpecimenCollectionComponent;
+ (NSArray *)orderPairArrayForFHIRSpecimenSourceComponent;
+ (NSArray *)orderPairArrayForFHIRSpecimenTreatmentComponent;
+ (NSArray *)orderPairArrayForFHIRSpecimenContainerComponent;
+ (NSArray *)orderPairArrayForFHIRStatusRequest;
+ (NSArray *)orderPairArrayForFHIRStatusResponse;
+ (NSArray *)orderPairArrayForFHIRStatusResponseNotesComponent;
+ (NSArray *)orderPairArrayForFHIRSubscription;
+ (NSArray *)orderPairArrayForFHIRSubscriptionChannelComponent;
+ (NSArray *)orderPairArrayForFHIRSubscriptionTagComponent;
+ (NSArray *)orderPairArrayForFHIRSubstance;
+ (NSArray *)orderPairArrayForFHIRSubstanceIngredientComponent;
+ (NSArray *)orderPairArrayForFHIRSubstanceInstanceComponent;
+ (NSArray *)orderPairArrayForFHIRSupply;
+ (NSArray *)orderPairArrayForFHIRSupplyDispenseComponent;
+ (NSArray *)orderPairArrayForFHIRSupportingDocumentation;
+ (NSArray *)orderPairArrayForFHIRSupportingDocumentationDetailComponent;
+ (NSArray *)orderPairArrayForFHIRValueSet;
+ (NSArray *)orderPairArrayForFHIRValueSetDefineComponent;
+ (NSArray *)orderPairArrayForFHIRValueSetExpansionContainsComponent;
+ (NSArray *)orderPairArrayForFHIRConceptDefinitionDesignationComponent;
+ (NSArray *)orderPairArrayForFHIRConceptDefinitionComponent;
+ (NSArray *)orderPairArrayForFHIRConceptSetComponent;
+ (NSArray *)orderPairArrayForFHIRConceptReferenceComponent;
+ (NSArray *)orderPairArrayForFHIRConceptSetFilterComponent;
+ (NSArray *)orderPairArrayForFHIRValueSetComposeComponent;
+ (NSArray *)orderPairArrayForFHIRValueSetExpansionComponent;
+ (NSArray *)orderPairArrayForFHIRVisionClaim;
+ (NSArray *)orderPairArrayForFHIRItemsComponent;
+ (NSArray *)orderPairArrayForFHIRDetailComponent;
+ (NSArray *)orderPairArrayForFHIRCoverageComponent;
+ (NSArray *)orderPairArrayForFHIRPayeeComponent;
+ (NSArray *)orderPairArrayForFHIRDiagnosisComponent;
+ (NSArray *)orderPairArrayForFHIRSubDetailComponent;
+ (NSArray *)orderPairArrayForFHIRVisionPrescription;
+ (NSArray *)orderPairArrayForFHIRVisionPrescriptionDispenseComponent;

@end

@implementation FHIRSerializerOrderPair

+ (NSArray *)orderPairArrayForFHIRAddress
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"use",@"FHIRCode",],
        @[@"text",@"FHIRString",],
        @[@"line",@"FHIRString",],
        @[@"city",@"FHIRString",],
        @[@"state",@"FHIRString",],
        @[@"postalCode",@"FHIRString",],
        @[@"country",@"FHIRString",],
        @[@"period",@"FHIRPeriod",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRAttachment
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"contentType",@"FHIRCode",],
        @[@"language",@"FHIRCode",],
        @[@"data",@"FHIRBase64Binary",],
        @[@"url",@"FHIRUri",],
        @[@"size",@"FHIRInteger",],
        @[@"hash",@"FHIRBase64Binary",],
        @[@"title",@"FHIRString",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRBackboneElement
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRCodeableConcept
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"coding",@"FHIRCoding",],
        @[@"text",@"FHIRString",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRCoding
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"system",@"FHIRUri",],
        @[@"version",@"FHIRString",],
        @[@"code",@"FHIRCode",],
        @[@"display",@"FHIRString",],
        @[@"primary",@"FHIRBoolean",],
        @[@"valueSet",@"FHIRReference",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRContactPoint
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"system",@"FHIRCode",],
        @[@"value",@"FHIRString",],
        @[@"use",@"FHIRCode",],
        @[@"period",@"FHIRPeriod",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRElement
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRElementDefinition
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"path",@"FHIRString",],
        @[@"representation",@"FHIRCode",],
        @[@"name",@"FHIRString",],
        @[@"slicing",@"FHIRElementDefinitionSlicingComponent",],
        @[@"short_",@"FHIRString",],
        @[@"formal",@"FHIRString",],
        @[@"comments",@"FHIRString",],
        @[@"requirements",@"FHIRString",],
        @[@"synonym",@"FHIRString",],
        @[@"min",@"FHIRInteger",],
        @[@"max",@"FHIRString",],
        @[@"type",@"FHIRTypeRefComponent",],
        @[@"nameReference",@"FHIRString",],
        @[@"defaultValue",@"FHIRElement",],
        @[@"meaningWhenMissing",@"FHIRString",],
        @[@"fixed_",@"FHIRElement",],
        @[@"pattern",@"FHIRElement",],
        @[@"example",@"FHIRElement",],
        @[@"maxLength",@"FHIRInteger",],
        @[@"condition",@"FHIRId",],
        @[@"constraint",@"FHIRElementDefinitionConstraintComponent",],
        @[@"mustSupport",@"FHIRBoolean",],
        @[@"isModifier",@"FHIRBoolean",],
        @[@"isSummary",@"FHIRBoolean",],
        @[@"binding",@"FHIRElementDefinitionBindingComponent",],
        @[@"mapping",@"FHIRElementDefinitionMappingComponent",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRElementDefinitionSlicingComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"discriminator",@"FHIRString",],
        @[@"description",@"FHIRString",],
        @[@"ordered",@"FHIRBoolean",],
        @[@"rules",@"FHIRCode",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRTypeRefComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"code",@"FHIRCode",],
        @[@"profile",@"FHIRUri",],
        @[@"aggregation",@"FHIRCode",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRElementDefinitionMappingComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"identity",@"FHIRId",],
        @[@"map",@"FHIRString",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRElementDefinitionBindingComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"name",@"FHIRString",],
        @[@"isExtensible",@"FHIRBoolean",],
        @[@"conformance",@"FHIRCode",],
        @[@"description",@"FHIRString",],
        @[@"reference",@"FHIRElement",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRElementDefinitionConstraintComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"key",@"FHIRId",],
        @[@"name",@"FHIRString",],
        @[@"severity",@"FHIRCode",],
        @[@"human",@"FHIRString",],
        @[@"xpath",@"FHIRString",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRExtension
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"url",@"FHIRUri",],
        @[@"value",@"FHIRElement",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRHumanName
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"use",@"FHIRCode",],
        @[@"text",@"FHIRString",],
        @[@"family",@"FHIRString",],
        @[@"given",@"FHIRString",],
        @[@"prefix",@"FHIRString",],
        @[@"suffix",@"FHIRString",],
        @[@"period",@"FHIRPeriod",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRIdentifier
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"use",@"FHIRCode",],
        @[@"label",@"FHIRString",],
        @[@"system",@"FHIRUri",],
        @[@"value",@"FHIRString",],
        @[@"period",@"FHIRPeriod",],
        @[@"assigner",@"FHIRReference",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRNarrative
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"status",@"FHIRCode",],
        @[@"div",@"FHIRXhtml",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRPeriod
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"start",@"FHIRDateTime",],
        @[@"end",@"FHIRDateTime",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRQuantity
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"value",@"FHIRDecimal",],
        @[@"comparator",@"FHIRCode",],
        @[@"units",@"FHIRString",],
        @[@"system",@"FHIRUri",],
        @[@"code",@"FHIRCode",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRRange
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"low",@"FHIRQuantity",],
        @[@"high",@"FHIRQuantity",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRRatio
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"numerator",@"FHIRQuantity",],
        @[@"denominator",@"FHIRQuantity",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRReference
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"reference",@"FHIRString",],
        @[@"display",@"FHIRString",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRSampledData
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"origin",@"FHIRQuantity",],
        @[@"period",@"FHIRDecimal",],
        @[@"factor",@"FHIRDecimal",],
        @[@"lowerLimit",@"FHIRDecimal",],
        @[@"upperLimit",@"FHIRDecimal",],
        @[@"dimensions",@"FHIRInteger",],
        @[@"data",@"FHIRString",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRTiming
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"event_",@"FHIRPeriod",],
        @[@"repeat",@"FHIRTimingRepeatComponent",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRTimingRepeatComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"frequency",@"FHIRInteger",],
        @[@"when",@"FHIRCode",],
        @[@"duration",@"FHIRDecimal",],
        @[@"units",@"FHIRCode",],
        @[@"count",@"FHIRInteger",],
        @[@"end",@"FHIRDateTime",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRBase64Binary
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"value",@"NSData",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRBoolean
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"value",@"NSNumber",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRCode
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"value",@"NSString",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRDate
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"value",@"NSString",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRDateTime
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"value",@"NSString",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRDecimal
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"value",@"NSDecimalNumber",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRId
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"value",@"NSString",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRInstant
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"value",@"NSDate",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRInteger
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"value",@"NSNumber",],
    ];
}

+ (NSArray *)orderPairArrayForFHIROid
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"value",@"NSString",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRString
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"value",@"NSString",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRTime
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"value",@"NSString",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRUri
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"value",@"NSString",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRUuid
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"value",@"NSString",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRXhtml
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"value",@"NSString",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRDomainResource
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"meta",@"FHIRResourceMetaComponent",],
        @[@"implicitRules",@"FHIRUri",],
        @[@"language",@"FHIRCode",],
        @[@"text",@"FHIRNarrative",],
        @[@"contained",@"FHIRBaseResource",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRParameters
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"meta",@"FHIRResourceMetaComponent",],
        @[@"implicitRules",@"FHIRUri",],
        @[@"language",@"FHIRCode",],
        @[@"parameter",@"FHIRParametersParameterComponent",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRParametersParameterComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"name",@"FHIRString",],
        @[@"value",@"FHIRElement",],
        @[@"resource",@"FHIRBaseResource",],
        @[@"part",@"FHIRParametersParameterPartComponent",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRParametersParameterPartComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"name",@"FHIRString",],
        @[@"value",@"FHIRElement",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRBaseResource
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"meta",@"FHIRResourceMetaComponent",],
        @[@"implicitRules",@"FHIRUri",],
        @[@"language",@"FHIRCode",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRResourceMetaComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"versionId",@"FHIRId",],
        @[@"lastUpdated",@"FHIRInstant",],
        @[@"profile",@"FHIRUri",],
        @[@"security",@"FHIRCoding",],
        @[@"tag",@"FHIRCoding",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRAlert
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"meta",@"FHIRResourceMetaComponent",],
        @[@"implicitRules",@"FHIRUri",],
        @[@"language",@"FHIRCode",],
        @[@"text",@"FHIRNarrative",],
        @[@"contained",@"FHIRBaseResource",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"identifier",@"FHIRIdentifier",],
        @[@"category",@"FHIRCodeableConcept",],
        @[@"status",@"FHIRCode",],
        @[@"subject",@"FHIRReference",],
        @[@"author",@"FHIRReference",],
        @[@"note",@"FHIRString",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRAllergyIntolerance
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"meta",@"FHIRResourceMetaComponent",],
        @[@"implicitRules",@"FHIRUri",],
        @[@"language",@"FHIRCode",],
        @[@"text",@"FHIRNarrative",],
        @[@"contained",@"FHIRBaseResource",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"identifier",@"FHIRIdentifier",],
        @[@"recordedDate",@"FHIRDateTime",],
        @[@"recorder",@"FHIRReference",],
        @[@"subject",@"FHIRReference",],
        @[@"substance",@"FHIRCodeableConcept",],
        @[@"status",@"FHIRCode",],
        @[@"criticality",@"FHIRCode",],
        @[@"type",@"FHIRCode",],
        @[@"category",@"FHIRCode",],
        @[@"lastOccurence",@"FHIRDateTime",],
        @[@"comment",@"FHIRString",],
        @[@"event_",@"FHIRAllergyIntoleranceEventComponent",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRAllergyIntoleranceEventComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"substance",@"FHIRCodeableConcept",],
        @[@"certainty",@"FHIRCode",],
        @[@"manifestation",@"FHIRCodeableConcept",],
        @[@"description",@"FHIRString",],
        @[@"onset",@"FHIRDateTime",],
        @[@"duration",@"FHIRDuration",],
        @[@"severity",@"FHIRCode",],
        @[@"exposureRoute",@"FHIRCodeableConcept",],
        @[@"comment",@"FHIRString",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRAppointment
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"meta",@"FHIRResourceMetaComponent",],
        @[@"implicitRules",@"FHIRUri",],
        @[@"language",@"FHIRCode",],
        @[@"text",@"FHIRNarrative",],
        @[@"contained",@"FHIRBaseResource",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"identifier",@"FHIRIdentifier",],
        @[@"priority",@"FHIRInteger",],
        @[@"status",@"FHIRCode",],
        @[@"type",@"FHIRCodeableConcept",],
        @[@"reason",@"FHIRCodeableConcept",],
        @[@"description",@"FHIRString",],
        @[@"start",@"FHIRInstant",],
        @[@"end",@"FHIRInstant",],
        @[@"slot",@"FHIRReference",],
        @[@"location",@"FHIRReference",],
        @[@"comment",@"FHIRString",],
        @[@"order",@"FHIRReference",],
        @[@"participant",@"FHIRAppointmentParticipantComponent",],
        @[@"lastModifiedBy",@"FHIRReference",],
        @[@"lastModified",@"FHIRDateTime",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRAppointmentParticipantComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"type",@"FHIRCodeableConcept",],
        @[@"actor",@"FHIRReference",],
        @[@"required",@"FHIRCode",],
        @[@"status",@"FHIRCode",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRAppointmentResponse
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"meta",@"FHIRResourceMetaComponent",],
        @[@"implicitRules",@"FHIRUri",],
        @[@"language",@"FHIRCode",],
        @[@"text",@"FHIRNarrative",],
        @[@"contained",@"FHIRBaseResource",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"identifier",@"FHIRIdentifier",],
        @[@"appointment",@"FHIRReference",],
        @[@"participantType",@"FHIRCodeableConcept",],
        @[@"individual",@"FHIRReference",],
        @[@"participantStatus",@"FHIRCode",],
        @[@"comment",@"FHIRString",],
        @[@"start",@"FHIRInstant",],
        @[@"end",@"FHIRInstant",],
        @[@"lastModifiedBy",@"FHIRReference",],
        @[@"lastModified",@"FHIRDateTime",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRBasic
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"meta",@"FHIRResourceMetaComponent",],
        @[@"implicitRules",@"FHIRUri",],
        @[@"language",@"FHIRCode",],
        @[@"text",@"FHIRNarrative",],
        @[@"contained",@"FHIRBaseResource",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"identifier",@"FHIRIdentifier",],
        @[@"code",@"FHIRCodeableConcept",],
        @[@"subject",@"FHIRReference",],
        @[@"author",@"FHIRReference",],
        @[@"created",@"FHIRDate",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRBinary
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"meta",@"FHIRResourceMetaComponent",],
        @[@"implicitRules",@"FHIRUri",],
        @[@"language",@"FHIRCode",],
        @[@"contentType",@"FHIRCode",],
        @[@"content",@"FHIRBase64Binary",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRBundle
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"meta",@"FHIRResourceMetaComponent",],
        @[@"implicitRules",@"FHIRUri",],
        @[@"language",@"FHIRCode",],
        @[@"type",@"FHIRCode",],
        @[@"base_",@"FHIRUri",],
        @[@"total",@"FHIRInteger",],
        @[@"link",@"FHIRBundleLinkComponent",],
        @[@"entry",@"FHIRBundleEntryComponent",],
        @[@"signature",@"FHIRBase64Binary",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRBundleEntryDeletedComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"type",@"FHIRCode",],
        @[@"resourceId",@"FHIRId",],
        @[@"versionId",@"FHIRId",],
        @[@"instant",@"FHIRInstant",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRBundleEntryComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"base_",@"FHIRUri",],
        @[@"status",@"FHIRCode",],
        @[@"search",@"FHIRUri",],
        @[@"score",@"FHIRDecimal",],
        @[@"deleted",@"FHIRBundleEntryDeletedComponent",],
        @[@"resource",@"FHIRBaseResource",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRBundleLinkComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"relation",@"FHIRString",],
        @[@"url",@"FHIRUri",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRCarePlan
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"meta",@"FHIRResourceMetaComponent",],
        @[@"implicitRules",@"FHIRUri",],
        @[@"language",@"FHIRCode",],
        @[@"text",@"FHIRNarrative",],
        @[@"contained",@"FHIRBaseResource",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"identifier",@"FHIRIdentifier",],
        @[@"patient",@"FHIRReference",],
        @[@"status",@"FHIRCode",],
        @[@"period",@"FHIRPeriod",],
        @[@"modified",@"FHIRDateTime",],
        @[@"concern",@"FHIRReference",],
        @[@"participant",@"FHIRCarePlanParticipantComponent",],
        @[@"goal",@"FHIRCarePlanGoalComponent",],
        @[@"activity",@"FHIRCarePlanActivityComponent",],
        @[@"notes",@"FHIRString",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRCarePlanGoalComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"description",@"FHIRString",],
        @[@"status",@"FHIRCode",],
        @[@"notes",@"FHIRString",],
        @[@"concern",@"FHIRReference",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRCarePlanParticipantComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"role",@"FHIRCodeableConcept",],
        @[@"member",@"FHIRReference",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRCarePlanActivityComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"goal",@"FHIRUri",],
        @[@"status",@"FHIRCode",],
        @[@"prohibited",@"FHIRBoolean",],
        @[@"actionResulting",@"FHIRReference",],
        @[@"notes",@"FHIRString",],
        @[@"detail",@"FHIRReference",],
        @[@"simple",@"FHIRCarePlanActivitySimpleComponent",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRCarePlanActivitySimpleComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"category",@"FHIRCode",],
        @[@"code",@"FHIRCodeableConcept",],
        @[@"scheduled",@"FHIRElement",],
        @[@"location",@"FHIRReference",],
        @[@"performer",@"FHIRReference",],
        @[@"product",@"FHIRReference",],
        @[@"dailyAmount",@"FHIRQuantity",],
        @[@"quantity",@"FHIRQuantity",],
        @[@"details",@"FHIRString",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRCarePlan2
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"meta",@"FHIRResourceMetaComponent",],
        @[@"implicitRules",@"FHIRUri",],
        @[@"language",@"FHIRCode",],
        @[@"text",@"FHIRNarrative",],
        @[@"contained",@"FHIRBaseResource",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"identifier",@"FHIRIdentifier",],
        @[@"patient",@"FHIRReference",],
        @[@"status",@"FHIRCode",],
        @[@"period",@"FHIRPeriod",],
        @[@"modified",@"FHIRDateTime",],
        @[@"concern",@"FHIRReference",],
        @[@"participant",@"FHIRCarePlan2ParticipantComponent",],
        @[@"notes",@"FHIRString",],
        @[@"goal",@"FHIRReference",],
        @[@"activity",@"FHIRReference",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRCarePlan2ParticipantComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"role",@"FHIRCodeableConcept",],
        @[@"member",@"FHIRReference",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRClaimResponse
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"meta",@"FHIRResourceMetaComponent",],
        @[@"implicitRules",@"FHIRUri",],
        @[@"language",@"FHIRCode",],
        @[@"text",@"FHIRNarrative",],
        @[@"contained",@"FHIRBaseResource",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"identifier",@"FHIRIdentifier",],
        @[@"request",@"FHIRReference",],
        @[@"ruleset",@"FHIRCoding",],
        @[@"originalRuleset",@"FHIRCoding",],
        @[@"created",@"FHIRDateTime",],
        @[@"organization",@"FHIRReference",],
        @[@"requestProvider",@"FHIRReference",],
        @[@"requestOrganization",@"FHIRReference",],
        @[@"outcome",@"FHIRCode",],
        @[@"disposition",@"FHIRString",],
        @[@"payeeType",@"FHIRCoding",],
        @[@"item",@"FHIRItemsComponent",],
        @[@"additem",@"FHIRAddedItemComponent",],
        @[@"error",@"FHIRErrorsComponent",],
        @[@"totalCost",@"FHIRMoney",],
        @[@"unallocDeductable",@"FHIRMoney",],
        @[@"totalBenefit",@"FHIRMoney",],
        @[@"paymentAdjustment",@"FHIRMoney",],
        @[@"paymentAdjustmentReason",@"FHIRCoding",],
        @[@"paymentDate",@"FHIRDate",],
        @[@"paymentAmount",@"FHIRMoney",],
        @[@"paymentRef",@"FHIRIdentifier",],
        @[@"reserved",@"FHIRCoding",],
        @[@"form",@"FHIRCoding",],
        @[@"note",@"FHIRNotesComponent",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRNotesComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"number",@"FHIRInteger",],
        @[@"type",@"FHIRCoding",],
        @[@"text",@"FHIRString",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRItemsComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"sequenceLinkId",@"FHIRInteger",],
        @[@"noteNumber",@"FHIRInteger",],
        @[@"adjudication",@"FHIRItemAdjudicationComponent",],
        @[@"detail",@"FHIRItemDetailComponent",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRItemSubdetailComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"sequenceLinkId",@"FHIRInteger",],
        @[@"adjudication",@"FHIRSubdetailAdjudicationComponent",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRAddedItemDetailAdjudicationComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"code",@"FHIRCoding",],
        @[@"amount",@"FHIRMoney",],
        @[@"value",@"FHIRDecimal",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRAddedItemAdjudicationComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"code",@"FHIRCoding",],
        @[@"amount",@"FHIRMoney",],
        @[@"value",@"FHIRDecimal",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRDetailAdjudicationComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"code",@"FHIRCoding",],
        @[@"amount",@"FHIRMoney",],
        @[@"value",@"FHIRDecimal",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRErrorsComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"sequenceLinkId",@"FHIRInteger",],
        @[@"detailSequenceLinkId",@"FHIRInteger",],
        @[@"subdetailSequenceLinkId",@"FHIRInteger",],
        @[@"code",@"FHIRCoding",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRAddedItemComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"sequenceLinkId",@"FHIRInteger",],
        @[@"service",@"FHIRCoding",],
        @[@"fee",@"FHIRMoney",],
        @[@"noteNumberLinkId",@"FHIRInteger",],
        @[@"adjudication",@"FHIRAddedItemAdjudicationComponent",],
        @[@"detail",@"FHIRAddedItemsDetailComponent",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRItemAdjudicationComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"code",@"FHIRCoding",],
        @[@"amount",@"FHIRMoney",],
        @[@"value",@"FHIRDecimal",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRAddedItemsDetailComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"service",@"FHIRCoding",],
        @[@"fee",@"FHIRMoney",],
        @[@"adjudication",@"FHIRAddedItemDetailAdjudicationComponent",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRSubdetailAdjudicationComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"code",@"FHIRCoding",],
        @[@"amount",@"FHIRMoney",],
        @[@"value",@"FHIRDecimal",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRItemDetailComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"sequenceLinkId",@"FHIRInteger",],
        @[@"adjudication",@"FHIRDetailAdjudicationComponent",],
        @[@"subdetail",@"FHIRItemSubdetailComponent",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRClinicalAssessment
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"meta",@"FHIRResourceMetaComponent",],
        @[@"implicitRules",@"FHIRUri",],
        @[@"language",@"FHIRCode",],
        @[@"text",@"FHIRNarrative",],
        @[@"contained",@"FHIRBaseResource",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"patient",@"FHIRReference",],
        @[@"assessor",@"FHIRReference",],
        @[@"date",@"FHIRDateTime",],
        @[@"description",@"FHIRString",],
        @[@"previous",@"FHIRReference",],
        @[@"problem",@"FHIRReference",],
        @[@"careplan",@"FHIRReference",],
        @[@"referral",@"FHIRReference",],
        @[@"investigations",@"FHIRClinicalAssessmentInvestigationsComponent",],
        @[@"protocol",@"FHIRUri",],
        @[@"summary",@"FHIRString",],
        @[@"diagnosis",@"FHIRClinicalAssessmentDiagnosisComponent",],
        @[@"resolved",@"FHIRCodeableConcept",],
        @[@"ruledOut",@"FHIRClinicalAssessmentRuledOutComponent",],
        @[@"prognosis",@"FHIRString",],
        @[@"plan",@"FHIRReference",],
        @[@"action",@"FHIRReference",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRClinicalAssessmentRuledOutComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"item",@"FHIRCodeableConcept",],
        @[@"reason",@"FHIRString",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRClinicalAssessmentInvestigationsComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"code",@"FHIRCodeableConcept",],
        @[@"item",@"FHIRReference",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRClinicalAssessmentDiagnosisComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"item",@"FHIRCodeableConcept",],
        @[@"cause",@"FHIRString",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRCommunication
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"meta",@"FHIRResourceMetaComponent",],
        @[@"implicitRules",@"FHIRUri",],
        @[@"language",@"FHIRCode",],
        @[@"text",@"FHIRNarrative",],
        @[@"contained",@"FHIRBaseResource",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"identifier",@"FHIRIdentifier",],
        @[@"category",@"FHIRCodeableConcept",],
        @[@"sender",@"FHIRReference",],
        @[@"recipient",@"FHIRReference",],
        @[@"payload",@"FHIRCommunicationPayloadComponent",],
        @[@"medium",@"FHIRCodeableConcept",],
        @[@"status",@"FHIRCode",],
        @[@"encounter",@"FHIRReference",],
        @[@"sent",@"FHIRDateTime",],
        @[@"received",@"FHIRDateTime",],
        @[@"reason",@"FHIRCodeableConcept",],
        @[@"subject",@"FHIRReference",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRCommunicationPayloadComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"content",@"FHIRElement",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRCommunicationRequest
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"meta",@"FHIRResourceMetaComponent",],
        @[@"implicitRules",@"FHIRUri",],
        @[@"language",@"FHIRCode",],
        @[@"text",@"FHIRNarrative",],
        @[@"contained",@"FHIRBaseResource",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"identifier",@"FHIRIdentifier",],
        @[@"category",@"FHIRCodeableConcept",],
        @[@"sender",@"FHIRReference",],
        @[@"recipient",@"FHIRReference",],
        @[@"payload",@"FHIRCommunicationRequestPayloadComponent",],
        @[@"medium",@"FHIRCodeableConcept",],
        @[@"requester",@"FHIRReference",],
        @[@"status",@"FHIRCode",],
        @[@"encounter",@"FHIRReference",],
        @[@"scheduledTime",@"FHIRDateTime",],
        @[@"reason",@"FHIRCodeableConcept",],
        @[@"orderedOn",@"FHIRDateTime",],
        @[@"subject",@"FHIRReference",],
        @[@"priority",@"FHIRCodeableConcept",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRCommunicationRequestPayloadComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"content",@"FHIRElement",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRComposition
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"meta",@"FHIRResourceMetaComponent",],
        @[@"implicitRules",@"FHIRUri",],
        @[@"language",@"FHIRCode",],
        @[@"text",@"FHIRNarrative",],
        @[@"contained",@"FHIRBaseResource",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"identifier",@"FHIRIdentifier",],
        @[@"date",@"FHIRDateTime",],
        @[@"type",@"FHIRCodeableConcept",],
        @[@"class_",@"FHIRCodeableConcept",],
        @[@"title",@"FHIRString",],
        @[@"status",@"FHIRCode",],
        @[@"confidentiality",@"FHIRCoding",],
        @[@"subject",@"FHIRReference",],
        @[@"author",@"FHIRReference",],
        @[@"attester",@"FHIRCompositionAttesterComponent",],
        @[@"custodian",@"FHIRReference",],
        @[@"event_",@"FHIRCompositionEventComponent",],
        @[@"encounter",@"FHIRReference",],
        @[@"section",@"FHIRSectionComponent",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRSectionComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"title",@"FHIRString",],
        @[@"code",@"FHIRCodeableConcept",],
        @[@"section",@"FHIRSectionComponent",],
        @[@"content",@"FHIRReference",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRCompositionEventComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"code",@"FHIRCodeableConcept",],
        @[@"period",@"FHIRPeriod",],
        @[@"detail",@"FHIRReference",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRCompositionAttesterComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"mode",@"FHIRCode",],
        @[@"time",@"FHIRDateTime",],
        @[@"party",@"FHIRReference",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRConceptMap
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"meta",@"FHIRResourceMetaComponent",],
        @[@"implicitRules",@"FHIRUri",],
        @[@"language",@"FHIRCode",],
        @[@"text",@"FHIRNarrative",],
        @[@"contained",@"FHIRBaseResource",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"identifier",@"FHIRString",],
        @[@"version",@"FHIRString",],
        @[@"name",@"FHIRString",],
        @[@"publisher",@"FHIRString",],
        @[@"telecom",@"FHIRContactPoint",],
        @[@"description",@"FHIRString",],
        @[@"copyright",@"FHIRString",],
        @[@"status",@"FHIRCode",],
        @[@"experimental",@"FHIRBoolean",],
        @[@"date",@"FHIRDateTime",],
        @[@"source",@"FHIRElement",],
        @[@"target",@"FHIRElement",],
        @[@"element",@"FHIRConceptMapElementComponent",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRConceptMapElementComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"codeSystem",@"FHIRUri",],
        @[@"code",@"FHIRCode",],
        @[@"dependsOn",@"FHIROtherElementComponent",],
        @[@"map",@"FHIRConceptMapElementMapComponent",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRConceptMapElementMapComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"codeSystem",@"FHIRUri",],
        @[@"code",@"FHIRCode",],
        @[@"equivalence",@"FHIRCode",],
        @[@"comments",@"FHIRString",],
        @[@"product",@"FHIROtherElementComponent",],
    ];
}

+ (NSArray *)orderPairArrayForFHIROtherElementComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"element",@"FHIRUri",],
        @[@"codeSystem",@"FHIRUri",],
        @[@"code",@"FHIRString",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRCondition
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"meta",@"FHIRResourceMetaComponent",],
        @[@"implicitRules",@"FHIRUri",],
        @[@"language",@"FHIRCode",],
        @[@"text",@"FHIRNarrative",],
        @[@"contained",@"FHIRBaseResource",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"identifier",@"FHIRIdentifier",],
        @[@"subject",@"FHIRReference",],
        @[@"encounter",@"FHIRReference",],
        @[@"asserter",@"FHIRReference",],
        @[@"dateAsserted",@"FHIRDate",],
        @[@"code",@"FHIRCodeableConcept",],
        @[@"category",@"FHIRCodeableConcept",],
        @[@"status",@"FHIRCode",],
        @[@"certainty",@"FHIRCodeableConcept",],
        @[@"severity",@"FHIRCodeableConcept",],
        @[@"onset",@"FHIRElement",],
        @[@"abatement",@"FHIRElement",],
        @[@"stage",@"FHIRConditionStageComponent",],
        @[@"evidence",@"FHIRConditionEvidenceComponent",],
        @[@"location",@"FHIRConditionLocationComponent",],
        @[@"dueTo",@"FHIRConditionDueToComponent",],
        @[@"occurredFollowing",@"FHIRConditionOccurredFollowingComponent",],
        @[@"notes",@"FHIRString",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRConditionEvidenceComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"code",@"FHIRCodeableConcept",],
        @[@"detail",@"FHIRReference",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRConditionDueToComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"codeableConcept",@"FHIRCodeableConcept",],
        @[@"target",@"FHIRReference",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRConditionOccurredFollowingComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"codeableConcept",@"FHIRCodeableConcept",],
        @[@"target",@"FHIRReference",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRConditionStageComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"summary",@"FHIRCodeableConcept",],
        @[@"assessment",@"FHIRReference",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRConditionLocationComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"code",@"FHIRCodeableConcept",],
        @[@"detail",@"FHIRString",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRConformance
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"meta",@"FHIRResourceMetaComponent",],
        @[@"implicitRules",@"FHIRUri",],
        @[@"language",@"FHIRCode",],
        @[@"text",@"FHIRNarrative",],
        @[@"contained",@"FHIRBaseResource",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"identifier",@"FHIRString",],
        @[@"version",@"FHIRString",],
        @[@"name",@"FHIRString",],
        @[@"publisher",@"FHIRString",],
        @[@"telecom",@"FHIRContactPoint",],
        @[@"description",@"FHIRString",],
        @[@"status",@"FHIRCode",],
        @[@"experimental",@"FHIRBoolean",],
        @[@"date",@"FHIRDateTime",],
        @[@"software",@"FHIRConformanceSoftwareComponent",],
        @[@"implementation",@"FHIRConformanceImplementationComponent",],
        @[@"fhirVersion",@"FHIRId",],
        @[@"acceptUnknown",@"FHIRBoolean",],
        @[@"format",@"FHIRCode",],
        @[@"profile",@"FHIRReference",],
        @[@"rest",@"FHIRConformanceRestComponent",],
        @[@"messaging",@"FHIRConformanceMessagingComponent",],
        @[@"document",@"FHIRConformanceDocumentComponent",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRConformanceRestComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"mode",@"FHIRCode",],
        @[@"documentation",@"FHIRString",],
        @[@"security",@"FHIRConformanceRestSecurityComponent",],
        @[@"resource",@"FHIRConformanceRestResourceComponent",],
        @[@"interaction",@"FHIRSystemInteractionComponent",],
        @[@"operation",@"FHIRConformanceRestOperationComponent",],
        @[@"documentMailbox",@"FHIRUri",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRConformanceSoftwareComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"name",@"FHIRString",],
        @[@"version",@"FHIRString",],
        @[@"releaseDate",@"FHIRDateTime",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRConformanceMessagingComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"endpoint",@"FHIRUri",],
        @[@"reliableCache",@"FHIRInteger",],
        @[@"documentation",@"FHIRString",],
        @[@"event_",@"FHIRConformanceMessagingEventComponent",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRConformanceDocumentComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"mode",@"FHIRCode",],
        @[@"documentation",@"FHIRString",],
        @[@"profile",@"FHIRReference",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRConformanceRestResourceComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"type",@"FHIRCode",],
        @[@"profile",@"FHIRReference",],
        @[@"interaction",@"FHIRResourceInteractionComponent",],
        @[@"versioning",@"FHIRCode",],
        @[@"readHistory",@"FHIRBoolean",],
        @[@"updateCreate",@"FHIRBoolean",],
        @[@"searchInclude",@"FHIRString",],
        @[@"searchParam",@"FHIRConformanceRestResourceSearchParamComponent",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRConformanceImplementationComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"description",@"FHIRString",],
        @[@"url",@"FHIRUri",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRConformanceMessagingEventComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"code",@"FHIRCoding",],
        @[@"category",@"FHIRCode",],
        @[@"mode",@"FHIRCode",],
        @[@"protocol",@"FHIRCoding",],
        @[@"focus",@"FHIRCode",],
        @[@"request",@"FHIRReference",],
        @[@"response",@"FHIRReference",],
        @[@"documentation",@"FHIRString",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRSystemInteractionComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"code",@"FHIRCode",],
        @[@"documentation",@"FHIRString",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRResourceInteractionComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"code",@"FHIRCode",],
        @[@"documentation",@"FHIRString",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRConformanceRestSecurityComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"cors",@"FHIRBoolean",],
        @[@"service",@"FHIRCodeableConcept",],
        @[@"description",@"FHIRString",],
        @[@"certificate",@"FHIRConformanceRestSecurityCertificateComponent",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRConformanceRestSecurityCertificateComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"type",@"FHIRCode",],
        @[@"blob",@"FHIRBase64Binary",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRConformanceRestOperationComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"name",@"FHIRString",],
        @[@"definition",@"FHIRReference",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRConformanceRestResourceSearchParamComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"name",@"FHIRString",],
        @[@"definition",@"FHIRUri",],
        @[@"type",@"FHIRCode",],
        @[@"documentation",@"FHIRString",],
        @[@"target",@"FHIRCode",],
        @[@"chain",@"FHIRString",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRContract
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"meta",@"FHIRResourceMetaComponent",],
        @[@"implicitRules",@"FHIRUri",],
        @[@"language",@"FHIRCode",],
        @[@"text",@"FHIRNarrative",],
        @[@"contained",@"FHIRBaseResource",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"identifier",@"FHIRIdentifier",],
        @[@"subject",@"FHIRReference",],
        @[@"authority",@"FHIRReference",],
        @[@"domain",@"FHIRReference",],
        @[@"type",@"FHIRCodeableConcept",],
        @[@"subtype",@"FHIRCodeableConcept",],
        @[@"issued",@"FHIRDateTime",],
        @[@"applies",@"FHIRPeriod",],
        @[@"quantity",@"FHIRQuantity",],
        @[@"unitPrice",@"FHIRMoney",],
        @[@"factor",@"FHIRDecimal",],
        @[@"points",@"FHIRDecimal",],
        @[@"net",@"FHIRMoney",],
        @[@"author",@"FHIRReference",],
        @[@"grantor",@"FHIRReference",],
        @[@"grantee",@"FHIRReference",],
        @[@"witness",@"FHIRReference",],
        @[@"executor",@"FHIRReference",],
        @[@"notary",@"FHIRReference",],
        @[@"signer",@"FHIRContractSignerComponent",],
        @[@"term",@"FHIRContractTermComponent",],
        @[@"binding",@"FHIRAttachment",],
        @[@"bindingDateTime",@"FHIRDateTime",],
        @[@"friendly",@"FHIRAttachment",],
        @[@"friendlyDateTime",@"FHIRDateTime",],
        @[@"legal",@"FHIRAttachment",],
        @[@"legalDateTime",@"FHIRDateTime",],
        @[@"rule",@"FHIRAttachment",],
        @[@"ruleDateTime",@"FHIRDateTime",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRContractSignerComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"type",@"FHIRCoding",],
        @[@"signature",@"FHIRString",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRContractTermComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"identifier",@"FHIRIdentifier",],
        @[@"type",@"FHIRCodeableConcept",],
        @[@"subtype",@"FHIRCodeableConcept",],
        @[@"subject",@"FHIRReference",],
        @[@"text",@"FHIRString",],
        @[@"issued",@"FHIRDateTime",],
        @[@"applies",@"FHIRPeriod",],
        @[@"quantity",@"FHIRQuantity",],
        @[@"unitPrice",@"FHIRMoney",],
        @[@"factor",@"FHIRDecimal",],
        @[@"points",@"FHIRDecimal",],
        @[@"net",@"FHIRMoney",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRContraindication
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"meta",@"FHIRResourceMetaComponent",],
        @[@"implicitRules",@"FHIRUri",],
        @[@"language",@"FHIRCode",],
        @[@"text",@"FHIRNarrative",],
        @[@"contained",@"FHIRBaseResource",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"patient",@"FHIRReference",],
        @[@"category",@"FHIRCodeableConcept",],
        @[@"severity",@"FHIRCode",],
        @[@"implicated",@"FHIRReference",],
        @[@"detail",@"FHIRString",],
        @[@"date",@"FHIRDateTime",],
        @[@"author",@"FHIRReference",],
        @[@"identifier",@"FHIRIdentifier",],
        @[@"reference",@"FHIRUri",],
        @[@"mitigation",@"FHIRContraindicationMitigationComponent",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRContraindicationMitigationComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"action",@"FHIRCodeableConcept",],
        @[@"date",@"FHIRDateTime",],
        @[@"author",@"FHIRReference",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRCoverage
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"meta",@"FHIRResourceMetaComponent",],
        @[@"implicitRules",@"FHIRUri",],
        @[@"language",@"FHIRCode",],
        @[@"text",@"FHIRNarrative",],
        @[@"contained",@"FHIRBaseResource",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"issuer",@"FHIRReference",],
        @[@"period",@"FHIRPeriod",],
        @[@"type",@"FHIRCoding",],
        @[@"identifier",@"FHIRIdentifier",],
        @[@"group",@"FHIRString",],
        @[@"plan",@"FHIRString",],
        @[@"subplan",@"FHIRString",],
        @[@"dependent",@"FHIRInteger",],
        @[@"sequence",@"FHIRInteger",],
        @[@"subscriber",@"FHIRReference",],
        @[@"network",@"FHIRIdentifier",],
        @[@"contract",@"FHIRReference",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRDataElement
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"meta",@"FHIRResourceMetaComponent",],
        @[@"implicitRules",@"FHIRUri",],
        @[@"language",@"FHIRCode",],
        @[@"text",@"FHIRNarrative",],
        @[@"contained",@"FHIRBaseResource",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"identifier",@"FHIRIdentifier",],
        @[@"version",@"FHIRString",],
        @[@"publisher",@"FHIRString",],
        @[@"telecom",@"FHIRContactPoint",],
        @[@"status",@"FHIRCode",],
        @[@"date",@"FHIRDateTime",],
        @[@"name",@"FHIRString",],
        @[@"category",@"FHIRCodeableConcept",],
        @[@"granularity",@"FHIRCode",],
        @[@"code",@"FHIRCoding",],
        @[@"question",@"FHIRString",],
        @[@"label",@"FHIRString",],
        @[@"definition",@"FHIRString",],
        @[@"comments",@"FHIRString",],
        @[@"requirements",@"FHIRString",],
        @[@"synonym",@"FHIRString",],
        @[@"type",@"FHIRCode",],
        @[@"example",@"FHIRElement",],
        @[@"maxLength",@"FHIRInteger",],
        @[@"units",@"FHIRElement",],
        @[@"binding",@"FHIRDataElementBindingComponent",],
        @[@"mapping",@"FHIRDataElementMappingComponent",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRDataElementMappingComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"uri",@"FHIRUri",],
        @[@"definitional",@"FHIRBoolean",],
        @[@"name",@"FHIRString",],
        @[@"comments",@"FHIRString",],
        @[@"map",@"FHIRString",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRDataElementBindingComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"isExtensible",@"FHIRBoolean",],
        @[@"conformance",@"FHIRCode",],
        @[@"description",@"FHIRString",],
        @[@"valueSet",@"FHIRReference",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRDevice
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"meta",@"FHIRResourceMetaComponent",],
        @[@"implicitRules",@"FHIRUri",],
        @[@"language",@"FHIRCode",],
        @[@"text",@"FHIRNarrative",],
        @[@"contained",@"FHIRBaseResource",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"identifier",@"FHIRIdentifier",],
        @[@"type",@"FHIRCodeableConcept",],
        @[@"manufacturer",@"FHIRString",],
        @[@"model",@"FHIRString",],
        @[@"version",@"FHIRString",],
        @[@"expiry",@"FHIRDate",],
        @[@"udi",@"FHIRString",],
        @[@"lotNumber",@"FHIRString",],
        @[@"owner",@"FHIRReference",],
        @[@"location",@"FHIRReference",],
        @[@"patient",@"FHIRReference",],
        @[@"contact",@"FHIRContactPoint",],
        @[@"url",@"FHIRUri",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRDeviceComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"meta",@"FHIRResourceMetaComponent",],
        @[@"implicitRules",@"FHIRUri",],
        @[@"language",@"FHIRCode",],
        @[@"text",@"FHIRNarrative",],
        @[@"contained",@"FHIRBaseResource",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"type",@"FHIRCodeableConcept",],
        @[@"identifier",@"FHIRIdentifier",],
        @[@"lastSystemChange",@"FHIRInstant",],
        @[@"source",@"FHIRReference",],
        @[@"parent",@"FHIRReference",],
        @[@"operationalStatus",@"FHIRCodeableConcept",],
        @[@"parameterGroup",@"FHIRCodeableConcept",],
        @[@"measurementPrinciple",@"FHIRCode",],
        @[@"productionSpecification",@"FHIRDeviceComponentProductionSpecificationComponent",],
        @[@"languageCode",@"FHIRCodeableConcept",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRDeviceComponentProductionSpecificationComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"specType",@"FHIRCodeableConcept",],
        @[@"componentId",@"FHIRIdentifier",],
        @[@"productionSpec",@"FHIRString",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRDeviceMetric
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"meta",@"FHIRResourceMetaComponent",],
        @[@"implicitRules",@"FHIRUri",],
        @[@"language",@"FHIRCode",],
        @[@"type",@"FHIRCodeableConcept",],
        @[@"identifier",@"FHIRIdentifier",],
        @[@"unit",@"FHIRCodeableConcept",],
        @[@"source",@"FHIRReference",],
        @[@"parent",@"FHIRReference",],
        @[@"operationalState",@"FHIRCode",],
        @[@"measurementMode",@"FHIRIdentifier",],
        @[@"color",@"FHIRIdentifier",],
        @[@"category",@"FHIRCode",],
        @[@"measurementPeriod",@"FHIRTiming",],
        @[@"calibrationInfo",@"FHIRDeviceMetricCalibrationInfoComponent",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRDeviceMetricCalibrationInfoComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"type",@"FHIRCode",],
        @[@"state",@"FHIRCode",],
        @[@"time",@"FHIRInstant",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRDeviceUseRequest
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"meta",@"FHIRResourceMetaComponent",],
        @[@"implicitRules",@"FHIRUri",],
        @[@"language",@"FHIRCode",],
        @[@"text",@"FHIRNarrative",],
        @[@"contained",@"FHIRBaseResource",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"bodySite",@"FHIRCodeableConcept",],
        @[@"status",@"FHIRCode",],
        @[@"device",@"FHIRReference",],
        @[@"encounter",@"FHIRReference",],
        @[@"identifier",@"FHIRIdentifier",],
        @[@"indication",@"FHIRCodeableConcept",],
        @[@"notes",@"FHIRString",],
        @[@"prnReason",@"FHIRCodeableConcept",],
        @[@"orderedOn",@"FHIRDateTime",],
        @[@"recordedOn",@"FHIRDateTime",],
        @[@"subject",@"FHIRReference",],
        @[@"timing",@"FHIRElement",],
        @[@"priority",@"FHIRCode",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRDeviceUseStatement
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"meta",@"FHIRResourceMetaComponent",],
        @[@"implicitRules",@"FHIRUri",],
        @[@"language",@"FHIRCode",],
        @[@"text",@"FHIRNarrative",],
        @[@"contained",@"FHIRBaseResource",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"bodySite",@"FHIRCodeableConcept",],
        @[@"whenUsed",@"FHIRPeriod",],
        @[@"device",@"FHIRReference",],
        @[@"identifier",@"FHIRIdentifier",],
        @[@"indication",@"FHIRCodeableConcept",],
        @[@"notes",@"FHIRString",],
        @[@"recordedOn",@"FHIRDateTime",],
        @[@"subject",@"FHIRReference",],
        @[@"timing",@"FHIRElement",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRDiagnosticOrder
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"meta",@"FHIRResourceMetaComponent",],
        @[@"implicitRules",@"FHIRUri",],
        @[@"language",@"FHIRCode",],
        @[@"text",@"FHIRNarrative",],
        @[@"contained",@"FHIRBaseResource",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"subject",@"FHIRReference",],
        @[@"orderer",@"FHIRReference",],
        @[@"identifier",@"FHIRIdentifier",],
        @[@"encounter",@"FHIRReference",],
        @[@"clinicalNotes",@"FHIRString",],
        @[@"supportingInformation",@"FHIRReference",],
        @[@"specimen",@"FHIRReference",],
        @[@"status",@"FHIRCode",],
        @[@"priority",@"FHIRCode",],
        @[@"event_",@"FHIRDiagnosticOrderEventComponent",],
        @[@"item",@"FHIRDiagnosticOrderItemComponent",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRDiagnosticOrderItemComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"code",@"FHIRCodeableConcept",],
        @[@"specimen",@"FHIRReference",],
        @[@"bodySite",@"FHIRCodeableConcept",],
        @[@"status",@"FHIRCode",],
        @[@"event_",@"FHIRDiagnosticOrderEventComponent",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRDiagnosticOrderEventComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"status",@"FHIRCode",],
        @[@"description",@"FHIRCodeableConcept",],
        @[@"dateTime",@"FHIRDateTime",],
        @[@"actor",@"FHIRReference",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRDiagnosticReport
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"meta",@"FHIRResourceMetaComponent",],
        @[@"implicitRules",@"FHIRUri",],
        @[@"language",@"FHIRCode",],
        @[@"text",@"FHIRNarrative",],
        @[@"contained",@"FHIRBaseResource",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"name",@"FHIRCodeableConcept",],
        @[@"status",@"FHIRCode",],
        @[@"issued",@"FHIRDateTime",],
        @[@"subject",@"FHIRReference",],
        @[@"performer",@"FHIRReference",],
        @[@"identifier",@"FHIRIdentifier",],
        @[@"requestDetail",@"FHIRReference",],
        @[@"serviceCategory",@"FHIRCodeableConcept",],
        @[@"diagnostic",@"FHIRElement",],
        @[@"specimen",@"FHIRReference",],
        @[@"result",@"FHIRReference",],
        @[@"imagingStudy",@"FHIRReference",],
        @[@"image",@"FHIRDiagnosticReportImageComponent",],
        @[@"conclusion",@"FHIRString",],
        @[@"codedDiagnosis",@"FHIRCodeableConcept",],
        @[@"presentedForm",@"FHIRAttachment",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRDiagnosticReportImageComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"comment",@"FHIRString",],
        @[@"link",@"FHIRReference",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRDocumentManifest
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"meta",@"FHIRResourceMetaComponent",],
        @[@"implicitRules",@"FHIRUri",],
        @[@"language",@"FHIRCode",],
        @[@"text",@"FHIRNarrative",],
        @[@"contained",@"FHIRBaseResource",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"masterIdentifier",@"FHIRIdentifier",],
        @[@"identifier",@"FHIRIdentifier",],
        @[@"subject",@"FHIRReference",],
        @[@"recipient",@"FHIRReference",],
        @[@"type",@"FHIRCodeableConcept",],
        @[@"author",@"FHIRReference",],
        @[@"created",@"FHIRDateTime",],
        @[@"source",@"FHIRUri",],
        @[@"status",@"FHIRCode",],
        @[@"supercedes",@"FHIRReference",],
        @[@"description",@"FHIRString",],
        @[@"confidentiality",@"FHIRCodeableConcept",],
        @[@"content",@"FHIRReference",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRDocumentReference
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"meta",@"FHIRResourceMetaComponent",],
        @[@"implicitRules",@"FHIRUri",],
        @[@"language",@"FHIRCode",],
        @[@"text",@"FHIRNarrative",],
        @[@"contained",@"FHIRBaseResource",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"masterIdentifier",@"FHIRIdentifier",],
        @[@"identifier",@"FHIRIdentifier",],
        @[@"subject",@"FHIRReference",],
        @[@"type",@"FHIRCodeableConcept",],
        @[@"class_",@"FHIRCodeableConcept",],
        @[@"author",@"FHIRReference",],
        @[@"custodian",@"FHIRReference",],
        @[@"policyManager",@"FHIRUri",],
        @[@"authenticator",@"FHIRReference",],
        @[@"created",@"FHIRDateTime",],
        @[@"indexed",@"FHIRInstant",],
        @[@"status",@"FHIRCode",],
        @[@"docStatus",@"FHIRCodeableConcept",],
        @[@"relatesTo",@"FHIRDocumentReferenceRelatesToComponent",],
        @[@"description",@"FHIRString",],
        @[@"confidentiality",@"FHIRCodeableConcept",],
        @[@"primaryLanguage",@"FHIRCode",],
        @[@"mimeType",@"FHIRCode",],
        @[@"format",@"FHIRUri",],
        @[@"size",@"FHIRInteger",],
        @[@"hash",@"FHIRBase64Binary",],
        @[@"location",@"FHIRUri",],
        @[@"service",@"FHIRDocumentReferenceServiceComponent",],
        @[@"context",@"FHIRDocumentReferenceContextComponent",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRDocumentReferenceContextComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"event_",@"FHIRCodeableConcept",],
        @[@"period",@"FHIRPeriod",],
        @[@"facilityType",@"FHIRCodeableConcept",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRDocumentReferenceRelatesToComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"code",@"FHIRCode",],
        @[@"target",@"FHIRReference",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRDocumentReferenceServiceParameterComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"name",@"FHIRString",],
        @[@"value",@"FHIRString",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRDocumentReferenceServiceComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"type",@"FHIRCodeableConcept",],
        @[@"address",@"FHIRString",],
        @[@"parameter",@"FHIRDocumentReferenceServiceParameterComponent",],
    ];
}

+ (NSArray *)orderPairArrayForFHIREligibilityRequest
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"meta",@"FHIRResourceMetaComponent",],
        @[@"implicitRules",@"FHIRUri",],
        @[@"language",@"FHIRCode",],
        @[@"text",@"FHIRNarrative",],
        @[@"contained",@"FHIRBaseResource",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"identifier",@"FHIRIdentifier",],
        @[@"ruleset",@"FHIRCoding",],
        @[@"originalRuleset",@"FHIRCoding",],
        @[@"created",@"FHIRDateTime",],
        @[@"target",@"FHIRReference",],
        @[@"provider",@"FHIRReference",],
        @[@"organization",@"FHIRReference",],
    ];
}

+ (NSArray *)orderPairArrayForFHIREligibilityResponse
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"meta",@"FHIRResourceMetaComponent",],
        @[@"implicitRules",@"FHIRUri",],
        @[@"language",@"FHIRCode",],
        @[@"text",@"FHIRNarrative",],
        @[@"contained",@"FHIRBaseResource",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"identifier",@"FHIRIdentifier",],
        @[@"request",@"FHIRReference",],
        @[@"outcome",@"FHIRCode",],
        @[@"disposition",@"FHIRString",],
        @[@"ruleset",@"FHIRCoding",],
        @[@"originalRuleset",@"FHIRCoding",],
        @[@"created",@"FHIRDateTime",],
        @[@"organization",@"FHIRReference",],
        @[@"requestProvider",@"FHIRReference",],
        @[@"requestOrganization",@"FHIRReference",],
    ];
}

+ (NSArray *)orderPairArrayForFHIREncounter
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"meta",@"FHIRResourceMetaComponent",],
        @[@"implicitRules",@"FHIRUri",],
        @[@"language",@"FHIRCode",],
        @[@"text",@"FHIRNarrative",],
        @[@"contained",@"FHIRBaseResource",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"identifier",@"FHIRIdentifier",],
        @[@"status",@"FHIRCode",],
        @[@"statusHistory",@"FHIREncounterStatusHistoryComponent",],
        @[@"class_",@"FHIRCode",],
        @[@"type",@"FHIRCodeableConcept",],
        @[@"patient",@"FHIRReference",],
        @[@"episodeOfCare",@"FHIRReference",],
        @[@"participant",@"FHIREncounterParticipantComponent",],
        @[@"fulfills",@"FHIRReference",],
        @[@"period",@"FHIRPeriod",],
        @[@"length",@"FHIRDuration",],
        @[@"reason",@"FHIRCodeableConcept",],
        @[@"indication",@"FHIRReference",],
        @[@"priority",@"FHIRCodeableConcept",],
        @[@"hospitalization",@"FHIREncounterHospitalizationComponent",],
        @[@"location",@"FHIREncounterLocationComponent",],
        @[@"serviceProvider",@"FHIRReference",],
        @[@"partOf",@"FHIRReference",],
    ];
}

+ (NSArray *)orderPairArrayForFHIREncounterHospitalizationComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"preAdmissionIdentifier",@"FHIRIdentifier",],
        @[@"origin",@"FHIRReference",],
        @[@"admitSource",@"FHIRCodeableConcept",],
        @[@"diet",@"FHIRCodeableConcept",],
        @[@"specialCourtesy",@"FHIRCodeableConcept",],
        @[@"specialArrangement",@"FHIRCodeableConcept",],
        @[@"destination",@"FHIRReference",],
        @[@"dischargeDisposition",@"FHIRCodeableConcept",],
        @[@"dischargeDiagnosis",@"FHIRReference",],
        @[@"reAdmission",@"FHIRBoolean",],
    ];
}

+ (NSArray *)orderPairArrayForFHIREncounterStatusHistoryComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"status",@"FHIRCode",],
        @[@"period",@"FHIRPeriod",],
    ];
}

+ (NSArray *)orderPairArrayForFHIREncounterLocationComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"location",@"FHIRReference",],
        @[@"status",@"FHIRCode",],
        @[@"period",@"FHIRPeriod",],
    ];
}

+ (NSArray *)orderPairArrayForFHIREncounterParticipantComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"type",@"FHIRCodeableConcept",],
        @[@"period",@"FHIRPeriod",],
        @[@"individual",@"FHIRReference",],
    ];
}

+ (NSArray *)orderPairArrayForFHIREnrollmentRequest
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"meta",@"FHIRResourceMetaComponent",],
        @[@"implicitRules",@"FHIRUri",],
        @[@"language",@"FHIRCode",],
        @[@"text",@"FHIRNarrative",],
        @[@"contained",@"FHIRBaseResource",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"identifier",@"FHIRIdentifier",],
        @[@"ruleset",@"FHIRCoding",],
        @[@"originalRuleset",@"FHIRCoding",],
        @[@"created",@"FHIRDateTime",],
        @[@"target",@"FHIRReference",],
        @[@"provider",@"FHIRReference",],
        @[@"organization",@"FHIRReference",],
        @[@"subject",@"FHIRReference",],
        @[@"coverage",@"FHIRReference",],
        @[@"relationship",@"FHIRCoding",],
    ];
}

+ (NSArray *)orderPairArrayForFHIREnrollmentResponse
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"meta",@"FHIRResourceMetaComponent",],
        @[@"implicitRules",@"FHIRUri",],
        @[@"language",@"FHIRCode",],
        @[@"text",@"FHIRNarrative",],
        @[@"contained",@"FHIRBaseResource",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"identifier",@"FHIRIdentifier",],
        @[@"request",@"FHIRReference",],
        @[@"outcome",@"FHIRCode",],
        @[@"disposition",@"FHIRString",],
        @[@"ruleset",@"FHIRCoding",],
        @[@"originalRuleset",@"FHIRCoding",],
        @[@"created",@"FHIRDateTime",],
        @[@"organization",@"FHIRReference",],
        @[@"requestProvider",@"FHIRReference",],
        @[@"requestOrganization",@"FHIRReference",],
    ];
}

+ (NSArray *)orderPairArrayForFHIREpisodeOfCare
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"meta",@"FHIRResourceMetaComponent",],
        @[@"implicitRules",@"FHIRUri",],
        @[@"language",@"FHIRCode",],
        @[@"text",@"FHIRNarrative",],
        @[@"contained",@"FHIRBaseResource",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"identifier",@"FHIRIdentifier",],
        @[@"currentStatus",@"FHIRCode",],
        @[@"statusHistory",@"FHIREpisodeOfCareStatusHistoryComponent",],
        @[@"type",@"FHIRCodeableConcept",],
        @[@"patient",@"FHIRReference",],
        @[@"managingOrganization",@"FHIRReference",],
        @[@"period",@"FHIRPeriod",],
        @[@"condition",@"FHIRReference",],
        @[@"referralRequest",@"FHIRReference",],
        @[@"careManager",@"FHIRReference",],
        @[@"careTeam",@"FHIREpisodeOfCareCareTeamComponent",],
    ];
}

+ (NSArray *)orderPairArrayForFHIREpisodeOfCareStatusHistoryComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"status",@"FHIRCode",],
        @[@"period",@"FHIRPeriod",],
    ];
}

+ (NSArray *)orderPairArrayForFHIREpisodeOfCareCareTeamComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"member",@"FHIRReference",],
        @[@"role",@"FHIRCodeableConcept",],
        @[@"period",@"FHIRPeriod",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRExplanationOfBenefit
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"meta",@"FHIRResourceMetaComponent",],
        @[@"implicitRules",@"FHIRUri",],
        @[@"language",@"FHIRCode",],
        @[@"text",@"FHIRNarrative",],
        @[@"contained",@"FHIRBaseResource",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"identifier",@"FHIRIdentifier",],
        @[@"request",@"FHIRReference",],
        @[@"outcome",@"FHIRCode",],
        @[@"disposition",@"FHIRString",],
        @[@"ruleset",@"FHIRCoding",],
        @[@"originalRuleset",@"FHIRCoding",],
        @[@"created",@"FHIRDateTime",],
        @[@"organization",@"FHIRReference",],
        @[@"requestProvider",@"FHIRReference",],
        @[@"requestOrganization",@"FHIRReference",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRExtensionDefinition
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"meta",@"FHIRResourceMetaComponent",],
        @[@"implicitRules",@"FHIRUri",],
        @[@"language",@"FHIRCode",],
        @[@"text",@"FHIRNarrative",],
        @[@"contained",@"FHIRBaseResource",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"url",@"FHIRUri",],
        @[@"identifier",@"FHIRIdentifier",],
        @[@"name",@"FHIRString",],
        @[@"display",@"FHIRString",],
        @[@"publisher",@"FHIRString",],
        @[@"telecom",@"FHIRContactPoint",],
        @[@"description",@"FHIRString",],
        @[@"code",@"FHIRCoding",],
        @[@"status",@"FHIRCode",],
        @[@"experimental",@"FHIRBoolean",],
        @[@"date",@"FHIRDateTime",],
        @[@"requirements",@"FHIRString",],
        @[@"mapping",@"FHIRExtensionDefinitionMappingComponent",],
        @[@"contextType",@"FHIRCode",],
        @[@"context",@"FHIRString",],
        @[@"element",@"FHIRElementDefinition",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRExtensionDefinitionMappingComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"identity",@"FHIRId",],
        @[@"uri",@"FHIRUri",],
        @[@"name",@"FHIRString",],
        @[@"comments",@"FHIRString",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRFamilyHistory
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"meta",@"FHIRResourceMetaComponent",],
        @[@"implicitRules",@"FHIRUri",],
        @[@"language",@"FHIRCode",],
        @[@"text",@"FHIRNarrative",],
        @[@"contained",@"FHIRBaseResource",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"identifier",@"FHIRIdentifier",],
        @[@"patient",@"FHIRReference",],
        @[@"date",@"FHIRDateTime",],
        @[@"note",@"FHIRString",],
        @[@"relation",@"FHIRFamilyHistoryRelationComponent",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRFamilyHistoryRelationConditionComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"type",@"FHIRCodeableConcept",],
        @[@"outcome",@"FHIRCodeableConcept",],
        @[@"onset",@"FHIRElement",],
        @[@"note",@"FHIRString",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRFamilyHistoryRelationComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"name",@"FHIRString",],
        @[@"relationship",@"FHIRCodeableConcept",],
        @[@"born",@"FHIRElement",],
        @[@"age",@"FHIRElement",],
        @[@"deceased",@"FHIRElement",],
        @[@"note",@"FHIRString",],
        @[@"condition",@"FHIRFamilyHistoryRelationConditionComponent",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRGoal
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"meta",@"FHIRResourceMetaComponent",],
        @[@"implicitRules",@"FHIRUri",],
        @[@"language",@"FHIRCode",],
        @[@"text",@"FHIRNarrative",],
        @[@"contained",@"FHIRBaseResource",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"identifier",@"FHIRIdentifier",],
        @[@"patient",@"FHIRReference",],
        @[@"description",@"FHIRString",],
        @[@"status",@"FHIRCode",],
        @[@"notes",@"FHIRString",],
        @[@"concern",@"FHIRReference",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRGroup
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"meta",@"FHIRResourceMetaComponent",],
        @[@"implicitRules",@"FHIRUri",],
        @[@"language",@"FHIRCode",],
        @[@"text",@"FHIRNarrative",],
        @[@"contained",@"FHIRBaseResource",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"identifier",@"FHIRIdentifier",],
        @[@"type",@"FHIRCode",],
        @[@"actual",@"FHIRBoolean",],
        @[@"code",@"FHIRCodeableConcept",],
        @[@"name",@"FHIRString",],
        @[@"quantity",@"FHIRInteger",],
        @[@"characteristic",@"FHIRGroupCharacteristicComponent",],
        @[@"member",@"FHIRReference",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRGroupCharacteristicComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"code",@"FHIRCodeableConcept",],
        @[@"value",@"FHIRElement",],
        @[@"exclude",@"FHIRBoolean",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRHealthcareService
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"meta",@"FHIRResourceMetaComponent",],
        @[@"implicitRules",@"FHIRUri",],
        @[@"language",@"FHIRCode",],
        @[@"text",@"FHIRNarrative",],
        @[@"contained",@"FHIRBaseResource",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"identifier",@"FHIRIdentifier",],
        @[@"location",@"FHIRReference",],
        @[@"serviceCategory",@"FHIRCodeableConcept",],
        @[@"serviceType",@"FHIRServiceTypeComponent",],
        @[@"serviceName",@"FHIRString",],
        @[@"comment",@"FHIRString",],
        @[@"extraDetails",@"FHIRString",],
        @[@"freeProvisionCode",@"FHIRCodeableConcept",],
        @[@"eligibility",@"FHIRCodeableConcept",],
        @[@"eligibilityNote",@"FHIRString",],
        @[@"appointmentRequired",@"FHIRCodeableConcept",],
        @[@"imageURI",@"FHIRUri",],
        @[@"availableTime",@"FHIRHealthcareServiceAvailableTimeComponent",],
        @[@"notAvailableTime",@"FHIRHealthcareServiceNotAvailableTimeComponent",],
        @[@"availabilityExceptions",@"FHIRString",],
        @[@"publicKey",@"FHIRString",],
        @[@"programName",@"FHIRString",],
        @[@"contactPoint",@"FHIRContactPoint",],
        @[@"characteristic",@"FHIRCodeableConcept",],
        @[@"referralMethod",@"FHIRCodeableConcept",],
        @[@"setting",@"FHIRCodeableConcept",],
        @[@"targetGroup",@"FHIRCodeableConcept",],
        @[@"coverageArea",@"FHIRCodeableConcept",],
        @[@"catchmentArea",@"FHIRCodeableConcept",],
        @[@"serviceCode",@"FHIRCodeableConcept",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRServiceTypeComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"type",@"FHIRCodeableConcept",],
        @[@"specialty",@"FHIRCodeableConcept",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRHealthcareServiceAvailableTimeComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"daysOfWeek",@"FHIRCodeableConcept",],
        @[@"allDay",@"FHIRBoolean",],
        @[@"availableStartTime",@"FHIRDateTime",],
        @[@"availableEndTime",@"FHIRDateTime",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRHealthcareServiceNotAvailableTimeComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"description",@"FHIRString",],
        @[@"startDate",@"FHIRDateTime",],
        @[@"endDate",@"FHIRDateTime",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRImagingObjectSelection
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"meta",@"FHIRResourceMetaComponent",],
        @[@"implicitRules",@"FHIRUri",],
        @[@"language",@"FHIRCode",],
        @[@"text",@"FHIRNarrative",],
        @[@"contained",@"FHIRBaseResource",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"uid",@"FHIROid",],
        @[@"patient",@"FHIRReference",],
        @[@"title",@"FHIRCodeableConcept",],
        @[@"description",@"FHIRString",],
        @[@"author",@"FHIRReference",],
        @[@"authoringTime",@"FHIRDateTime",],
        @[@"study",@"FHIRStudyComponent",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRStudyComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"uid",@"FHIROid",],
        @[@"retrieveAETitle",@"FHIRId",],
        @[@"retrieveUrl",@"FHIRUri",],
        @[@"series",@"FHIRSeriesComponent",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRInstanceComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"sopClass",@"FHIROid",],
        @[@"uid",@"FHIROid",],
        @[@"retrieveAETitle",@"FHIRId",],
        @[@"retrieveUrl",@"FHIRUri",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRSeriesComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"uid",@"FHIROid",],
        @[@"retrieveAETitle",@"FHIRId",],
        @[@"retrieveUrl",@"FHIRUri",],
        @[@"instance",@"FHIRInstanceComponent",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRImagingStudy
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"meta",@"FHIRResourceMetaComponent",],
        @[@"implicitRules",@"FHIRUri",],
        @[@"language",@"FHIRCode",],
        @[@"text",@"FHIRNarrative",],
        @[@"contained",@"FHIRBaseResource",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"started",@"FHIRDateTime",],
        @[@"patient",@"FHIRReference",],
        @[@"uid",@"FHIROid",],
        @[@"accession",@"FHIRIdentifier",],
        @[@"identifier",@"FHIRIdentifier",],
        @[@"order",@"FHIRReference",],
        @[@"modalityList",@"FHIRCode",],
        @[@"referrer",@"FHIRReference",],
        @[@"availability",@"FHIRCode",],
        @[@"url",@"FHIRUri",],
        @[@"numberOfSeries",@"FHIRInteger",],
        @[@"numberOfInstances",@"FHIRInteger",],
        @[@"clinicalInformation",@"FHIRString",],
        @[@"procedure",@"FHIRCoding",],
        @[@"interpreter",@"FHIRReference",],
        @[@"description",@"FHIRString",],
        @[@"series",@"FHIRImagingStudySeriesComponent",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRImagingStudySeriesComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"number",@"FHIRInteger",],
        @[@"modality",@"FHIRCode",],
        @[@"uid",@"FHIROid",],
        @[@"description",@"FHIRString",],
        @[@"numberOfInstances",@"FHIRInteger",],
        @[@"availability",@"FHIRCode",],
        @[@"url",@"FHIRUri",],
        @[@"bodySite",@"FHIRCoding",],
        @[@"dateTime",@"FHIRDateTime",],
        @[@"instance",@"FHIRImagingStudySeriesInstanceComponent",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRImagingStudySeriesInstanceComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"number",@"FHIRInteger",],
        @[@"uid",@"FHIROid",],
        @[@"sopclass",@"FHIROid",],
        @[@"type",@"FHIRString",],
        @[@"title",@"FHIRString",],
        @[@"url",@"FHIRUri",],
        @[@"attachment",@"FHIRReference",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRImmunization
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"meta",@"FHIRResourceMetaComponent",],
        @[@"implicitRules",@"FHIRUri",],
        @[@"language",@"FHIRCode",],
        @[@"text",@"FHIRNarrative",],
        @[@"contained",@"FHIRBaseResource",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"identifier",@"FHIRIdentifier",],
        @[@"date",@"FHIRDateTime",],
        @[@"vaccineType",@"FHIRCodeableConcept",],
        @[@"subject",@"FHIRReference",],
        @[@"refusedIndicator",@"FHIRBoolean",],
        @[@"reported",@"FHIRBoolean",],
        @[@"performer",@"FHIRReference",],
        @[@"requester",@"FHIRReference",],
        @[@"manufacturer",@"FHIRReference",],
        @[@"location",@"FHIRReference",],
        @[@"lotNumber",@"FHIRString",],
        @[@"expirationDate",@"FHIRDate",],
        @[@"site",@"FHIRCodeableConcept",],
        @[@"route",@"FHIRCodeableConcept",],
        @[@"doseQuantity",@"FHIRQuantity",],
        @[@"explanation",@"FHIRImmunizationExplanationComponent",],
        @[@"reaction",@"FHIRImmunizationReactionComponent",],
        @[@"vaccinationProtocol",@"FHIRImmunizationVaccinationProtocolComponent",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRImmunizationVaccinationProtocolComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"doseSequence",@"FHIRInteger",],
        @[@"description",@"FHIRString",],
        @[@"authority",@"FHIRReference",],
        @[@"series",@"FHIRString",],
        @[@"seriesDoses",@"FHIRInteger",],
        @[@"doseTarget",@"FHIRCodeableConcept",],
        @[@"doseStatus",@"FHIRCodeableConcept",],
        @[@"doseStatusReason",@"FHIRCodeableConcept",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRImmunizationExplanationComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"reason",@"FHIRCodeableConcept",],
        @[@"refusalReason",@"FHIRCodeableConcept",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRImmunizationReactionComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"date",@"FHIRDateTime",],
        @[@"detail",@"FHIRReference",],
        @[@"reported",@"FHIRBoolean",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRImmunizationRecommendation
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"meta",@"FHIRResourceMetaComponent",],
        @[@"implicitRules",@"FHIRUri",],
        @[@"language",@"FHIRCode",],
        @[@"text",@"FHIRNarrative",],
        @[@"contained",@"FHIRBaseResource",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"identifier",@"FHIRIdentifier",],
        @[@"subject",@"FHIRReference",],
        @[@"recommendation",@"FHIRImmunizationRecommendationRecommendationComponent",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRImmunizationRecommendationRecommendationDateCriterionComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"code",@"FHIRCodeableConcept",],
        @[@"value",@"FHIRDateTime",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRImmunizationRecommendationRecommendationProtocolComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"doseSequence",@"FHIRInteger",],
        @[@"description",@"FHIRString",],
        @[@"authority",@"FHIRReference",],
        @[@"series",@"FHIRString",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRImmunizationRecommendationRecommendationComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"date",@"FHIRDateTime",],
        @[@"vaccineType",@"FHIRCodeableConcept",],
        @[@"doseNumber",@"FHIRInteger",],
        @[@"forecastStatus",@"FHIRCodeableConcept",],
        @[@"dateCriterion",@"FHIRImmunizationRecommendationRecommendationDateCriterionComponent",],
        @[@"protocol",@"FHIRImmunizationRecommendationRecommendationProtocolComponent",],
        @[@"supportingImmunization",@"FHIRReference",],
        @[@"supportingPatientInformation",@"FHIRReference",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRInstitutionalClaim
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"meta",@"FHIRResourceMetaComponent",],
        @[@"implicitRules",@"FHIRUri",],
        @[@"language",@"FHIRCode",],
        @[@"text",@"FHIRNarrative",],
        @[@"contained",@"FHIRBaseResource",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"identifier",@"FHIRIdentifier",],
        @[@"ruleset",@"FHIRCoding",],
        @[@"originalRuleset",@"FHIRCoding",],
        @[@"created",@"FHIRDateTime",],
        @[@"target",@"FHIRReference",],
        @[@"provider",@"FHIRReference",],
        @[@"organization",@"FHIRReference",],
        @[@"use",@"FHIRCode",],
        @[@"priority",@"FHIRCoding",],
        @[@"fundsReserve",@"FHIRCoding",],
        @[@"enterer",@"FHIRReference",],
        @[@"facility",@"FHIRReference",],
        @[@"payee",@"FHIRPayeeComponent",],
        @[@"referral",@"FHIRReference",],
        @[@"diagnosis",@"FHIRDiagnosisComponent",],
        @[@"condition",@"FHIRCoding",],
        @[@"patient",@"FHIRReference",],
        @[@"coverage",@"FHIRCoverageComponent",],
        @[@"exception",@"FHIRCoding",],
        @[@"school",@"FHIRString",],
        @[@"accident",@"FHIRDate",],
        @[@"accidentType",@"FHIRCoding",],
        @[@"interventionException",@"FHIRCoding",],
        @[@"item",@"FHIRItemsComponent",],
        @[@"additionalMaterials",@"FHIRCoding",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRItemsComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"sequence",@"FHIRInteger",],
        @[@"type",@"FHIRCoding",],
        @[@"provider",@"FHIRReference",],
        @[@"diagnosisLinkId",@"FHIRInteger",],
        @[@"service",@"FHIRCoding",],
        @[@"serviceDate",@"FHIRDate",],
        @[@"quantity",@"FHIRQuantity",],
        @[@"unitPrice",@"FHIRMoney",],
        @[@"factor",@"FHIRDecimal",],
        @[@"points",@"FHIRDecimal",],
        @[@"net",@"FHIRMoney",],
        @[@"udi",@"FHIRCoding",],
        @[@"bodySite",@"FHIRCoding",],
        @[@"subsite",@"FHIRCoding",],
        @[@"modifier",@"FHIRCoding",],
        @[@"detail",@"FHIRDetailComponent",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRDetailComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"sequence",@"FHIRInteger",],
        @[@"type",@"FHIRCoding",],
        @[@"service",@"FHIRCoding",],
        @[@"quantity",@"FHIRQuantity",],
        @[@"unitPrice",@"FHIRMoney",],
        @[@"factor",@"FHIRDecimal",],
        @[@"points",@"FHIRDecimal",],
        @[@"net",@"FHIRMoney",],
        @[@"udi",@"FHIRCoding",],
        @[@"subDetail",@"FHIRSubDetailComponent",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRCoverageComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"sequence",@"FHIRInteger",],
        @[@"focal",@"FHIRBoolean",],
        @[@"coverage",@"FHIRReference",],
        @[@"businessArrangement",@"FHIRString",],
        @[@"relationship",@"FHIRCoding",],
        @[@"preauthref",@"FHIRString",],
        @[@"claimResponse",@"FHIRReference",],
        @[@"originalRuleset",@"FHIRCoding",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRPayeeComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"type",@"FHIRCoding",],
        @[@"provider",@"FHIRReference",],
        @[@"organization",@"FHIRReference",],
        @[@"person",@"FHIRReference",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRDiagnosisComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"sequence",@"FHIRInteger",],
        @[@"diagnosis",@"FHIRCoding",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRSubDetailComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"sequence",@"FHIRInteger",],
        @[@"type",@"FHIRCoding",],
        @[@"service",@"FHIRCoding",],
        @[@"quantity",@"FHIRQuantity",],
        @[@"unitPrice",@"FHIRMoney",],
        @[@"factor",@"FHIRDecimal",],
        @[@"points",@"FHIRDecimal",],
        @[@"net",@"FHIRMoney",],
        @[@"udi",@"FHIRCoding",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRList
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"meta",@"FHIRResourceMetaComponent",],
        @[@"implicitRules",@"FHIRUri",],
        @[@"language",@"FHIRCode",],
        @[@"text",@"FHIRNarrative",],
        @[@"contained",@"FHIRBaseResource",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"identifier",@"FHIRIdentifier",],
        @[@"code",@"FHIRCodeableConcept",],
        @[@"subject",@"FHIRReference",],
        @[@"source",@"FHIRReference",],
        @[@"date",@"FHIRDateTime",],
        @[@"ordered",@"FHIRBoolean",],
        @[@"mode",@"FHIRCode",],
        @[@"entry",@"FHIRListEntryComponent",],
        @[@"emptyReason",@"FHIRCodeableConcept",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRListEntryComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"flag",@"FHIRCodeableConcept",],
        @[@"deleted",@"FHIRBoolean",],
        @[@"date",@"FHIRDateTime",],
        @[@"item",@"FHIRReference",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRLocation
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"meta",@"FHIRResourceMetaComponent",],
        @[@"implicitRules",@"FHIRUri",],
        @[@"language",@"FHIRCode",],
        @[@"text",@"FHIRNarrative",],
        @[@"contained",@"FHIRBaseResource",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"identifier",@"FHIRIdentifier",],
        @[@"name",@"FHIRString",],
        @[@"description",@"FHIRString",],
        @[@"type",@"FHIRCodeableConcept",],
        @[@"telecom",@"FHIRContactPoint",],
        @[@"address",@"FHIRAddress",],
        @[@"physicalType",@"FHIRCodeableConcept",],
        @[@"position",@"FHIRLocationPositionComponent",],
        @[@"managingOrganization",@"FHIRReference",],
        @[@"status",@"FHIRCode",],
        @[@"partOf",@"FHIRReference",],
        @[@"mode",@"FHIRCode",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRLocationPositionComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"longitude",@"FHIRDecimal",],
        @[@"latitude",@"FHIRDecimal",],
        @[@"altitude",@"FHIRDecimal",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRMedia
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"meta",@"FHIRResourceMetaComponent",],
        @[@"implicitRules",@"FHIRUri",],
        @[@"language",@"FHIRCode",],
        @[@"text",@"FHIRNarrative",],
        @[@"contained",@"FHIRBaseResource",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"type",@"FHIRCode",],
        @[@"subtype",@"FHIRCodeableConcept",],
        @[@"identifier",@"FHIRIdentifier",],
        @[@"created",@"FHIRDateTime",],
        @[@"subject",@"FHIRReference",],
        @[@"operator_",@"FHIRReference",],
        @[@"view",@"FHIRCodeableConcept",],
        @[@"deviceName",@"FHIRString",],
        @[@"height",@"FHIRInteger",],
        @[@"width",@"FHIRInteger",],
        @[@"frames",@"FHIRInteger",],
        @[@"duration",@"FHIRInteger",],
        @[@"content",@"FHIRAttachment",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRMedication
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"meta",@"FHIRResourceMetaComponent",],
        @[@"implicitRules",@"FHIRUri",],
        @[@"language",@"FHIRCode",],
        @[@"text",@"FHIRNarrative",],
        @[@"contained",@"FHIRBaseResource",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"name",@"FHIRString",],
        @[@"code",@"FHIRCodeableConcept",],
        @[@"isBrand",@"FHIRBoolean",],
        @[@"manufacturer",@"FHIRReference",],
        @[@"kind",@"FHIRCode",],
        @[@"product",@"FHIRMedicationProductComponent",],
        @[@"package",@"FHIRMedicationPackageComponent",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRMedicationPackageContentComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"item",@"FHIRReference",],
        @[@"amount",@"FHIRQuantity",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRMedicationPackageComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"container",@"FHIRCodeableConcept",],
        @[@"content",@"FHIRMedicationPackageContentComponent",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRMedicationProductIngredientComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"item",@"FHIRReference",],
        @[@"amount",@"FHIRRatio",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRMedicationProductComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"form",@"FHIRCodeableConcept",],
        @[@"ingredient",@"FHIRMedicationProductIngredientComponent",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRMedicationAdministration
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"meta",@"FHIRResourceMetaComponent",],
        @[@"implicitRules",@"FHIRUri",],
        @[@"language",@"FHIRCode",],
        @[@"text",@"FHIRNarrative",],
        @[@"contained",@"FHIRBaseResource",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"identifier",@"FHIRIdentifier",],
        @[@"status",@"FHIRCode",],
        @[@"patient",@"FHIRReference",],
        @[@"practitioner",@"FHIRReference",],
        @[@"encounter",@"FHIRReference",],
        @[@"prescription",@"FHIRReference",],
        @[@"wasNotGiven",@"FHIRBoolean",],
        @[@"reasonNotGiven",@"FHIRCodeableConcept",],
        @[@"effectiveTime",@"FHIRElement",],
        @[@"medication",@"FHIRReference",],
        @[@"device",@"FHIRReference",],
        @[@"dosage",@"FHIRMedicationAdministrationDosageComponent",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRMedicationAdministrationDosageComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"timing",@"FHIRElement",],
        @[@"asNeeded",@"FHIRElement",],
        @[@"site",@"FHIRCodeableConcept",],
        @[@"route",@"FHIRCodeableConcept",],
        @[@"method",@"FHIRCodeableConcept",],
        @[@"quantity",@"FHIRQuantity",],
        @[@"rate",@"FHIRRatio",],
        @[@"maxDosePerPeriod",@"FHIRRatio",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRMedicationDispense
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"meta",@"FHIRResourceMetaComponent",],
        @[@"implicitRules",@"FHIRUri",],
        @[@"language",@"FHIRCode",],
        @[@"text",@"FHIRNarrative",],
        @[@"contained",@"FHIRBaseResource",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"identifier",@"FHIRIdentifier",],
        @[@"status",@"FHIRCode",],
        @[@"patient",@"FHIRReference",],
        @[@"dispenser",@"FHIRReference",],
        @[@"authorizingPrescription",@"FHIRReference",],
        @[@"dispense",@"FHIRMedicationDispenseDispenseComponent",],
        @[@"substitution",@"FHIRMedicationDispenseSubstitutionComponent",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRMedicationDispenseDispenseDosageComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"additionalInstructions",@"FHIRCodeableConcept",],
        @[@"schedule",@"FHIRElement",],
        @[@"asNeeded",@"FHIRElement",],
        @[@"site",@"FHIRCodeableConcept",],
        @[@"route",@"FHIRCodeableConcept",],
        @[@"method",@"FHIRCodeableConcept",],
        @[@"quantity",@"FHIRQuantity",],
        @[@"rate",@"FHIRRatio",],
        @[@"maxDosePerPeriod",@"FHIRRatio",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRMedicationDispenseSubstitutionComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"type",@"FHIRCodeableConcept",],
        @[@"reason",@"FHIRCodeableConcept",],
        @[@"responsibleParty",@"FHIRReference",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRMedicationDispenseDispenseComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"identifier",@"FHIRIdentifier",],
        @[@"status",@"FHIRCode",],
        @[@"type",@"FHIRCodeableConcept",],
        @[@"quantity",@"FHIRQuantity",],
        @[@"medication",@"FHIRReference",],
        @[@"whenPrepared",@"FHIRDateTime",],
        @[@"whenHandedOver",@"FHIRDateTime",],
        @[@"destination",@"FHIRReference",],
        @[@"receiver",@"FHIRReference",],
        @[@"dosage",@"FHIRMedicationDispenseDispenseDosageComponent",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRMedicationPrescription
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"meta",@"FHIRResourceMetaComponent",],
        @[@"implicitRules",@"FHIRUri",],
        @[@"language",@"FHIRCode",],
        @[@"text",@"FHIRNarrative",],
        @[@"contained",@"FHIRBaseResource",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"identifier",@"FHIRIdentifier",],
        @[@"dateWritten",@"FHIRDateTime",],
        @[@"status",@"FHIRCode",],
        @[@"patient",@"FHIRReference",],
        @[@"prescriber",@"FHIRReference",],
        @[@"encounter",@"FHIRReference",],
        @[@"reason",@"FHIRElement",],
        @[@"medication",@"FHIRReference",],
        @[@"dosageInstruction",@"FHIRMedicationPrescriptionDosageInstructionComponent",],
        @[@"dispense",@"FHIRMedicationPrescriptionDispenseComponent",],
        @[@"substitution",@"FHIRMedicationPrescriptionSubstitutionComponent",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRMedicationPrescriptionDosageInstructionComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"text",@"FHIRString",],
        @[@"additionalInstructions",@"FHIRCodeableConcept",],
        @[@"scheduled",@"FHIRElement",],
        @[@"asNeeded",@"FHIRElement",],
        @[@"site",@"FHIRCodeableConcept",],
        @[@"route",@"FHIRCodeableConcept",],
        @[@"method",@"FHIRCodeableConcept",],
        @[@"doseQuantity",@"FHIRQuantity",],
        @[@"rate",@"FHIRRatio",],
        @[@"maxDosePerPeriod",@"FHIRRatio",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRMedicationPrescriptionSubstitutionComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"type",@"FHIRCodeableConcept",],
        @[@"reason",@"FHIRCodeableConcept",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRMedicationPrescriptionDispenseComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"medication",@"FHIRReference",],
        @[@"validityPeriod",@"FHIRPeriod",],
        @[@"numberOfRepeatsAllowed",@"FHIRInteger",],
        @[@"quantity",@"FHIRQuantity",],
        @[@"expectedSupplyDuration",@"FHIRDuration",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRMedicationStatement
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"meta",@"FHIRResourceMetaComponent",],
        @[@"implicitRules",@"FHIRUri",],
        @[@"language",@"FHIRCode",],
        @[@"text",@"FHIRNarrative",],
        @[@"contained",@"FHIRBaseResource",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"identifier",@"FHIRIdentifier",],
        @[@"patient",@"FHIRReference",],
        @[@"wasNotGiven",@"FHIRBoolean",],
        @[@"reasonNotGiven",@"FHIRCodeableConcept",],
        @[@"whenGiven",@"FHIRPeriod",],
        @[@"medication",@"FHIRReference",],
        @[@"device",@"FHIRReference",],
        @[@"dosage",@"FHIRMedicationStatementDosageComponent",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRMedicationStatementDosageComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"schedule",@"FHIRTiming",],
        @[@"asNeeded",@"FHIRElement",],
        @[@"site",@"FHIRCodeableConcept",],
        @[@"route",@"FHIRCodeableConcept",],
        @[@"method",@"FHIRCodeableConcept",],
        @[@"quantity",@"FHIRQuantity",],
        @[@"rate",@"FHIRRatio",],
        @[@"maxDosePerPeriod",@"FHIRRatio",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRMessageHeader
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"meta",@"FHIRResourceMetaComponent",],
        @[@"implicitRules",@"FHIRUri",],
        @[@"language",@"FHIRCode",],
        @[@"text",@"FHIRNarrative",],
        @[@"contained",@"FHIRBaseResource",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"identifier",@"FHIRId",],
        @[@"timestamp",@"FHIRInstant",],
        @[@"event_",@"FHIRCoding",],
        @[@"response",@"FHIRMessageHeaderResponseComponent",],
        @[@"source",@"FHIRMessageSourceComponent",],
        @[@"destination",@"FHIRMessageDestinationComponent",],
        @[@"enterer",@"FHIRReference",],
        @[@"author",@"FHIRReference",],
        @[@"receiver",@"FHIRReference",],
        @[@"responsible",@"FHIRReference",],
        @[@"reason",@"FHIRCodeableConcept",],
        @[@"data",@"FHIRReference",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRMessageDestinationComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"name",@"FHIRString",],
        @[@"target",@"FHIRReference",],
        @[@"endpoint",@"FHIRUri",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRMessageSourceComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"name",@"FHIRString",],
        @[@"software",@"FHIRString",],
        @[@"version",@"FHIRString",],
        @[@"contact",@"FHIRContactPoint",],
        @[@"endpoint",@"FHIRUri",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRMessageHeaderResponseComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"identifier",@"FHIRId",],
        @[@"code",@"FHIRCode",],
        @[@"details",@"FHIRReference",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRNamingSystem
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"meta",@"FHIRResourceMetaComponent",],
        @[@"implicitRules",@"FHIRUri",],
        @[@"language",@"FHIRCode",],
        @[@"text",@"FHIRNarrative",],
        @[@"contained",@"FHIRBaseResource",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"type",@"FHIRCode",],
        @[@"name",@"FHIRString",],
        @[@"status",@"FHIRCode",],
        @[@"country",@"FHIRCode",],
        @[@"category",@"FHIRCodeableConcept",],
        @[@"responsible",@"FHIRString",],
        @[@"description",@"FHIRString",],
        @[@"usage",@"FHIRString",],
        @[@"uniqueId",@"FHIRNamingSystemUniqueIdComponent",],
        @[@"contact",@"FHIRNamingSystemContactComponent",],
        @[@"replacedBy",@"FHIRReference",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRNamingSystemContactComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"name",@"FHIRHumanName",],
        @[@"telecom",@"FHIRContactPoint",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRNamingSystemUniqueIdComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"type",@"FHIRCode",],
        @[@"value",@"FHIRString",],
        @[@"preferred",@"FHIRBoolean",],
        @[@"period",@"FHIRPeriod",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRNutritionOrder
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"meta",@"FHIRResourceMetaComponent",],
        @[@"implicitRules",@"FHIRUri",],
        @[@"language",@"FHIRCode",],
        @[@"text",@"FHIRNarrative",],
        @[@"contained",@"FHIRBaseResource",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"subject",@"FHIRReference",],
        @[@"orderer",@"FHIRReference",],
        @[@"identifier",@"FHIRIdentifier",],
        @[@"encounter",@"FHIRReference",],
        @[@"dateTime",@"FHIRDateTime",],
        @[@"allergyIntolerance",@"FHIRReference",],
        @[@"foodPreferenceModifier",@"FHIRCodeableConcept",],
        @[@"excludeFoodModifier",@"FHIRCodeableConcept",],
        @[@"item",@"FHIRNutritionOrderItemComponent",],
        @[@"status",@"FHIRCode",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRNutritionOrderItemSupplementComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"type",@"FHIRCodeableConcept",],
        @[@"quantity",@"FHIRQuantity",],
        @[@"name",@"FHIRString",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRNutritionOrderItemOralDietTextureComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"modifier",@"FHIRCodeableConcept",],
        @[@"foodType",@"FHIRCodeableConcept",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRNutritionOrderItemComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"scheduled",@"FHIRElement",],
        @[@"isInEffect",@"FHIRBoolean",],
        @[@"oralDiet",@"FHIRNutritionOrderItemOralDietComponent",],
        @[@"supplement",@"FHIRNutritionOrderItemSupplementComponent",],
        @[@"enteralFormula",@"FHIRNutritionOrderItemEnteralFormulaComponent",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRNutritionOrderItemEnteralFormulaComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"administrationInstructions",@"FHIRString",],
        @[@"baseFormulaType",@"FHIRCodeableConcept",],
        @[@"baseFormulaName",@"FHIRString",],
        @[@"additiveType",@"FHIRCodeableConcept",],
        @[@"additiveName",@"FHIRString",],
        @[@"caloricDensity",@"FHIRQuantity",],
        @[@"routeofAdministration",@"FHIRCodeableConcept",],
        @[@"quantity",@"FHIRQuantity",],
        @[@"rate",@"FHIRRatio",],
        @[@"rateAdjustment",@"FHIRQuantity",],
        @[@"maxVolumeToDeliver",@"FHIRQuantity",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRNutritionOrderItemOralDietComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"type",@"FHIRCodeableConcept",],
        @[@"nutrients",@"FHIRNutritionOrderItemOralDietNutrientsComponent",],
        @[@"texture",@"FHIRNutritionOrderItemOralDietTextureComponent",],
        @[@"fluidConsistencyType",@"FHIRCodeableConcept",],
        @[@"instruction",@"FHIRString",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRNutritionOrderItemOralDietNutrientsComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"modifier",@"FHIRCodeableConcept",],
        @[@"amount",@"FHIRElement",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRObservation
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"meta",@"FHIRResourceMetaComponent",],
        @[@"implicitRules",@"FHIRUri",],
        @[@"language",@"FHIRCode",],
        @[@"text",@"FHIRNarrative",],
        @[@"contained",@"FHIRBaseResource",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"name",@"FHIRCodeableConcept",],
        @[@"value",@"FHIRElement",],
        @[@"dataAbsentReason",@"FHIRCode",],
        @[@"interpretation",@"FHIRCodeableConcept",],
        @[@"comments",@"FHIRString",],
        @[@"applies",@"FHIRElement",],
        @[@"issued",@"FHIRInstant",],
        @[@"status",@"FHIRCode",],
        @[@"reliability",@"FHIRCode",],
        @[@"bodySite",@"FHIRCodeableConcept",],
        @[@"method",@"FHIRCodeableConcept",],
        @[@"identifier",@"FHIRIdentifier",],
        @[@"subject",@"FHIRReference",],
        @[@"specimen",@"FHIRReference",],
        @[@"performer",@"FHIRReference",],
        @[@"encounter",@"FHIRReference",],
        @[@"referenceRange",@"FHIRObservationReferenceRangeComponent",],
        @[@"related",@"FHIRObservationRelatedComponent",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRObservationReferenceRangeComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"low",@"FHIRQuantity",],
        @[@"high",@"FHIRQuantity",],
        @[@"meaning",@"FHIRCodeableConcept",],
        @[@"age",@"FHIRRange",],
        @[@"text",@"FHIRString",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRObservationRelatedComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"type",@"FHIRCode",],
        @[@"target",@"FHIRReference",],
    ];
}

+ (NSArray *)orderPairArrayForFHIROperationDefinition
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"meta",@"FHIRResourceMetaComponent",],
        @[@"implicitRules",@"FHIRUri",],
        @[@"language",@"FHIRCode",],
        @[@"text",@"FHIRNarrative",],
        @[@"contained",@"FHIRBaseResource",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"identifier",@"FHIRUri",],
        @[@"version",@"FHIRString",],
        @[@"title",@"FHIRString",],
        @[@"publisher",@"FHIRString",],
        @[@"telecom",@"FHIRContactPoint",],
        @[@"description",@"FHIRString",],
        @[@"code",@"FHIRCoding",],
        @[@"status",@"FHIRCode",],
        @[@"experimental",@"FHIRBoolean",],
        @[@"date",@"FHIRDateTime",],
        @[@"kind",@"FHIRCode",],
        @[@"name",@"FHIRCode",],
        @[@"notes",@"FHIRString",],
        @[@"base_",@"FHIRReference",],
        @[@"system",@"FHIRBoolean",],
        @[@"type",@"FHIRCode",],
        @[@"instance",@"FHIRBoolean",],
        @[@"parameter",@"FHIROperationDefinitionParameterComponent",],
    ];
}

+ (NSArray *)orderPairArrayForFHIROperationDefinitionParameterPartComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"name",@"FHIRCode",],
        @[@"min",@"FHIRInteger",],
        @[@"max",@"FHIRString",],
        @[@"documentation",@"FHIRString",],
        @[@"type",@"FHIRCode",],
        @[@"profile",@"FHIRReference",],
    ];
}

+ (NSArray *)orderPairArrayForFHIROperationDefinitionParameterComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"name",@"FHIRCode",],
        @[@"use",@"FHIRCode",],
        @[@"min",@"FHIRInteger",],
        @[@"max",@"FHIRString",],
        @[@"documentation",@"FHIRString",],
        @[@"type",@"FHIRCode",],
        @[@"profile",@"FHIRReference",],
        @[@"part",@"FHIROperationDefinitionParameterPartComponent",],
    ];
}

+ (NSArray *)orderPairArrayForFHIROperationOutcome
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"meta",@"FHIRResourceMetaComponent",],
        @[@"implicitRules",@"FHIRUri",],
        @[@"language",@"FHIRCode",],
        @[@"text",@"FHIRNarrative",],
        @[@"contained",@"FHIRBaseResource",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"issue",@"FHIROperationOutcomeIssueComponent",],
    ];
}

+ (NSArray *)orderPairArrayForFHIROperationOutcomeIssueComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"severity",@"FHIRCode",],
        @[@"type",@"FHIRCoding",],
        @[@"details",@"FHIRString",],
        @[@"location",@"FHIRString",],
    ];
}

+ (NSArray *)orderPairArrayForFHIROralHealthClaim
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"meta",@"FHIRResourceMetaComponent",],
        @[@"implicitRules",@"FHIRUri",],
        @[@"language",@"FHIRCode",],
        @[@"text",@"FHIRNarrative",],
        @[@"contained",@"FHIRBaseResource",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"identifier",@"FHIRIdentifier",],
        @[@"ruleset",@"FHIRCoding",],
        @[@"originalRuleset",@"FHIRCoding",],
        @[@"created",@"FHIRDateTime",],
        @[@"target",@"FHIRReference",],
        @[@"provider",@"FHIRReference",],
        @[@"organization",@"FHIRReference",],
        @[@"use",@"FHIRCode",],
        @[@"priority",@"FHIRCoding",],
        @[@"fundsReserve",@"FHIRCoding",],
        @[@"enterer",@"FHIRReference",],
        @[@"facility",@"FHIRReference",],
        @[@"payee",@"FHIRPayeeComponent",],
        @[@"referral",@"FHIRReference",],
        @[@"diagnosis",@"FHIRDiagnosisComponent",],
        @[@"condition",@"FHIRCoding",],
        @[@"patient",@"FHIRReference",],
        @[@"coverage",@"FHIRCoverageComponent",],
        @[@"exception",@"FHIRCoding",],
        @[@"school",@"FHIRString",],
        @[@"accident",@"FHIRDate",],
        @[@"accidentType",@"FHIRCoding",],
        @[@"interventionException",@"FHIRCoding",],
        @[@"missingteeth",@"FHIRMissingTeethComponent",],
        @[@"orthoPlan",@"FHIROrthodonticPlanComponent",],
        @[@"item",@"FHIRItemsComponent",],
        @[@"additionalMaterials",@"FHIRCoding",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRItemsComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"sequence",@"FHIRInteger",],
        @[@"type",@"FHIRCoding",],
        @[@"provider",@"FHIRReference",],
        @[@"diagnosisLinkId",@"FHIRInteger",],
        @[@"service",@"FHIRCoding",],
        @[@"serviceDate",@"FHIRDate",],
        @[@"quantity",@"FHIRQuantity",],
        @[@"unitPrice",@"FHIRMoney",],
        @[@"factor",@"FHIRDecimal",],
        @[@"points",@"FHIRDecimal",],
        @[@"net",@"FHIRMoney",],
        @[@"udi",@"FHIRCoding",],
        @[@"bodySite",@"FHIRCoding",],
        @[@"subsite",@"FHIRCoding",],
        @[@"modifier",@"FHIRCoding",],
        @[@"detail",@"FHIRDetailComponent",],
        @[@"prosthesis",@"FHIRProsthesisComponent",],
    ];
}

+ (NSArray *)orderPairArrayForFHIROrthodonticPlanComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"start",@"FHIRDate",],
        @[@"examFee",@"FHIRMoney",],
        @[@"diagnosticFee",@"FHIRMoney",],
        @[@"initialPayment",@"FHIRMoney",],
        @[@"durationMonths",@"FHIRInteger",],
        @[@"paymentCount",@"FHIRInteger",],
        @[@"periodicPayment",@"FHIRMoney",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRDetailComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"sequence",@"FHIRInteger",],
        @[@"type",@"FHIRCoding",],
        @[@"service",@"FHIRCoding",],
        @[@"quantity",@"FHIRQuantity",],
        @[@"unitPrice",@"FHIRMoney",],
        @[@"factor",@"FHIRDecimal",],
        @[@"points",@"FHIRDecimal",],
        @[@"net",@"FHIRMoney",],
        @[@"udi",@"FHIRCoding",],
        @[@"subDetail",@"FHIRSubDetailComponent",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRCoverageComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"sequence",@"FHIRInteger",],
        @[@"focal",@"FHIRBoolean",],
        @[@"coverage",@"FHIRReference",],
        @[@"businessArrangement",@"FHIRString",],
        @[@"relationship",@"FHIRCoding",],
        @[@"preauthref",@"FHIRString",],
        @[@"claimResponse",@"FHIRReference",],
        @[@"originalRuleset",@"FHIRCoding",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRPayeeComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"type",@"FHIRCoding",],
        @[@"provider",@"FHIRReference",],
        @[@"organization",@"FHIRReference",],
        @[@"person",@"FHIRReference",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRDiagnosisComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"sequence",@"FHIRInteger",],
        @[@"diagnosis",@"FHIRCoding",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRProsthesisComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"initial",@"FHIRBoolean",],
        @[@"priorDate",@"FHIRDate",],
        @[@"priorMaterial",@"FHIRCoding",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRSubDetailComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"sequence",@"FHIRInteger",],
        @[@"type",@"FHIRCoding",],
        @[@"service",@"FHIRCoding",],
        @[@"quantity",@"FHIRQuantity",],
        @[@"unitPrice",@"FHIRMoney",],
        @[@"factor",@"FHIRDecimal",],
        @[@"points",@"FHIRDecimal",],
        @[@"net",@"FHIRMoney",],
        @[@"udi",@"FHIRCoding",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRMissingTeethComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"tooth",@"FHIRCoding",],
        @[@"reason",@"FHIRCoding",],
        @[@"extractiondate",@"FHIRDate",],
    ];
}

+ (NSArray *)orderPairArrayForFHIROrder
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"meta",@"FHIRResourceMetaComponent",],
        @[@"implicitRules",@"FHIRUri",],
        @[@"language",@"FHIRCode",],
        @[@"text",@"FHIRNarrative",],
        @[@"contained",@"FHIRBaseResource",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"identifier",@"FHIRIdentifier",],
        @[@"date",@"FHIRDateTime",],
        @[@"subject",@"FHIRReference",],
        @[@"source",@"FHIRReference",],
        @[@"target",@"FHIRReference",],
        @[@"reason",@"FHIRElement",],
        @[@"authority",@"FHIRReference",],
        @[@"when",@"FHIROrderWhenComponent",],
        @[@"detail",@"FHIRReference",],
    ];
}

+ (NSArray *)orderPairArrayForFHIROrderWhenComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"code",@"FHIRCodeableConcept",],
        @[@"schedule",@"FHIRTiming",],
    ];
}

+ (NSArray *)orderPairArrayForFHIROrderResponse
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"meta",@"FHIRResourceMetaComponent",],
        @[@"implicitRules",@"FHIRUri",],
        @[@"language",@"FHIRCode",],
        @[@"text",@"FHIRNarrative",],
        @[@"contained",@"FHIRBaseResource",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"identifier",@"FHIRIdentifier",],
        @[@"request",@"FHIRReference",],
        @[@"date",@"FHIRDateTime",],
        @[@"who",@"FHIRReference",],
        @[@"authority",@"FHIRElement",],
        @[@"code",@"FHIRCode",],
        @[@"description",@"FHIRString",],
        @[@"fulfillment",@"FHIRReference",],
    ];
}

+ (NSArray *)orderPairArrayForFHIROrganization
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"meta",@"FHIRResourceMetaComponent",],
        @[@"implicitRules",@"FHIRUri",],
        @[@"language",@"FHIRCode",],
        @[@"text",@"FHIRNarrative",],
        @[@"contained",@"FHIRBaseResource",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"identifier",@"FHIRIdentifier",],
        @[@"name",@"FHIRString",],
        @[@"type",@"FHIRCodeableConcept",],
        @[@"telecom",@"FHIRContactPoint",],
        @[@"address",@"FHIRAddress",],
        @[@"partOf",@"FHIRReference",],
        @[@"contact",@"FHIROrganizationContactComponent",],
        @[@"location",@"FHIRReference",],
        @[@"active",@"FHIRBoolean",],
    ];
}

+ (NSArray *)orderPairArrayForFHIROrganizationContactComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"purpose",@"FHIRCodeableConcept",],
        @[@"name",@"FHIRHumanName",],
        @[@"telecom",@"FHIRContactPoint",],
        @[@"address",@"FHIRAddress",],
        @[@"gender",@"FHIRCode",],
    ];
}

+ (NSArray *)orderPairArrayForFHIROther
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"meta",@"FHIRResourceMetaComponent",],
        @[@"implicitRules",@"FHIRUri",],
        @[@"language",@"FHIRCode",],
        @[@"text",@"FHIRNarrative",],
        @[@"contained",@"FHIRBaseResource",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"identifier",@"FHIRIdentifier",],
        @[@"code",@"FHIRCodeableConcept",],
        @[@"subject",@"FHIRReference",],
        @[@"author",@"FHIRReference",],
        @[@"created",@"FHIRDate",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRPatient
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"meta",@"FHIRResourceMetaComponent",],
        @[@"implicitRules",@"FHIRUri",],
        @[@"language",@"FHIRCode",],
        @[@"text",@"FHIRNarrative",],
        @[@"contained",@"FHIRBaseResource",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"identifier",@"FHIRIdentifier",],
        @[@"name",@"FHIRHumanName",],
        @[@"telecom",@"FHIRContactPoint",],
        @[@"gender",@"FHIRCode",],
        @[@"birthDate",@"FHIRDate",],
        @[@"deceased",@"FHIRElement",],
        @[@"address",@"FHIRAddress",],
        @[@"maritalStatus",@"FHIRCodeableConcept",],
        @[@"multipleBirth",@"FHIRElement",],
        @[@"photo",@"FHIRAttachment",],
        @[@"contact",@"FHIRContactComponent",],
        @[@"animal",@"FHIRAnimalComponent",],
        @[@"communication",@"FHIRCodeableConcept",],
        @[@"careProvider",@"FHIRReference",],
        @[@"managingOrganization",@"FHIRReference",],
        @[@"link",@"FHIRPatientLinkComponent",],
        @[@"active",@"FHIRBoolean",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRContactComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"relationship",@"FHIRCodeableConcept",],
        @[@"name",@"FHIRHumanName",],
        @[@"telecom",@"FHIRContactPoint",],
        @[@"address",@"FHIRAddress",],
        @[@"gender",@"FHIRCode",],
        @[@"organization",@"FHIRReference",],
        @[@"period",@"FHIRPeriod",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRAnimalComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"species",@"FHIRCodeableConcept",],
        @[@"breed",@"FHIRCodeableConcept",],
        @[@"genderStatus",@"FHIRCodeableConcept",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRPatientLinkComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"other",@"FHIRReference",],
        @[@"type",@"FHIRCode",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRPaymentNotice
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"meta",@"FHIRResourceMetaComponent",],
        @[@"implicitRules",@"FHIRUri",],
        @[@"language",@"FHIRCode",],
        @[@"text",@"FHIRNarrative",],
        @[@"contained",@"FHIRBaseResource",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"identifier",@"FHIRIdentifier",],
        @[@"ruleset",@"FHIRCoding",],
        @[@"originalRuleset",@"FHIRCoding",],
        @[@"created",@"FHIRDateTime",],
        @[@"target",@"FHIRReference",],
        @[@"provider",@"FHIRReference",],
        @[@"organization",@"FHIRReference",],
        @[@"request",@"FHIRReference",],
        @[@"response",@"FHIRReference",],
        @[@"paymentStatus",@"FHIRCoding",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRPaymentReconciliation
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"meta",@"FHIRResourceMetaComponent",],
        @[@"implicitRules",@"FHIRUri",],
        @[@"language",@"FHIRCode",],
        @[@"text",@"FHIRNarrative",],
        @[@"contained",@"FHIRBaseResource",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"identifier",@"FHIRIdentifier",],
        @[@"request",@"FHIRReference",],
        @[@"outcome",@"FHIRCode",],
        @[@"disposition",@"FHIRString",],
        @[@"ruleset",@"FHIRCoding",],
        @[@"originalRuleset",@"FHIRCoding",],
        @[@"created",@"FHIRDateTime",],
        @[@"period",@"FHIRPeriod",],
        @[@"organization",@"FHIRReference",],
        @[@"requestProvider",@"FHIRReference",],
        @[@"requestOrganization",@"FHIRReference",],
        @[@"detail",@"FHIRDetailsComponent",],
        @[@"form",@"FHIRCoding",],
        @[@"total",@"FHIRMoney",],
        @[@"note",@"FHIRNotesComponent",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRNotesComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"type",@"FHIRCoding",],
        @[@"text",@"FHIRString",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRDetailsComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"type",@"FHIRCoding",],
        @[@"request",@"FHIRReference",],
        @[@"responce",@"FHIRReference",],
        @[@"submitter",@"FHIRReference",],
        @[@"payee",@"FHIRReference",],
        @[@"date",@"FHIRDate",],
        @[@"amount",@"FHIRMoney",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRPendedRequest
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"meta",@"FHIRResourceMetaComponent",],
        @[@"implicitRules",@"FHIRUri",],
        @[@"language",@"FHIRCode",],
        @[@"text",@"FHIRNarrative",],
        @[@"contained",@"FHIRBaseResource",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"identifier",@"FHIRIdentifier",],
        @[@"ruleset",@"FHIRCoding",],
        @[@"originalRuleset",@"FHIRCoding",],
        @[@"created",@"FHIRDateTime",],
        @[@"target",@"FHIRReference",],
        @[@"provider",@"FHIRReference",],
        @[@"organization",@"FHIRReference",],
        @[@"request",@"FHIRReference",],
        @[@"include",@"FHIRString",],
        @[@"exclude",@"FHIRString",],
        @[@"period",@"FHIRPeriod",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRPerson
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"meta",@"FHIRResourceMetaComponent",],
        @[@"implicitRules",@"FHIRUri",],
        @[@"language",@"FHIRCode",],
        @[@"text",@"FHIRNarrative",],
        @[@"contained",@"FHIRBaseResource",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"identifier",@"FHIRIdentifier",],
        @[@"name",@"FHIRHumanName",],
        @[@"telecom",@"FHIRContactPoint",],
        @[@"gender",@"FHIRCode",],
        @[@"birthDate",@"FHIRDateTime",],
        @[@"address",@"FHIRAddress",],
        @[@"photo",@"FHIRAttachment",],
        @[@"managingOrganization",@"FHIRReference",],
        @[@"active",@"FHIRBoolean",],
        @[@"link",@"FHIRPersonLinkComponent",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRPersonLinkComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"other",@"FHIRReference",],
        @[@"assurance",@"FHIRCode",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRPharmacyClaim
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"meta",@"FHIRResourceMetaComponent",],
        @[@"implicitRules",@"FHIRUri",],
        @[@"language",@"FHIRCode",],
        @[@"text",@"FHIRNarrative",],
        @[@"contained",@"FHIRBaseResource",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"identifier",@"FHIRIdentifier",],
        @[@"ruleset",@"FHIRCoding",],
        @[@"originalRuleset",@"FHIRCoding",],
        @[@"created",@"FHIRDateTime",],
        @[@"target",@"FHIRReference",],
        @[@"provider",@"FHIRReference",],
        @[@"organization",@"FHIRReference",],
        @[@"use",@"FHIRCode",],
        @[@"priority",@"FHIRCoding",],
        @[@"fundsReserve",@"FHIRCoding",],
        @[@"enterer",@"FHIRReference",],
        @[@"facility",@"FHIRReference",],
        @[@"prescription",@"FHIRReference",],
        @[@"originalPrescription",@"FHIRReference",],
        @[@"payee",@"FHIRPayeeComponent",],
        @[@"referral",@"FHIRReference",],
        @[@"diagnosis",@"FHIRDiagnosisComponent",],
        @[@"condition",@"FHIRCoding",],
        @[@"patient",@"FHIRReference",],
        @[@"coverage",@"FHIRCoverageComponent",],
        @[@"exception",@"FHIRCoding",],
        @[@"school",@"FHIRString",],
        @[@"accident",@"FHIRDate",],
        @[@"accidentType",@"FHIRCoding",],
        @[@"interventionException",@"FHIRCoding",],
        @[@"item",@"FHIRItemsComponent",],
        @[@"additionalMaterials",@"FHIRCoding",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRItemsComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"sequence",@"FHIRInteger",],
        @[@"type",@"FHIRCoding",],
        @[@"provider",@"FHIRReference",],
        @[@"diagnosisLinkId",@"FHIRInteger",],
        @[@"service",@"FHIRCoding",],
        @[@"serviceDate",@"FHIRDate",],
        @[@"quantity",@"FHIRQuantity",],
        @[@"unitPrice",@"FHIRMoney",],
        @[@"factor",@"FHIRDecimal",],
        @[@"points",@"FHIRDecimal",],
        @[@"net",@"FHIRMoney",],
        @[@"udi",@"FHIRCoding",],
        @[@"bodySite",@"FHIRCoding",],
        @[@"subsite",@"FHIRCoding",],
        @[@"modifier",@"FHIRCoding",],
        @[@"detail",@"FHIRDetailComponent",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRDetailComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"sequence",@"FHIRInteger",],
        @[@"type",@"FHIRCoding",],
        @[@"service",@"FHIRCoding",],
        @[@"quantity",@"FHIRQuantity",],
        @[@"unitPrice",@"FHIRMoney",],
        @[@"factor",@"FHIRDecimal",],
        @[@"points",@"FHIRDecimal",],
        @[@"net",@"FHIRMoney",],
        @[@"udi",@"FHIRCoding",],
        @[@"subDetail",@"FHIRSubDetailComponent",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRCoverageComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"sequence",@"FHIRInteger",],
        @[@"focal",@"FHIRBoolean",],
        @[@"coverage",@"FHIRReference",],
        @[@"businessArrangement",@"FHIRString",],
        @[@"relationship",@"FHIRCoding",],
        @[@"preauthref",@"FHIRString",],
        @[@"claimResponse",@"FHIRReference",],
        @[@"originalRuleset",@"FHIRCoding",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRPayeeComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"type",@"FHIRCoding",],
        @[@"provider",@"FHIRReference",],
        @[@"organization",@"FHIRReference",],
        @[@"person",@"FHIRReference",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRDiagnosisComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"sequence",@"FHIRInteger",],
        @[@"diagnosis",@"FHIRCoding",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRSubDetailComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"sequence",@"FHIRInteger",],
        @[@"type",@"FHIRCoding",],
        @[@"service",@"FHIRCoding",],
        @[@"quantity",@"FHIRQuantity",],
        @[@"unitPrice",@"FHIRMoney",],
        @[@"factor",@"FHIRDecimal",],
        @[@"points",@"FHIRDecimal",],
        @[@"net",@"FHIRMoney",],
        @[@"udi",@"FHIRCoding",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRPractitioner
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"meta",@"FHIRResourceMetaComponent",],
        @[@"implicitRules",@"FHIRUri",],
        @[@"language",@"FHIRCode",],
        @[@"text",@"FHIRNarrative",],
        @[@"contained",@"FHIRBaseResource",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"identifier",@"FHIRIdentifier",],
        @[@"name",@"FHIRHumanName",],
        @[@"telecom",@"FHIRContactPoint",],
        @[@"address",@"FHIRAddress",],
        @[@"gender",@"FHIRCode",],
        @[@"birthDate",@"FHIRDateTime",],
        @[@"photo",@"FHIRAttachment",],
        @[@"organization",@"FHIRReference",],
        @[@"role",@"FHIRCodeableConcept",],
        @[@"specialty",@"FHIRCodeableConcept",],
        @[@"period",@"FHIRPeriod",],
        @[@"location",@"FHIRReference",],
        @[@"qualification",@"FHIRPractitionerQualificationComponent",],
        @[@"communication",@"FHIRCodeableConcept",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRPractitionerQualificationComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"identifier",@"FHIRIdentifier",],
        @[@"code",@"FHIRCodeableConcept",],
        @[@"period",@"FHIRPeriod",],
        @[@"issuer",@"FHIRReference",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRProcedure
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"meta",@"FHIRResourceMetaComponent",],
        @[@"implicitRules",@"FHIRUri",],
        @[@"language",@"FHIRCode",],
        @[@"text",@"FHIRNarrative",],
        @[@"contained",@"FHIRBaseResource",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"identifier",@"FHIRIdentifier",],
        @[@"patient",@"FHIRReference",],
        @[@"type",@"FHIRCodeableConcept",],
        @[@"bodySite",@"FHIRCodeableConcept",],
        @[@"indication",@"FHIRCodeableConcept",],
        @[@"performer",@"FHIRProcedurePerformerComponent",],
        @[@"date",@"FHIRPeriod",],
        @[@"encounter",@"FHIRReference",],
        @[@"outcome",@"FHIRString",],
        @[@"report",@"FHIRReference",],
        @[@"complication",@"FHIRCodeableConcept",],
        @[@"followUp",@"FHIRString",],
        @[@"relatedItem",@"FHIRProcedureRelatedItemComponent",],
        @[@"notes",@"FHIRString",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRProcedureRelatedItemComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"type",@"FHIRCode",],
        @[@"target",@"FHIRReference",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRProcedurePerformerComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"person",@"FHIRReference",],
        @[@"role",@"FHIRCodeableConcept",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRProcedureRequest
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"meta",@"FHIRResourceMetaComponent",],
        @[@"implicitRules",@"FHIRUri",],
        @[@"language",@"FHIRCode",],
        @[@"text",@"FHIRNarrative",],
        @[@"contained",@"FHIRBaseResource",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"identifier",@"FHIRIdentifier",],
        @[@"subject",@"FHIRReference",],
        @[@"type",@"FHIRCodeableConcept",],
        @[@"bodySite",@"FHIRCodeableConcept",],
        @[@"indication",@"FHIRCodeableConcept",],
        @[@"timing",@"FHIRElement",],
        @[@"encounter",@"FHIRReference",],
        @[@"performer",@"FHIRReference",],
        @[@"status",@"FHIRCode",],
        @[@"notes",@"FHIRString",],
        @[@"asNeeded",@"FHIRElement",],
        @[@"orderedOn",@"FHIRDateTime",],
        @[@"orderer",@"FHIRReference",],
        @[@"priority",@"FHIRCode",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRProfessionalClaim
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"meta",@"FHIRResourceMetaComponent",],
        @[@"implicitRules",@"FHIRUri",],
        @[@"language",@"FHIRCode",],
        @[@"text",@"FHIRNarrative",],
        @[@"contained",@"FHIRBaseResource",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"identifier",@"FHIRIdentifier",],
        @[@"ruleset",@"FHIRCoding",],
        @[@"originalRuleset",@"FHIRCoding",],
        @[@"created",@"FHIRDateTime",],
        @[@"target",@"FHIRReference",],
        @[@"provider",@"FHIRReference",],
        @[@"organization",@"FHIRReference",],
        @[@"use",@"FHIRCode",],
        @[@"priority",@"FHIRCoding",],
        @[@"fundsReserve",@"FHIRCoding",],
        @[@"enterer",@"FHIRReference",],
        @[@"facility",@"FHIRReference",],
        @[@"payee",@"FHIRPayeeComponent",],
        @[@"referral",@"FHIRReference",],
        @[@"diagnosis",@"FHIRDiagnosisComponent",],
        @[@"condition",@"FHIRCoding",],
        @[@"patient",@"FHIRReference",],
        @[@"coverage",@"FHIRCoverageComponent",],
        @[@"exception",@"FHIRCoding",],
        @[@"school",@"FHIRString",],
        @[@"accident",@"FHIRDate",],
        @[@"accidentType",@"FHIRCoding",],
        @[@"interventionException",@"FHIRCoding",],
        @[@"item",@"FHIRItemsComponent",],
        @[@"additionalMaterials",@"FHIRCoding",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRItemsComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"sequence",@"FHIRInteger",],
        @[@"type",@"FHIRCoding",],
        @[@"provider",@"FHIRReference",],
        @[@"diagnosisLinkId",@"FHIRInteger",],
        @[@"service",@"FHIRCoding",],
        @[@"serviceDate",@"FHIRDate",],
        @[@"quantity",@"FHIRQuantity",],
        @[@"unitPrice",@"FHIRMoney",],
        @[@"factor",@"FHIRDecimal",],
        @[@"points",@"FHIRDecimal",],
        @[@"net",@"FHIRMoney",],
        @[@"udi",@"FHIRCoding",],
        @[@"bodySite",@"FHIRCoding",],
        @[@"subsite",@"FHIRCoding",],
        @[@"modifier",@"FHIRCoding",],
        @[@"detail",@"FHIRDetailComponent",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRDetailComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"sequence",@"FHIRInteger",],
        @[@"type",@"FHIRCoding",],
        @[@"service",@"FHIRCoding",],
        @[@"quantity",@"FHIRQuantity",],
        @[@"unitPrice",@"FHIRMoney",],
        @[@"factor",@"FHIRDecimal",],
        @[@"points",@"FHIRDecimal",],
        @[@"net",@"FHIRMoney",],
        @[@"udi",@"FHIRCoding",],
        @[@"subDetail",@"FHIRSubDetailComponent",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRCoverageComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"sequence",@"FHIRInteger",],
        @[@"focal",@"FHIRBoolean",],
        @[@"coverage",@"FHIRReference",],
        @[@"businessArrangement",@"FHIRString",],
        @[@"relationship",@"FHIRCoding",],
        @[@"preauthref",@"FHIRString",],
        @[@"claimResponse",@"FHIRReference",],
        @[@"originalRuleset",@"FHIRCoding",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRPayeeComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"type",@"FHIRCoding",],
        @[@"provider",@"FHIRReference",],
        @[@"organization",@"FHIRReference",],
        @[@"person",@"FHIRReference",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRDiagnosisComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"sequence",@"FHIRInteger",],
        @[@"diagnosis",@"FHIRCoding",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRSubDetailComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"sequence",@"FHIRInteger",],
        @[@"type",@"FHIRCoding",],
        @[@"service",@"FHIRCoding",],
        @[@"quantity",@"FHIRQuantity",],
        @[@"unitPrice",@"FHIRMoney",],
        @[@"factor",@"FHIRDecimal",],
        @[@"points",@"FHIRDecimal",],
        @[@"net",@"FHIRMoney",],
        @[@"udi",@"FHIRCoding",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRProfile
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"meta",@"FHIRResourceMetaComponent",],
        @[@"implicitRules",@"FHIRUri",],
        @[@"language",@"FHIRCode",],
        @[@"text",@"FHIRNarrative",],
        @[@"contained",@"FHIRBaseResource",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"url",@"FHIRUri",],
        @[@"identifier",@"FHIRIdentifier",],
        @[@"version",@"FHIRString",],
        @[@"name",@"FHIRString",],
        @[@"publisher",@"FHIRString",],
        @[@"telecom",@"FHIRContactPoint",],
        @[@"description",@"FHIRString",],
        @[@"code",@"FHIRCoding",],
        @[@"status",@"FHIRCode",],
        @[@"experimental",@"FHIRBoolean",],
        @[@"date",@"FHIRDateTime",],
        @[@"requirements",@"FHIRString",],
        @[@"fhirVersion",@"FHIRId",],
        @[@"mapping",@"FHIRProfileMappingComponent",],
        @[@"type",@"FHIRCode",],
        @[@"base_",@"FHIRUri",],
        @[@"snapshot",@"FHIRConstraintComponent",],
        @[@"differential",@"FHIRConstraintComponent",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRConstraintComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"element",@"FHIRElementDefinition",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRProfileMappingComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"identity",@"FHIRId",],
        @[@"uri",@"FHIRUri",],
        @[@"name",@"FHIRString",],
        @[@"comments",@"FHIRString",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRProvenance
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"meta",@"FHIRResourceMetaComponent",],
        @[@"implicitRules",@"FHIRUri",],
        @[@"language",@"FHIRCode",],
        @[@"text",@"FHIRNarrative",],
        @[@"contained",@"FHIRBaseResource",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"target",@"FHIRReference",],
        @[@"period",@"FHIRPeriod",],
        @[@"recorded",@"FHIRInstant",],
        @[@"reason",@"FHIRCodeableConcept",],
        @[@"location",@"FHIRReference",],
        @[@"policy",@"FHIRUri",],
        @[@"agent",@"FHIRProvenanceAgentComponent",],
        @[@"entity",@"FHIRProvenanceEntityComponent",],
        @[@"integritySignature",@"FHIRString",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRProvenanceAgentComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"role",@"FHIRCoding",],
        @[@"type",@"FHIRCoding",],
        @[@"reference",@"FHIRUri",],
        @[@"display",@"FHIRString",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRProvenanceEntityComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"role",@"FHIRCode",],
        @[@"type",@"FHIRCoding",],
        @[@"reference",@"FHIRUri",],
        @[@"display",@"FHIRString",],
        @[@"agent",@"FHIRProvenanceAgentComponent",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRQuestionnaire
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"meta",@"FHIRResourceMetaComponent",],
        @[@"implicitRules",@"FHIRUri",],
        @[@"language",@"FHIRCode",],
        @[@"text",@"FHIRNarrative",],
        @[@"contained",@"FHIRBaseResource",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"identifier",@"FHIRIdentifier",],
        @[@"version",@"FHIRString",],
        @[@"status",@"FHIRCode",],
        @[@"date",@"FHIRDateTime",],
        @[@"publisher",@"FHIRString",],
        @[@"group",@"FHIRGroupComponent",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRQuestionComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"linkId",@"FHIRString",],
        @[@"concept",@"FHIRCoding",],
        @[@"text",@"FHIRString",],
        @[@"type",@"FHIRCode",],
        @[@"required",@"FHIRBoolean",],
        @[@"repeats",@"FHIRBoolean",],
        @[@"options",@"FHIRReference",],
        @[@"group",@"FHIRGroupComponent",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRGroupComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"linkId",@"FHIRString",],
        @[@"title",@"FHIRString",],
        @[@"concept",@"FHIRCoding",],
        @[@"text",@"FHIRString",],
        @[@"required",@"FHIRBoolean",],
        @[@"repeats",@"FHIRBoolean",],
        @[@"group",@"FHIRGroupComponent",],
        @[@"question",@"FHIRQuestionComponent",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRQuestionnaireAnswers
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"meta",@"FHIRResourceMetaComponent",],
        @[@"implicitRules",@"FHIRUri",],
        @[@"language",@"FHIRCode",],
        @[@"text",@"FHIRNarrative",],
        @[@"contained",@"FHIRBaseResource",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"identifier",@"FHIRIdentifier",],
        @[@"questionnaire",@"FHIRReference",],
        @[@"status",@"FHIRCode",],
        @[@"subject",@"FHIRReference",],
        @[@"author",@"FHIRReference",],
        @[@"authored",@"FHIRDateTime",],
        @[@"source",@"FHIRReference",],
        @[@"encounter",@"FHIRReference",],
        @[@"group",@"FHIRGroupComponent",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRQuestionAnswerComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"value",@"FHIRElement",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRQuestionComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"linkId",@"FHIRString",],
        @[@"text",@"FHIRString",],
        @[@"answer",@"FHIRQuestionAnswerComponent",],
        @[@"group",@"FHIRGroupComponent",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRGroupComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"linkId",@"FHIRString",],
        @[@"title",@"FHIRString",],
        @[@"text",@"FHIRString",],
        @[@"subject",@"FHIRReference",],
        @[@"group",@"FHIRGroupComponent",],
        @[@"question",@"FHIRQuestionComponent",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRReadjudicate
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"meta",@"FHIRResourceMetaComponent",],
        @[@"implicitRules",@"FHIRUri",],
        @[@"language",@"FHIRCode",],
        @[@"text",@"FHIRNarrative",],
        @[@"contained",@"FHIRBaseResource",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"identifier",@"FHIRIdentifier",],
        @[@"ruleset",@"FHIRCoding",],
        @[@"originalRuleset",@"FHIRCoding",],
        @[@"created",@"FHIRDateTime",],
        @[@"target",@"FHIRReference",],
        @[@"provider",@"FHIRReference",],
        @[@"organization",@"FHIRReference",],
        @[@"request",@"FHIRReference",],
        @[@"response",@"FHIRReference",],
        @[@"reference",@"FHIRString",],
        @[@"item",@"FHIRItemsComponent",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRItemsComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"sequenceLinkId",@"FHIRInteger",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRReferralRequest
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"meta",@"FHIRResourceMetaComponent",],
        @[@"implicitRules",@"FHIRUri",],
        @[@"language",@"FHIRCode",],
        @[@"text",@"FHIRNarrative",],
        @[@"contained",@"FHIRBaseResource",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"status",@"FHIRCode",],
        @[@"identifier",@"FHIRIdentifier",],
        @[@"type",@"FHIRCodeableConcept",],
        @[@"specialty",@"FHIRCodeableConcept",],
        @[@"priority",@"FHIRCodeableConcept",],
        @[@"patient",@"FHIRReference",],
        @[@"requester",@"FHIRReference",],
        @[@"recipient",@"FHIRReference",],
        @[@"encounter",@"FHIRReference",],
        @[@"dateSent",@"FHIRDateTime",],
        @[@"reason",@"FHIRCodeableConcept",],
        @[@"description",@"FHIRString",],
        @[@"serviceRequested",@"FHIRCodeableConcept",],
        @[@"supportingInformation",@"FHIRReference",],
        @[@"fulfillmentTime",@"FHIRPeriod",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRRelatedPerson
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"meta",@"FHIRResourceMetaComponent",],
        @[@"implicitRules",@"FHIRUri",],
        @[@"language",@"FHIRCode",],
        @[@"text",@"FHIRNarrative",],
        @[@"contained",@"FHIRBaseResource",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"identifier",@"FHIRIdentifier",],
        @[@"patient",@"FHIRReference",],
        @[@"relationship",@"FHIRCodeableConcept",],
        @[@"name",@"FHIRHumanName",],
        @[@"telecom",@"FHIRContactPoint",],
        @[@"gender",@"FHIRCode",],
        @[@"address",@"FHIRAddress",],
        @[@"photo",@"FHIRAttachment",],
        @[@"period",@"FHIRPeriod",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRReversal
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"meta",@"FHIRResourceMetaComponent",],
        @[@"implicitRules",@"FHIRUri",],
        @[@"language",@"FHIRCode",],
        @[@"text",@"FHIRNarrative",],
        @[@"contained",@"FHIRBaseResource",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"identifier",@"FHIRIdentifier",],
        @[@"ruleset",@"FHIRCoding",],
        @[@"originalRuleset",@"FHIRCoding",],
        @[@"created",@"FHIRDateTime",],
        @[@"target",@"FHIRReference",],
        @[@"provider",@"FHIRReference",],
        @[@"organization",@"FHIRReference",],
        @[@"request",@"FHIRReference",],
        @[@"response",@"FHIRReference",],
        @[@"payee",@"FHIRPayeeComponent",],
        @[@"coverage",@"FHIRReversalCoverageComponent",],
        @[@"nullify",@"FHIRBoolean",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRPayeeComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"type",@"FHIRCoding",],
        @[@"provider",@"FHIRReference",],
        @[@"organization",@"FHIRReference",],
        @[@"person",@"FHIRReference",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRReversalCoverageComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"sequence",@"FHIRInteger",],
        @[@"focal",@"FHIRBoolean",],
        @[@"coverage",@"FHIRReference",],
        @[@"businessArrangement",@"FHIRString",],
        @[@"relationship",@"FHIRCoding",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRRiskAssessment
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"meta",@"FHIRResourceMetaComponent",],
        @[@"implicitRules",@"FHIRUri",],
        @[@"language",@"FHIRCode",],
        @[@"text",@"FHIRNarrative",],
        @[@"contained",@"FHIRBaseResource",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"subject",@"FHIRReference",],
        @[@"date",@"FHIRDateTime",],
        @[@"condition",@"FHIRReference",],
        @[@"performer",@"FHIRReference",],
        @[@"identifier",@"FHIRIdentifier",],
        @[@"method",@"FHIRCodeableConcept",],
        @[@"basis",@"FHIRReference",],
        @[@"prediction",@"FHIRRiskAssessmentPredictionComponent",],
        @[@"mitigation",@"FHIRString",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRRiskAssessmentPredictionComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"outcome",@"FHIRCodeableConcept",],
        @[@"probability",@"FHIRElement",],
        @[@"relativeRisk",@"FHIRDecimal",],
        @[@"when",@"FHIRElement",],
        @[@"rationale",@"FHIRString",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRSchedule
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"meta",@"FHIRResourceMetaComponent",],
        @[@"implicitRules",@"FHIRUri",],
        @[@"language",@"FHIRCode",],
        @[@"text",@"FHIRNarrative",],
        @[@"contained",@"FHIRBaseResource",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"identifier",@"FHIRIdentifier",],
        @[@"type",@"FHIRCodeableConcept",],
        @[@"actor",@"FHIRReference",],
        @[@"planningHorizon",@"FHIRPeriod",],
        @[@"comment",@"FHIRString",],
        @[@"lastModified",@"FHIRDateTime",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRSearchParameter
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"meta",@"FHIRResourceMetaComponent",],
        @[@"implicitRules",@"FHIRUri",],
        @[@"language",@"FHIRCode",],
        @[@"text",@"FHIRNarrative",],
        @[@"contained",@"FHIRBaseResource",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"url",@"FHIRUri",],
        @[@"name",@"FHIRString",],
        @[@"publisher",@"FHIRString",],
        @[@"telecom",@"FHIRContactPoint",],
        @[@"requirements",@"FHIRString",],
        @[@"base_",@"FHIRCode",],
        @[@"type",@"FHIRCode",],
        @[@"description",@"FHIRString",],
        @[@"xpath",@"FHIRString",],
        @[@"target",@"FHIRCode",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRSecurityEvent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"meta",@"FHIRResourceMetaComponent",],
        @[@"implicitRules",@"FHIRUri",],
        @[@"language",@"FHIRCode",],
        @[@"text",@"FHIRNarrative",],
        @[@"contained",@"FHIRBaseResource",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"event_",@"FHIRSecurityEventEventComponent",],
        @[@"participant",@"FHIRSecurityEventParticipantComponent",],
        @[@"source",@"FHIRSecurityEventSourceComponent",],
        @[@"object_",@"FHIRSecurityEventObjectComponent",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRSecurityEventObjectDetailComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"type",@"FHIRString",],
        @[@"value",@"FHIRBase64Binary",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRSecurityEventObjectComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"identifier",@"FHIRIdentifier",],
        @[@"reference",@"FHIRReference",],
        @[@"type",@"FHIRCode",],
        @[@"role",@"FHIRCode",],
        @[@"lifecycle",@"FHIRCode",],
        @[@"sensitivity",@"FHIRCodeableConcept",],
        @[@"name",@"FHIRString",],
        @[@"description",@"FHIRString",],
        @[@"query",@"FHIRBase64Binary",],
        @[@"detail",@"FHIRSecurityEventObjectDetailComponent",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRSecurityEventSourceComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"site",@"FHIRString",],
        @[@"identifier",@"FHIRString",],
        @[@"type",@"FHIRCoding",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRSecurityEventEventComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"type",@"FHIRCodeableConcept",],
        @[@"subtype",@"FHIRCodeableConcept",],
        @[@"action",@"FHIRCode",],
        @[@"dateTime",@"FHIRInstant",],
        @[@"outcome",@"FHIRCode",],
        @[@"outcomeDesc",@"FHIRString",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRSecurityEventParticipantNetworkComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"identifier",@"FHIRString",],
        @[@"type",@"FHIRCode",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRSecurityEventParticipantComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"role",@"FHIRCodeableConcept",],
        @[@"reference",@"FHIRReference",],
        @[@"userId",@"FHIRString",],
        @[@"altId",@"FHIRString",],
        @[@"name",@"FHIRString",],
        @[@"requestor",@"FHIRBoolean",],
        @[@"media",@"FHIRCoding",],
        @[@"network",@"FHIRSecurityEventParticipantNetworkComponent",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRSlot
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"meta",@"FHIRResourceMetaComponent",],
        @[@"implicitRules",@"FHIRUri",],
        @[@"language",@"FHIRCode",],
        @[@"text",@"FHIRNarrative",],
        @[@"contained",@"FHIRBaseResource",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"identifier",@"FHIRIdentifier",],
        @[@"type",@"FHIRCodeableConcept",],
        @[@"schedule",@"FHIRReference",],
        @[@"freeBusyType",@"FHIRCode",],
        @[@"start",@"FHIRInstant",],
        @[@"end",@"FHIRInstant",],
        @[@"overbooked",@"FHIRBoolean",],
        @[@"comment",@"FHIRString",],
        @[@"lastModified",@"FHIRDateTime",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRSpecimen
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"meta",@"FHIRResourceMetaComponent",],
        @[@"implicitRules",@"FHIRUri",],
        @[@"language",@"FHIRCode",],
        @[@"text",@"FHIRNarrative",],
        @[@"contained",@"FHIRBaseResource",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"identifier",@"FHIRIdentifier",],
        @[@"type",@"FHIRCodeableConcept",],
        @[@"source",@"FHIRSpecimenSourceComponent",],
        @[@"subject",@"FHIRReference",],
        @[@"accessionIdentifier",@"FHIRIdentifier",],
        @[@"receivedTime",@"FHIRDateTime",],
        @[@"collection",@"FHIRSpecimenCollectionComponent",],
        @[@"treatment",@"FHIRSpecimenTreatmentComponent",],
        @[@"container",@"FHIRSpecimenContainerComponent",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRSpecimenCollectionComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"collector",@"FHIRReference",],
        @[@"comment",@"FHIRString",],
        @[@"collected",@"FHIRElement",],
        @[@"quantity",@"FHIRQuantity",],
        @[@"method",@"FHIRCodeableConcept",],
        @[@"sourceSite",@"FHIRCodeableConcept",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRSpecimenSourceComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"relationship",@"FHIRCode",],
        @[@"target",@"FHIRReference",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRSpecimenTreatmentComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"description",@"FHIRString",],
        @[@"procedure",@"FHIRCodeableConcept",],
        @[@"additive",@"FHIRReference",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRSpecimenContainerComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"identifier",@"FHIRIdentifier",],
        @[@"description",@"FHIRString",],
        @[@"type",@"FHIRCodeableConcept",],
        @[@"capacity",@"FHIRQuantity",],
        @[@"specimenQuantity",@"FHIRQuantity",],
        @[@"additive",@"FHIRElement",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRStatusRequest
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"meta",@"FHIRResourceMetaComponent",],
        @[@"implicitRules",@"FHIRUri",],
        @[@"language",@"FHIRCode",],
        @[@"text",@"FHIRNarrative",],
        @[@"contained",@"FHIRBaseResource",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"identifier",@"FHIRIdentifier",],
        @[@"ruleset",@"FHIRCoding",],
        @[@"originalRuleset",@"FHIRCoding",],
        @[@"created",@"FHIRDateTime",],
        @[@"target",@"FHIRReference",],
        @[@"provider",@"FHIRReference",],
        @[@"organization",@"FHIRReference",],
        @[@"request",@"FHIRReference",],
        @[@"response",@"FHIRReference",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRStatusResponse
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"meta",@"FHIRResourceMetaComponent",],
        @[@"implicitRules",@"FHIRUri",],
        @[@"language",@"FHIRCode",],
        @[@"text",@"FHIRNarrative",],
        @[@"contained",@"FHIRBaseResource",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"identifier",@"FHIRIdentifier",],
        @[@"request",@"FHIRReference",],
        @[@"outcome",@"FHIRCoding",],
        @[@"disposition",@"FHIRString",],
        @[@"ruleset",@"FHIRCoding",],
        @[@"originalRuleset",@"FHIRCoding",],
        @[@"created",@"FHIRDateTime",],
        @[@"organization",@"FHIRReference",],
        @[@"requestProvider",@"FHIRReference",],
        @[@"requestOrganization",@"FHIRReference",],
        @[@"form",@"FHIRCoding",],
        @[@"notes",@"FHIRStatusResponseNotesComponent",],
        @[@"error",@"FHIRCoding",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRStatusResponseNotesComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"type",@"FHIRCoding",],
        @[@"text",@"FHIRString",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRSubscription
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"meta",@"FHIRResourceMetaComponent",],
        @[@"implicitRules",@"FHIRUri",],
        @[@"language",@"FHIRCode",],
        @[@"text",@"FHIRNarrative",],
        @[@"contained",@"FHIRBaseResource",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"criteria",@"FHIRString",],
        @[@"contact",@"FHIRContactPoint",],
        @[@"reason",@"FHIRString",],
        @[@"status",@"FHIRCode",],
        @[@"error",@"FHIRString",],
        @[@"channel",@"FHIRSubscriptionChannelComponent",],
        @[@"end",@"FHIRInstant",],
        @[@"tag",@"FHIRSubscriptionTagComponent",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRSubscriptionChannelComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"type",@"FHIRCode",],
        @[@"url",@"FHIRUri",],
        @[@"payload",@"FHIRString",],
        @[@"header",@"FHIRString",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRSubscriptionTagComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"term",@"FHIRUri",],
        @[@"scheme",@"FHIRUri",],
        @[@"description",@"FHIRString",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRSubstance
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"meta",@"FHIRResourceMetaComponent",],
        @[@"implicitRules",@"FHIRUri",],
        @[@"language",@"FHIRCode",],
        @[@"text",@"FHIRNarrative",],
        @[@"contained",@"FHIRBaseResource",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"type",@"FHIRCodeableConcept",],
        @[@"description",@"FHIRString",],
        @[@"instance",@"FHIRSubstanceInstanceComponent",],
        @[@"ingredient",@"FHIRSubstanceIngredientComponent",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRSubstanceIngredientComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"quantity",@"FHIRRatio",],
        @[@"substance",@"FHIRReference",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRSubstanceInstanceComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"identifier",@"FHIRIdentifier",],
        @[@"expiry",@"FHIRDateTime",],
        @[@"quantity",@"FHIRQuantity",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRSupply
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"meta",@"FHIRResourceMetaComponent",],
        @[@"implicitRules",@"FHIRUri",],
        @[@"language",@"FHIRCode",],
        @[@"text",@"FHIRNarrative",],
        @[@"contained",@"FHIRBaseResource",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"kind",@"FHIRCodeableConcept",],
        @[@"identifier",@"FHIRIdentifier",],
        @[@"status",@"FHIRCode",],
        @[@"orderedItem",@"FHIRReference",],
        @[@"patient",@"FHIRReference",],
        @[@"dispense",@"FHIRSupplyDispenseComponent",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRSupplyDispenseComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"identifier",@"FHIRIdentifier",],
        @[@"status",@"FHIRCode",],
        @[@"type",@"FHIRCodeableConcept",],
        @[@"quantity",@"FHIRQuantity",],
        @[@"suppliedItem",@"FHIRReference",],
        @[@"supplier",@"FHIRReference",],
        @[@"whenPrepared",@"FHIRPeriod",],
        @[@"whenHandedOver",@"FHIRPeriod",],
        @[@"destination",@"FHIRReference",],
        @[@"receiver",@"FHIRReference",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRSupportingDocumentation
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"meta",@"FHIRResourceMetaComponent",],
        @[@"implicitRules",@"FHIRUri",],
        @[@"language",@"FHIRCode",],
        @[@"text",@"FHIRNarrative",],
        @[@"contained",@"FHIRBaseResource",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"identifier",@"FHIRIdentifier",],
        @[@"ruleset",@"FHIRCoding",],
        @[@"originalRuleset",@"FHIRCoding",],
        @[@"created",@"FHIRDateTime",],
        @[@"target",@"FHIRReference",],
        @[@"provider",@"FHIRReference",],
        @[@"organization",@"FHIRReference",],
        @[@"request",@"FHIRReference",],
        @[@"response",@"FHIRReference",],
        @[@"author",@"FHIRReference",],
        @[@"subject",@"FHIRReference",],
        @[@"detail",@"FHIRSupportingDocumentationDetailComponent",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRSupportingDocumentationDetailComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"linkId",@"FHIRInteger",],
        @[@"content",@"FHIRElement",],
        @[@"dateTime",@"FHIRDateTime",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRValueSet
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"meta",@"FHIRResourceMetaComponent",],
        @[@"implicitRules",@"FHIRUri",],
        @[@"language",@"FHIRCode",],
        @[@"text",@"FHIRNarrative",],
        @[@"contained",@"FHIRBaseResource",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"identifier",@"FHIRUri",],
        @[@"version",@"FHIRString",],
        @[@"name",@"FHIRString",],
        @[@"purpose",@"FHIRString",],
        @[@"immutable",@"FHIRBoolean",],
        @[@"publisher",@"FHIRString",],
        @[@"telecom",@"FHIRContactPoint",],
        @[@"description",@"FHIRString",],
        @[@"copyright",@"FHIRString",],
        @[@"status",@"FHIRCode",],
        @[@"experimental",@"FHIRBoolean",],
        @[@"extensible",@"FHIRBoolean",],
        @[@"date",@"FHIRDateTime",],
        @[@"stableDate",@"FHIRDate",],
        @[@"define",@"FHIRValueSetDefineComponent",],
        @[@"compose",@"FHIRValueSetComposeComponent",],
        @[@"expansion",@"FHIRValueSetExpansionComponent",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRValueSetDefineComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"system",@"FHIRUri",],
        @[@"version",@"FHIRString",],
        @[@"caseSensitive",@"FHIRBoolean",],
        @[@"concept",@"FHIRConceptDefinitionComponent",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRValueSetExpansionContainsComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"system",@"FHIRUri",],
        @[@"abstract_",@"FHIRBoolean",],
        @[@"version",@"FHIRString",],
        @[@"code",@"FHIRCode",],
        @[@"display",@"FHIRString",],
        @[@"contains",@"FHIRValueSetExpansionContainsComponent",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRConceptDefinitionDesignationComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"language",@"FHIRCode",],
        @[@"use",@"FHIRCoding",],
        @[@"value",@"FHIRString",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRConceptDefinitionComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"code",@"FHIRCode",],
        @[@"abstract_",@"FHIRBoolean",],
        @[@"display",@"FHIRString",],
        @[@"definition",@"FHIRString",],
        @[@"designation",@"FHIRConceptDefinitionDesignationComponent",],
        @[@"concept",@"FHIRConceptDefinitionComponent",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRConceptSetComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"system",@"FHIRUri",],
        @[@"version",@"FHIRString",],
        @[@"concept",@"FHIRConceptReferenceComponent",],
        @[@"filter",@"FHIRConceptSetFilterComponent",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRConceptReferenceComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"code",@"FHIRCode",],
        @[@"display",@"FHIRString",],
        @[@"designation",@"FHIRConceptDefinitionDesignationComponent",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRConceptSetFilterComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"property",@"FHIRCode",],
        @[@"op",@"FHIRCode",],
        @[@"value",@"FHIRCode",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRValueSetComposeComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"import",@"FHIRUri",],
        @[@"include",@"FHIRConceptSetComponent",],
        @[@"exclude",@"FHIRConceptSetComponent",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRValueSetExpansionComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"identifier",@"FHIRIdentifier",],
        @[@"timestamp",@"FHIRDateTime",],
        @[@"contains",@"FHIRValueSetExpansionContainsComponent",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRVisionClaim
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"meta",@"FHIRResourceMetaComponent",],
        @[@"implicitRules",@"FHIRUri",],
        @[@"language",@"FHIRCode",],
        @[@"text",@"FHIRNarrative",],
        @[@"contained",@"FHIRBaseResource",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"identifier",@"FHIRIdentifier",],
        @[@"ruleset",@"FHIRCoding",],
        @[@"originalRuleset",@"FHIRCoding",],
        @[@"created",@"FHIRDateTime",],
        @[@"target",@"FHIRReference",],
        @[@"provider",@"FHIRReference",],
        @[@"organization",@"FHIRReference",],
        @[@"use",@"FHIRCode",],
        @[@"priority",@"FHIRCoding",],
        @[@"fundsReserve",@"FHIRCoding",],
        @[@"enterer",@"FHIRReference",],
        @[@"facility",@"FHIRReference",],
        @[@"prescription",@"FHIRReference",],
        @[@"payee",@"FHIRPayeeComponent",],
        @[@"referral",@"FHIRReference",],
        @[@"diagnosis",@"FHIRDiagnosisComponent",],
        @[@"condition",@"FHIRCoding",],
        @[@"patient",@"FHIRReference",],
        @[@"coverage",@"FHIRCoverageComponent",],
        @[@"exception",@"FHIRCoding",],
        @[@"school",@"FHIRString",],
        @[@"accident",@"FHIRDate",],
        @[@"accidentType",@"FHIRCoding",],
        @[@"interventionException",@"FHIRCoding",],
        @[@"item",@"FHIRItemsComponent",],
        @[@"additionalMaterials",@"FHIRCoding",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRItemsComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"sequence",@"FHIRInteger",],
        @[@"type",@"FHIRCoding",],
        @[@"provider",@"FHIRReference",],
        @[@"diagnosisLinkId",@"FHIRInteger",],
        @[@"service",@"FHIRCoding",],
        @[@"serviceDate",@"FHIRDate",],
        @[@"quantity",@"FHIRQuantity",],
        @[@"unitPrice",@"FHIRMoney",],
        @[@"factor",@"FHIRDecimal",],
        @[@"points",@"FHIRDecimal",],
        @[@"net",@"FHIRMoney",],
        @[@"udi",@"FHIRCoding",],
        @[@"bodySite",@"FHIRCoding",],
        @[@"subsite",@"FHIRCoding",],
        @[@"modifier",@"FHIRCoding",],
        @[@"detail",@"FHIRDetailComponent",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRDetailComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"sequence",@"FHIRInteger",],
        @[@"type",@"FHIRCoding",],
        @[@"service",@"FHIRCoding",],
        @[@"quantity",@"FHIRQuantity",],
        @[@"unitPrice",@"FHIRMoney",],
        @[@"factor",@"FHIRDecimal",],
        @[@"points",@"FHIRDecimal",],
        @[@"net",@"FHIRMoney",],
        @[@"udi",@"FHIRCoding",],
        @[@"subDetail",@"FHIRSubDetailComponent",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRCoverageComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"sequence",@"FHIRInteger",],
        @[@"focal",@"FHIRBoolean",],
        @[@"coverage",@"FHIRReference",],
        @[@"businessArrangement",@"FHIRString",],
        @[@"relationship",@"FHIRCoding",],
        @[@"preauthref",@"FHIRString",],
        @[@"claimResponse",@"FHIRReference",],
        @[@"originalRuleset",@"FHIRCoding",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRPayeeComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"type",@"FHIRCoding",],
        @[@"provider",@"FHIRReference",],
        @[@"organization",@"FHIRReference",],
        @[@"person",@"FHIRReference",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRDiagnosisComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"sequence",@"FHIRInteger",],
        @[@"diagnosis",@"FHIRCoding",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRSubDetailComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"sequence",@"FHIRInteger",],
        @[@"type",@"FHIRCoding",],
        @[@"service",@"FHIRCoding",],
        @[@"quantity",@"FHIRQuantity",],
        @[@"unitPrice",@"FHIRMoney",],
        @[@"factor",@"FHIRDecimal",],
        @[@"points",@"FHIRDecimal",],
        @[@"net",@"FHIRMoney",],
        @[@"udi",@"FHIRCoding",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRVisionPrescription
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"meta",@"FHIRResourceMetaComponent",],
        @[@"implicitRules",@"FHIRUri",],
        @[@"language",@"FHIRCode",],
        @[@"text",@"FHIRNarrative",],
        @[@"contained",@"FHIRBaseResource",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"identifier",@"FHIRIdentifier",],
        @[@"dateWritten",@"FHIRDateTime",],
        @[@"patient",@"FHIRReference",],
        @[@"prescriber",@"FHIRReference",],
        @[@"encounter",@"FHIRReference",],
        @[@"reason",@"FHIRElement",],
        @[@"dispense",@"FHIRVisionPrescriptionDispenseComponent",],
    ];
}

+ (NSArray *)orderPairArrayForFHIRVisionPrescriptionDispenseComponent
{
    return @[
    
        @[@"id",@"FHIRId",],
        @[@"extension",@"FHIRExtension",],
        @[@"modifierExtension",@"FHIRExtension",],
        @[@"product",@"FHIRCoding",],
        @[@"eye",@"FHIRCode",],
        @[@"sphere",@"FHIRDecimal",],
        @[@"cylinder",@"FHIRDecimal",],
        @[@"axis",@"FHIRInteger",],
        @[@"prism",@"FHIRDecimal",],
        @[@"base_",@"FHIRCode",],
        @[@"add",@"FHIRDecimal",],
        @[@"power",@"FHIRDecimal",],
        @[@"backCurve",@"FHIRDecimal",],
        @[@"diameter",@"FHIRDecimal",],
        @[@"duration",@"FHIRQuantity",],
        @[@"color",@"FHIRString",],
        @[@"brand",@"FHIRString",],
        @[@"notes",@"FHIRString",],
    ];
}


+ (NSArray *)orderPairArrayForType:(NSString *)fhirOcType
{
    if([fhirOcType isEqualToString:@"FHIRAddress"])
    {
        return [self orderPairArrayForFHIRAddress];
    }
    else if([fhirOcType isEqualToString:@"FHIRAttachment"])
    {
        return [self orderPairArrayForFHIRAttachment];
    }
    else if([fhirOcType isEqualToString:@"FHIRBackboneElement"])
    {
        return [self orderPairArrayForFHIRBackboneElement];
    }
    else if([fhirOcType isEqualToString:@"FHIRCodeableConcept"])
    {
        return [self orderPairArrayForFHIRCodeableConcept];
    }
    else if([fhirOcType isEqualToString:@"FHIRCoding"])
    {
        return [self orderPairArrayForFHIRCoding];
    }
    else if([fhirOcType isEqualToString:@"FHIRContactPoint"])
    {
        return [self orderPairArrayForFHIRContactPoint];
    }
    else if([fhirOcType isEqualToString:@"FHIRElement"])
    {
        return [self orderPairArrayForFHIRElement];
    }
    else if([fhirOcType isEqualToString:@"FHIRElementDefinition"])
    {
        return [self orderPairArrayForFHIRElementDefinition];
    }
    else if([fhirOcType isEqualToString:@"FHIRElementDefinitionSlicingComponent"])
    {
        return [self orderPairArrayForFHIRElementDefinitionSlicingComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRTypeRefComponent"])
    {
        return [self orderPairArrayForFHIRTypeRefComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRElementDefinitionMappingComponent"])
    {
        return [self orderPairArrayForFHIRElementDefinitionMappingComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRElementDefinitionBindingComponent"])
    {
        return [self orderPairArrayForFHIRElementDefinitionBindingComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRElementDefinitionConstraintComponent"])
    {
        return [self orderPairArrayForFHIRElementDefinitionConstraintComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRExtension"])
    {
        return [self orderPairArrayForFHIRExtension];
    }
    else if([fhirOcType isEqualToString:@"FHIRHumanName"])
    {
        return [self orderPairArrayForFHIRHumanName];
    }
    else if([fhirOcType isEqualToString:@"FHIRIdentifier"])
    {
        return [self orderPairArrayForFHIRIdentifier];
    }
    else if([fhirOcType isEqualToString:@"FHIRNarrative"])
    {
        return [self orderPairArrayForFHIRNarrative];
    }
    else if([fhirOcType isEqualToString:@"FHIRPeriod"])
    {
        return [self orderPairArrayForFHIRPeriod];
    }
    else if([fhirOcType isEqualToString:@"FHIRQuantity"])
    {
        return [self orderPairArrayForFHIRQuantity];
    }
    else if([fhirOcType isEqualToString:@"FHIRRange"])
    {
        return [self orderPairArrayForFHIRRange];
    }
    else if([fhirOcType isEqualToString:@"FHIRRatio"])
    {
        return [self orderPairArrayForFHIRRatio];
    }
    else if([fhirOcType isEqualToString:@"FHIRReference"])
    {
        return [self orderPairArrayForFHIRReference];
    }
    else if([fhirOcType isEqualToString:@"FHIRSampledData"])
    {
        return [self orderPairArrayForFHIRSampledData];
    }
    else if([fhirOcType isEqualToString:@"FHIRTiming"])
    {
        return [self orderPairArrayForFHIRTiming];
    }
    else if([fhirOcType isEqualToString:@"FHIRTimingRepeatComponent"])
    {
        return [self orderPairArrayForFHIRTimingRepeatComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRBase64Binary"])
    {
        return [self orderPairArrayForFHIRBase64Binary];
    }
    else if([fhirOcType isEqualToString:@"FHIRBoolean"])
    {
        return [self orderPairArrayForFHIRBoolean];
    }
    else if([fhirOcType isEqualToString:@"FHIRCode"])
    {
        return [self orderPairArrayForFHIRCode];
    }
    else if([fhirOcType isEqualToString:@"FHIRDate"])
    {
        return [self orderPairArrayForFHIRDate];
    }
    else if([fhirOcType isEqualToString:@"FHIRDateTime"])
    {
        return [self orderPairArrayForFHIRDateTime];
    }
    else if([fhirOcType isEqualToString:@"FHIRDecimal"])
    {
        return [self orderPairArrayForFHIRDecimal];
    }
    else if([fhirOcType isEqualToString:@"FHIRId"])
    {
        return [self orderPairArrayForFHIRId];
    }
    else if([fhirOcType isEqualToString:@"FHIRInstant"])
    {
        return [self orderPairArrayForFHIRInstant];
    }
    else if([fhirOcType isEqualToString:@"FHIRInteger"])
    {
        return [self orderPairArrayForFHIRInteger];
    }
    else if([fhirOcType isEqualToString:@"FHIROid"])
    {
        return [self orderPairArrayForFHIROid];
    }
    else if([fhirOcType isEqualToString:@"FHIRString"])
    {
        return [self orderPairArrayForFHIRString];
    }
    else if([fhirOcType isEqualToString:@"FHIRTime"])
    {
        return [self orderPairArrayForFHIRTime];
    }
    else if([fhirOcType isEqualToString:@"FHIRUri"])
    {
        return [self orderPairArrayForFHIRUri];
    }
    else if([fhirOcType isEqualToString:@"FHIRUuid"])
    {
        return [self orderPairArrayForFHIRUuid];
    }
    else if([fhirOcType isEqualToString:@"FHIRXhtml"])
    {
        return [self orderPairArrayForFHIRXhtml];
    }
    else if([fhirOcType isEqualToString:@"FHIRDomainResource"])
    {
        return [self orderPairArrayForFHIRDomainResource];
    }
    else if([fhirOcType isEqualToString:@"FHIRParameters"])
    {
        return [self orderPairArrayForFHIRParameters];
    }
    else if([fhirOcType isEqualToString:@"FHIRParametersParameterComponent"])
    {
        return [self orderPairArrayForFHIRParametersParameterComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRParametersParameterPartComponent"])
    {
        return [self orderPairArrayForFHIRParametersParameterPartComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRBaseResource"])
    {
        return [self orderPairArrayForFHIRBaseResource];
    }
    else if([fhirOcType isEqualToString:@"FHIRResourceMetaComponent"])
    {
        return [self orderPairArrayForFHIRResourceMetaComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRAlert"])
    {
        return [self orderPairArrayForFHIRAlert];
    }
    else if([fhirOcType isEqualToString:@"FHIRAllergyIntolerance"])
    {
        return [self orderPairArrayForFHIRAllergyIntolerance];
    }
    else if([fhirOcType isEqualToString:@"FHIRAllergyIntoleranceEventComponent"])
    {
        return [self orderPairArrayForFHIRAllergyIntoleranceEventComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRAppointment"])
    {
        return [self orderPairArrayForFHIRAppointment];
    }
    else if([fhirOcType isEqualToString:@"FHIRAppointmentParticipantComponent"])
    {
        return [self orderPairArrayForFHIRAppointmentParticipantComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRAppointmentResponse"])
    {
        return [self orderPairArrayForFHIRAppointmentResponse];
    }
    else if([fhirOcType isEqualToString:@"FHIRBasic"])
    {
        return [self orderPairArrayForFHIRBasic];
    }
    else if([fhirOcType isEqualToString:@"FHIRBinary"])
    {
        return [self orderPairArrayForFHIRBinary];
    }
    else if([fhirOcType isEqualToString:@"FHIRBundle"])
    {
        return [self orderPairArrayForFHIRBundle];
    }
    else if([fhirOcType isEqualToString:@"FHIRBundleEntryDeletedComponent"])
    {
        return [self orderPairArrayForFHIRBundleEntryDeletedComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRBundleEntryComponent"])
    {
        return [self orderPairArrayForFHIRBundleEntryComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRBundleLinkComponent"])
    {
        return [self orderPairArrayForFHIRBundleLinkComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRCarePlan"])
    {
        return [self orderPairArrayForFHIRCarePlan];
    }
    else if([fhirOcType isEqualToString:@"FHIRCarePlanGoalComponent"])
    {
        return [self orderPairArrayForFHIRCarePlanGoalComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRCarePlanParticipantComponent"])
    {
        return [self orderPairArrayForFHIRCarePlanParticipantComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRCarePlanActivityComponent"])
    {
        return [self orderPairArrayForFHIRCarePlanActivityComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRCarePlanActivitySimpleComponent"])
    {
        return [self orderPairArrayForFHIRCarePlanActivitySimpleComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRCarePlan2"])
    {
        return [self orderPairArrayForFHIRCarePlan2];
    }
    else if([fhirOcType isEqualToString:@"FHIRCarePlan2ParticipantComponent"])
    {
        return [self orderPairArrayForFHIRCarePlan2ParticipantComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRClaimResponse"])
    {
        return [self orderPairArrayForFHIRClaimResponse];
    }
    else if([fhirOcType isEqualToString:@"FHIRNotesComponent"])
    {
        return [self orderPairArrayForFHIRNotesComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRItemsComponent"])
    {
        return [self orderPairArrayForFHIRItemsComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRItemSubdetailComponent"])
    {
        return [self orderPairArrayForFHIRItemSubdetailComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRAddedItemDetailAdjudicationComponent"])
    {
        return [self orderPairArrayForFHIRAddedItemDetailAdjudicationComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRAddedItemAdjudicationComponent"])
    {
        return [self orderPairArrayForFHIRAddedItemAdjudicationComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRDetailAdjudicationComponent"])
    {
        return [self orderPairArrayForFHIRDetailAdjudicationComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRErrorsComponent"])
    {
        return [self orderPairArrayForFHIRErrorsComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRAddedItemComponent"])
    {
        return [self orderPairArrayForFHIRAddedItemComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRItemAdjudicationComponent"])
    {
        return [self orderPairArrayForFHIRItemAdjudicationComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRAddedItemsDetailComponent"])
    {
        return [self orderPairArrayForFHIRAddedItemsDetailComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRSubdetailAdjudicationComponent"])
    {
        return [self orderPairArrayForFHIRSubdetailAdjudicationComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRItemDetailComponent"])
    {
        return [self orderPairArrayForFHIRItemDetailComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRClinicalAssessment"])
    {
        return [self orderPairArrayForFHIRClinicalAssessment];
    }
    else if([fhirOcType isEqualToString:@"FHIRClinicalAssessmentRuledOutComponent"])
    {
        return [self orderPairArrayForFHIRClinicalAssessmentRuledOutComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRClinicalAssessmentInvestigationsComponent"])
    {
        return [self orderPairArrayForFHIRClinicalAssessmentInvestigationsComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRClinicalAssessmentDiagnosisComponent"])
    {
        return [self orderPairArrayForFHIRClinicalAssessmentDiagnosisComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRCommunication"])
    {
        return [self orderPairArrayForFHIRCommunication];
    }
    else if([fhirOcType isEqualToString:@"FHIRCommunicationPayloadComponent"])
    {
        return [self orderPairArrayForFHIRCommunicationPayloadComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRCommunicationRequest"])
    {
        return [self orderPairArrayForFHIRCommunicationRequest];
    }
    else if([fhirOcType isEqualToString:@"FHIRCommunicationRequestPayloadComponent"])
    {
        return [self orderPairArrayForFHIRCommunicationRequestPayloadComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRComposition"])
    {
        return [self orderPairArrayForFHIRComposition];
    }
    else if([fhirOcType isEqualToString:@"FHIRSectionComponent"])
    {
        return [self orderPairArrayForFHIRSectionComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRCompositionEventComponent"])
    {
        return [self orderPairArrayForFHIRCompositionEventComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRCompositionAttesterComponent"])
    {
        return [self orderPairArrayForFHIRCompositionAttesterComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRConceptMap"])
    {
        return [self orderPairArrayForFHIRConceptMap];
    }
    else if([fhirOcType isEqualToString:@"FHIRConceptMapElementComponent"])
    {
        return [self orderPairArrayForFHIRConceptMapElementComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRConceptMapElementMapComponent"])
    {
        return [self orderPairArrayForFHIRConceptMapElementMapComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIROtherElementComponent"])
    {
        return [self orderPairArrayForFHIROtherElementComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRCondition"])
    {
        return [self orderPairArrayForFHIRCondition];
    }
    else if([fhirOcType isEqualToString:@"FHIRConditionEvidenceComponent"])
    {
        return [self orderPairArrayForFHIRConditionEvidenceComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRConditionDueToComponent"])
    {
        return [self orderPairArrayForFHIRConditionDueToComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRConditionOccurredFollowingComponent"])
    {
        return [self orderPairArrayForFHIRConditionOccurredFollowingComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRConditionStageComponent"])
    {
        return [self orderPairArrayForFHIRConditionStageComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRConditionLocationComponent"])
    {
        return [self orderPairArrayForFHIRConditionLocationComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRConformance"])
    {
        return [self orderPairArrayForFHIRConformance];
    }
    else if([fhirOcType isEqualToString:@"FHIRConformanceRestComponent"])
    {
        return [self orderPairArrayForFHIRConformanceRestComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRConformanceSoftwareComponent"])
    {
        return [self orderPairArrayForFHIRConformanceSoftwareComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRConformanceMessagingComponent"])
    {
        return [self orderPairArrayForFHIRConformanceMessagingComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRConformanceDocumentComponent"])
    {
        return [self orderPairArrayForFHIRConformanceDocumentComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRConformanceRestResourceComponent"])
    {
        return [self orderPairArrayForFHIRConformanceRestResourceComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRConformanceImplementationComponent"])
    {
        return [self orderPairArrayForFHIRConformanceImplementationComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRConformanceMessagingEventComponent"])
    {
        return [self orderPairArrayForFHIRConformanceMessagingEventComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRSystemInteractionComponent"])
    {
        return [self orderPairArrayForFHIRSystemInteractionComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRResourceInteractionComponent"])
    {
        return [self orderPairArrayForFHIRResourceInteractionComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRConformanceRestSecurityComponent"])
    {
        return [self orderPairArrayForFHIRConformanceRestSecurityComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRConformanceRestSecurityCertificateComponent"])
    {
        return [self orderPairArrayForFHIRConformanceRestSecurityCertificateComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRConformanceRestOperationComponent"])
    {
        return [self orderPairArrayForFHIRConformanceRestOperationComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRConformanceRestResourceSearchParamComponent"])
    {
        return [self orderPairArrayForFHIRConformanceRestResourceSearchParamComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRContract"])
    {
        return [self orderPairArrayForFHIRContract];
    }
    else if([fhirOcType isEqualToString:@"FHIRContractSignerComponent"])
    {
        return [self orderPairArrayForFHIRContractSignerComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRContractTermComponent"])
    {
        return [self orderPairArrayForFHIRContractTermComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRContraindication"])
    {
        return [self orderPairArrayForFHIRContraindication];
    }
    else if([fhirOcType isEqualToString:@"FHIRContraindicationMitigationComponent"])
    {
        return [self orderPairArrayForFHIRContraindicationMitigationComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRCoverage"])
    {
        return [self orderPairArrayForFHIRCoverage];
    }
    else if([fhirOcType isEqualToString:@"FHIRDataElement"])
    {
        return [self orderPairArrayForFHIRDataElement];
    }
    else if([fhirOcType isEqualToString:@"FHIRDataElementMappingComponent"])
    {
        return [self orderPairArrayForFHIRDataElementMappingComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRDataElementBindingComponent"])
    {
        return [self orderPairArrayForFHIRDataElementBindingComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRDevice"])
    {
        return [self orderPairArrayForFHIRDevice];
    }
    else if([fhirOcType isEqualToString:@"FHIRDeviceComponent"])
    {
        return [self orderPairArrayForFHIRDeviceComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRDeviceComponentProductionSpecificationComponent"])
    {
        return [self orderPairArrayForFHIRDeviceComponentProductionSpecificationComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRDeviceMetric"])
    {
        return [self orderPairArrayForFHIRDeviceMetric];
    }
    else if([fhirOcType isEqualToString:@"FHIRDeviceMetricCalibrationInfoComponent"])
    {
        return [self orderPairArrayForFHIRDeviceMetricCalibrationInfoComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRDeviceUseRequest"])
    {
        return [self orderPairArrayForFHIRDeviceUseRequest];
    }
    else if([fhirOcType isEqualToString:@"FHIRDeviceUseStatement"])
    {
        return [self orderPairArrayForFHIRDeviceUseStatement];
    }
    else if([fhirOcType isEqualToString:@"FHIRDiagnosticOrder"])
    {
        return [self orderPairArrayForFHIRDiagnosticOrder];
    }
    else if([fhirOcType isEqualToString:@"FHIRDiagnosticOrderItemComponent"])
    {
        return [self orderPairArrayForFHIRDiagnosticOrderItemComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRDiagnosticOrderEventComponent"])
    {
        return [self orderPairArrayForFHIRDiagnosticOrderEventComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRDiagnosticReport"])
    {
        return [self orderPairArrayForFHIRDiagnosticReport];
    }
    else if([fhirOcType isEqualToString:@"FHIRDiagnosticReportImageComponent"])
    {
        return [self orderPairArrayForFHIRDiagnosticReportImageComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRDocumentManifest"])
    {
        return [self orderPairArrayForFHIRDocumentManifest];
    }
    else if([fhirOcType isEqualToString:@"FHIRDocumentReference"])
    {
        return [self orderPairArrayForFHIRDocumentReference];
    }
    else if([fhirOcType isEqualToString:@"FHIRDocumentReferenceContextComponent"])
    {
        return [self orderPairArrayForFHIRDocumentReferenceContextComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRDocumentReferenceRelatesToComponent"])
    {
        return [self orderPairArrayForFHIRDocumentReferenceRelatesToComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRDocumentReferenceServiceParameterComponent"])
    {
        return [self orderPairArrayForFHIRDocumentReferenceServiceParameterComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRDocumentReferenceServiceComponent"])
    {
        return [self orderPairArrayForFHIRDocumentReferenceServiceComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIREligibilityRequest"])
    {
        return [self orderPairArrayForFHIREligibilityRequest];
    }
    else if([fhirOcType isEqualToString:@"FHIREligibilityResponse"])
    {
        return [self orderPairArrayForFHIREligibilityResponse];
    }
    else if([fhirOcType isEqualToString:@"FHIREncounter"])
    {
        return [self orderPairArrayForFHIREncounter];
    }
    else if([fhirOcType isEqualToString:@"FHIREncounterHospitalizationComponent"])
    {
        return [self orderPairArrayForFHIREncounterHospitalizationComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIREncounterStatusHistoryComponent"])
    {
        return [self orderPairArrayForFHIREncounterStatusHistoryComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIREncounterLocationComponent"])
    {
        return [self orderPairArrayForFHIREncounterLocationComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIREncounterParticipantComponent"])
    {
        return [self orderPairArrayForFHIREncounterParticipantComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIREnrollmentRequest"])
    {
        return [self orderPairArrayForFHIREnrollmentRequest];
    }
    else if([fhirOcType isEqualToString:@"FHIREnrollmentResponse"])
    {
        return [self orderPairArrayForFHIREnrollmentResponse];
    }
    else if([fhirOcType isEqualToString:@"FHIREpisodeOfCare"])
    {
        return [self orderPairArrayForFHIREpisodeOfCare];
    }
    else if([fhirOcType isEqualToString:@"FHIREpisodeOfCareStatusHistoryComponent"])
    {
        return [self orderPairArrayForFHIREpisodeOfCareStatusHistoryComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIREpisodeOfCareCareTeamComponent"])
    {
        return [self orderPairArrayForFHIREpisodeOfCareCareTeamComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRExplanationOfBenefit"])
    {
        return [self orderPairArrayForFHIRExplanationOfBenefit];
    }
    else if([fhirOcType isEqualToString:@"FHIRExtensionDefinition"])
    {
        return [self orderPairArrayForFHIRExtensionDefinition];
    }
    else if([fhirOcType isEqualToString:@"FHIRExtensionDefinitionMappingComponent"])
    {
        return [self orderPairArrayForFHIRExtensionDefinitionMappingComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRFamilyHistory"])
    {
        return [self orderPairArrayForFHIRFamilyHistory];
    }
    else if([fhirOcType isEqualToString:@"FHIRFamilyHistoryRelationConditionComponent"])
    {
        return [self orderPairArrayForFHIRFamilyHistoryRelationConditionComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRFamilyHistoryRelationComponent"])
    {
        return [self orderPairArrayForFHIRFamilyHistoryRelationComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRGoal"])
    {
        return [self orderPairArrayForFHIRGoal];
    }
    else if([fhirOcType isEqualToString:@"FHIRGroup"])
    {
        return [self orderPairArrayForFHIRGroup];
    }
    else if([fhirOcType isEqualToString:@"FHIRGroupCharacteristicComponent"])
    {
        return [self orderPairArrayForFHIRGroupCharacteristicComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRHealthcareService"])
    {
        return [self orderPairArrayForFHIRHealthcareService];
    }
    else if([fhirOcType isEqualToString:@"FHIRServiceTypeComponent"])
    {
        return [self orderPairArrayForFHIRServiceTypeComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRHealthcareServiceAvailableTimeComponent"])
    {
        return [self orderPairArrayForFHIRHealthcareServiceAvailableTimeComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRHealthcareServiceNotAvailableTimeComponent"])
    {
        return [self orderPairArrayForFHIRHealthcareServiceNotAvailableTimeComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRImagingObjectSelection"])
    {
        return [self orderPairArrayForFHIRImagingObjectSelection];
    }
    else if([fhirOcType isEqualToString:@"FHIRStudyComponent"])
    {
        return [self orderPairArrayForFHIRStudyComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRInstanceComponent"])
    {
        return [self orderPairArrayForFHIRInstanceComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRSeriesComponent"])
    {
        return [self orderPairArrayForFHIRSeriesComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRImagingStudy"])
    {
        return [self orderPairArrayForFHIRImagingStudy];
    }
    else if([fhirOcType isEqualToString:@"FHIRImagingStudySeriesComponent"])
    {
        return [self orderPairArrayForFHIRImagingStudySeriesComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRImagingStudySeriesInstanceComponent"])
    {
        return [self orderPairArrayForFHIRImagingStudySeriesInstanceComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRImmunization"])
    {
        return [self orderPairArrayForFHIRImmunization];
    }
    else if([fhirOcType isEqualToString:@"FHIRImmunizationVaccinationProtocolComponent"])
    {
        return [self orderPairArrayForFHIRImmunizationVaccinationProtocolComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRImmunizationExplanationComponent"])
    {
        return [self orderPairArrayForFHIRImmunizationExplanationComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRImmunizationReactionComponent"])
    {
        return [self orderPairArrayForFHIRImmunizationReactionComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRImmunizationRecommendation"])
    {
        return [self orderPairArrayForFHIRImmunizationRecommendation];
    }
    else if([fhirOcType isEqualToString:@"FHIRImmunizationRecommendationRecommendationDateCriterionComponent"])
    {
        return [self orderPairArrayForFHIRImmunizationRecommendationRecommendationDateCriterionComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRImmunizationRecommendationRecommendationProtocolComponent"])
    {
        return [self orderPairArrayForFHIRImmunizationRecommendationRecommendationProtocolComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRImmunizationRecommendationRecommendationComponent"])
    {
        return [self orderPairArrayForFHIRImmunizationRecommendationRecommendationComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRInstitutionalClaim"])
    {
        return [self orderPairArrayForFHIRInstitutionalClaim];
    }
    else if([fhirOcType isEqualToString:@"FHIRItemsComponent"])
    {
        return [self orderPairArrayForFHIRItemsComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRDetailComponent"])
    {
        return [self orderPairArrayForFHIRDetailComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRCoverageComponent"])
    {
        return [self orderPairArrayForFHIRCoverageComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRPayeeComponent"])
    {
        return [self orderPairArrayForFHIRPayeeComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRDiagnosisComponent"])
    {
        return [self orderPairArrayForFHIRDiagnosisComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRSubDetailComponent"])
    {
        return [self orderPairArrayForFHIRSubDetailComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRList"])
    {
        return [self orderPairArrayForFHIRList];
    }
    else if([fhirOcType isEqualToString:@"FHIRListEntryComponent"])
    {
        return [self orderPairArrayForFHIRListEntryComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRLocation"])
    {
        return [self orderPairArrayForFHIRLocation];
    }
    else if([fhirOcType isEqualToString:@"FHIRLocationPositionComponent"])
    {
        return [self orderPairArrayForFHIRLocationPositionComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRMedia"])
    {
        return [self orderPairArrayForFHIRMedia];
    }
    else if([fhirOcType isEqualToString:@"FHIRMedication"])
    {
        return [self orderPairArrayForFHIRMedication];
    }
    else if([fhirOcType isEqualToString:@"FHIRMedicationPackageContentComponent"])
    {
        return [self orderPairArrayForFHIRMedicationPackageContentComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRMedicationPackageComponent"])
    {
        return [self orderPairArrayForFHIRMedicationPackageComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRMedicationProductIngredientComponent"])
    {
        return [self orderPairArrayForFHIRMedicationProductIngredientComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRMedicationProductComponent"])
    {
        return [self orderPairArrayForFHIRMedicationProductComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRMedicationAdministration"])
    {
        return [self orderPairArrayForFHIRMedicationAdministration];
    }
    else if([fhirOcType isEqualToString:@"FHIRMedicationAdministrationDosageComponent"])
    {
        return [self orderPairArrayForFHIRMedicationAdministrationDosageComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRMedicationDispense"])
    {
        return [self orderPairArrayForFHIRMedicationDispense];
    }
    else if([fhirOcType isEqualToString:@"FHIRMedicationDispenseDispenseDosageComponent"])
    {
        return [self orderPairArrayForFHIRMedicationDispenseDispenseDosageComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRMedicationDispenseSubstitutionComponent"])
    {
        return [self orderPairArrayForFHIRMedicationDispenseSubstitutionComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRMedicationDispenseDispenseComponent"])
    {
        return [self orderPairArrayForFHIRMedicationDispenseDispenseComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRMedicationPrescription"])
    {
        return [self orderPairArrayForFHIRMedicationPrescription];
    }
    else if([fhirOcType isEqualToString:@"FHIRMedicationPrescriptionDosageInstructionComponent"])
    {
        return [self orderPairArrayForFHIRMedicationPrescriptionDosageInstructionComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRMedicationPrescriptionSubstitutionComponent"])
    {
        return [self orderPairArrayForFHIRMedicationPrescriptionSubstitutionComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRMedicationPrescriptionDispenseComponent"])
    {
        return [self orderPairArrayForFHIRMedicationPrescriptionDispenseComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRMedicationStatement"])
    {
        return [self orderPairArrayForFHIRMedicationStatement];
    }
    else if([fhirOcType isEqualToString:@"FHIRMedicationStatementDosageComponent"])
    {
        return [self orderPairArrayForFHIRMedicationStatementDosageComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRMessageHeader"])
    {
        return [self orderPairArrayForFHIRMessageHeader];
    }
    else if([fhirOcType isEqualToString:@"FHIRMessageDestinationComponent"])
    {
        return [self orderPairArrayForFHIRMessageDestinationComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRMessageSourceComponent"])
    {
        return [self orderPairArrayForFHIRMessageSourceComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRMessageHeaderResponseComponent"])
    {
        return [self orderPairArrayForFHIRMessageHeaderResponseComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRNamingSystem"])
    {
        return [self orderPairArrayForFHIRNamingSystem];
    }
    else if([fhirOcType isEqualToString:@"FHIRNamingSystemContactComponent"])
    {
        return [self orderPairArrayForFHIRNamingSystemContactComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRNamingSystemUniqueIdComponent"])
    {
        return [self orderPairArrayForFHIRNamingSystemUniqueIdComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRNutritionOrder"])
    {
        return [self orderPairArrayForFHIRNutritionOrder];
    }
    else if([fhirOcType isEqualToString:@"FHIRNutritionOrderItemSupplementComponent"])
    {
        return [self orderPairArrayForFHIRNutritionOrderItemSupplementComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRNutritionOrderItemOralDietTextureComponent"])
    {
        return [self orderPairArrayForFHIRNutritionOrderItemOralDietTextureComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRNutritionOrderItemComponent"])
    {
        return [self orderPairArrayForFHIRNutritionOrderItemComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRNutritionOrderItemEnteralFormulaComponent"])
    {
        return [self orderPairArrayForFHIRNutritionOrderItemEnteralFormulaComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRNutritionOrderItemOralDietComponent"])
    {
        return [self orderPairArrayForFHIRNutritionOrderItemOralDietComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRNutritionOrderItemOralDietNutrientsComponent"])
    {
        return [self orderPairArrayForFHIRNutritionOrderItemOralDietNutrientsComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRObservation"])
    {
        return [self orderPairArrayForFHIRObservation];
    }
    else if([fhirOcType isEqualToString:@"FHIRObservationReferenceRangeComponent"])
    {
        return [self orderPairArrayForFHIRObservationReferenceRangeComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRObservationRelatedComponent"])
    {
        return [self orderPairArrayForFHIRObservationRelatedComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIROperationDefinition"])
    {
        return [self orderPairArrayForFHIROperationDefinition];
    }
    else if([fhirOcType isEqualToString:@"FHIROperationDefinitionParameterPartComponent"])
    {
        return [self orderPairArrayForFHIROperationDefinitionParameterPartComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIROperationDefinitionParameterComponent"])
    {
        return [self orderPairArrayForFHIROperationDefinitionParameterComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIROperationOutcome"])
    {
        return [self orderPairArrayForFHIROperationOutcome];
    }
    else if([fhirOcType isEqualToString:@"FHIROperationOutcomeIssueComponent"])
    {
        return [self orderPairArrayForFHIROperationOutcomeIssueComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIROralHealthClaim"])
    {
        return [self orderPairArrayForFHIROralHealthClaim];
    }
    else if([fhirOcType isEqualToString:@"FHIRItemsComponent"])
    {
        return [self orderPairArrayForFHIRItemsComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIROrthodonticPlanComponent"])
    {
        return [self orderPairArrayForFHIROrthodonticPlanComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRDetailComponent"])
    {
        return [self orderPairArrayForFHIRDetailComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRCoverageComponent"])
    {
        return [self orderPairArrayForFHIRCoverageComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRPayeeComponent"])
    {
        return [self orderPairArrayForFHIRPayeeComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRDiagnosisComponent"])
    {
        return [self orderPairArrayForFHIRDiagnosisComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRProsthesisComponent"])
    {
        return [self orderPairArrayForFHIRProsthesisComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRSubDetailComponent"])
    {
        return [self orderPairArrayForFHIRSubDetailComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRMissingTeethComponent"])
    {
        return [self orderPairArrayForFHIRMissingTeethComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIROrder"])
    {
        return [self orderPairArrayForFHIROrder];
    }
    else if([fhirOcType isEqualToString:@"FHIROrderWhenComponent"])
    {
        return [self orderPairArrayForFHIROrderWhenComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIROrderResponse"])
    {
        return [self orderPairArrayForFHIROrderResponse];
    }
    else if([fhirOcType isEqualToString:@"FHIROrganization"])
    {
        return [self orderPairArrayForFHIROrganization];
    }
    else if([fhirOcType isEqualToString:@"FHIROrganizationContactComponent"])
    {
        return [self orderPairArrayForFHIROrganizationContactComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIROther"])
    {
        return [self orderPairArrayForFHIROther];
    }
    else if([fhirOcType isEqualToString:@"FHIRPatient"])
    {
        return [self orderPairArrayForFHIRPatient];
    }
    else if([fhirOcType isEqualToString:@"FHIRContactComponent"])
    {
        return [self orderPairArrayForFHIRContactComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRAnimalComponent"])
    {
        return [self orderPairArrayForFHIRAnimalComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRPatientLinkComponent"])
    {
        return [self orderPairArrayForFHIRPatientLinkComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRPaymentNotice"])
    {
        return [self orderPairArrayForFHIRPaymentNotice];
    }
    else if([fhirOcType isEqualToString:@"FHIRPaymentReconciliation"])
    {
        return [self orderPairArrayForFHIRPaymentReconciliation];
    }
    else if([fhirOcType isEqualToString:@"FHIRNotesComponent"])
    {
        return [self orderPairArrayForFHIRNotesComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRDetailsComponent"])
    {
        return [self orderPairArrayForFHIRDetailsComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRPendedRequest"])
    {
        return [self orderPairArrayForFHIRPendedRequest];
    }
    else if([fhirOcType isEqualToString:@"FHIRPerson"])
    {
        return [self orderPairArrayForFHIRPerson];
    }
    else if([fhirOcType isEqualToString:@"FHIRPersonLinkComponent"])
    {
        return [self orderPairArrayForFHIRPersonLinkComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRPharmacyClaim"])
    {
        return [self orderPairArrayForFHIRPharmacyClaim];
    }
    else if([fhirOcType isEqualToString:@"FHIRItemsComponent"])
    {
        return [self orderPairArrayForFHIRItemsComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRDetailComponent"])
    {
        return [self orderPairArrayForFHIRDetailComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRCoverageComponent"])
    {
        return [self orderPairArrayForFHIRCoverageComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRPayeeComponent"])
    {
        return [self orderPairArrayForFHIRPayeeComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRDiagnosisComponent"])
    {
        return [self orderPairArrayForFHIRDiagnosisComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRSubDetailComponent"])
    {
        return [self orderPairArrayForFHIRSubDetailComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRPractitioner"])
    {
        return [self orderPairArrayForFHIRPractitioner];
    }
    else if([fhirOcType isEqualToString:@"FHIRPractitionerQualificationComponent"])
    {
        return [self orderPairArrayForFHIRPractitionerQualificationComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRProcedure"])
    {
        return [self orderPairArrayForFHIRProcedure];
    }
    else if([fhirOcType isEqualToString:@"FHIRProcedureRelatedItemComponent"])
    {
        return [self orderPairArrayForFHIRProcedureRelatedItemComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRProcedurePerformerComponent"])
    {
        return [self orderPairArrayForFHIRProcedurePerformerComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRProcedureRequest"])
    {
        return [self orderPairArrayForFHIRProcedureRequest];
    }
    else if([fhirOcType isEqualToString:@"FHIRProfessionalClaim"])
    {
        return [self orderPairArrayForFHIRProfessionalClaim];
    }
    else if([fhirOcType isEqualToString:@"FHIRItemsComponent"])
    {
        return [self orderPairArrayForFHIRItemsComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRDetailComponent"])
    {
        return [self orderPairArrayForFHIRDetailComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRCoverageComponent"])
    {
        return [self orderPairArrayForFHIRCoverageComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRPayeeComponent"])
    {
        return [self orderPairArrayForFHIRPayeeComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRDiagnosisComponent"])
    {
        return [self orderPairArrayForFHIRDiagnosisComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRSubDetailComponent"])
    {
        return [self orderPairArrayForFHIRSubDetailComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRProfile"])
    {
        return [self orderPairArrayForFHIRProfile];
    }
    else if([fhirOcType isEqualToString:@"FHIRConstraintComponent"])
    {
        return [self orderPairArrayForFHIRConstraintComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRProfileMappingComponent"])
    {
        return [self orderPairArrayForFHIRProfileMappingComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRProvenance"])
    {
        return [self orderPairArrayForFHIRProvenance];
    }
    else if([fhirOcType isEqualToString:@"FHIRProvenanceAgentComponent"])
    {
        return [self orderPairArrayForFHIRProvenanceAgentComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRProvenanceEntityComponent"])
    {
        return [self orderPairArrayForFHIRProvenanceEntityComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRQuestionnaire"])
    {
        return [self orderPairArrayForFHIRQuestionnaire];
    }
    else if([fhirOcType isEqualToString:@"FHIRQuestionComponent"])
    {
        return [self orderPairArrayForFHIRQuestionComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRGroupComponent"])
    {
        return [self orderPairArrayForFHIRGroupComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRQuestionnaireAnswers"])
    {
        return [self orderPairArrayForFHIRQuestionnaireAnswers];
    }
    else if([fhirOcType isEqualToString:@"FHIRQuestionAnswerComponent"])
    {
        return [self orderPairArrayForFHIRQuestionAnswerComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRQuestionComponent"])
    {
        return [self orderPairArrayForFHIRQuestionComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRGroupComponent"])
    {
        return [self orderPairArrayForFHIRGroupComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRReadjudicate"])
    {
        return [self orderPairArrayForFHIRReadjudicate];
    }
    else if([fhirOcType isEqualToString:@"FHIRItemsComponent"])
    {
        return [self orderPairArrayForFHIRItemsComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRReferralRequest"])
    {
        return [self orderPairArrayForFHIRReferralRequest];
    }
    else if([fhirOcType isEqualToString:@"FHIRRelatedPerson"])
    {
        return [self orderPairArrayForFHIRRelatedPerson];
    }
    else if([fhirOcType isEqualToString:@"FHIRReversal"])
    {
        return [self orderPairArrayForFHIRReversal];
    }
    else if([fhirOcType isEqualToString:@"FHIRPayeeComponent"])
    {
        return [self orderPairArrayForFHIRPayeeComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRReversalCoverageComponent"])
    {
        return [self orderPairArrayForFHIRReversalCoverageComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRRiskAssessment"])
    {
        return [self orderPairArrayForFHIRRiskAssessment];
    }
    else if([fhirOcType isEqualToString:@"FHIRRiskAssessmentPredictionComponent"])
    {
        return [self orderPairArrayForFHIRRiskAssessmentPredictionComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRSchedule"])
    {
        return [self orderPairArrayForFHIRSchedule];
    }
    else if([fhirOcType isEqualToString:@"FHIRSearchParameter"])
    {
        return [self orderPairArrayForFHIRSearchParameter];
    }
    else if([fhirOcType isEqualToString:@"FHIRSecurityEvent"])
    {
        return [self orderPairArrayForFHIRSecurityEvent];
    }
    else if([fhirOcType isEqualToString:@"FHIRSecurityEventObjectDetailComponent"])
    {
        return [self orderPairArrayForFHIRSecurityEventObjectDetailComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRSecurityEventObjectComponent"])
    {
        return [self orderPairArrayForFHIRSecurityEventObjectComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRSecurityEventSourceComponent"])
    {
        return [self orderPairArrayForFHIRSecurityEventSourceComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRSecurityEventEventComponent"])
    {
        return [self orderPairArrayForFHIRSecurityEventEventComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRSecurityEventParticipantNetworkComponent"])
    {
        return [self orderPairArrayForFHIRSecurityEventParticipantNetworkComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRSecurityEventParticipantComponent"])
    {
        return [self orderPairArrayForFHIRSecurityEventParticipantComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRSlot"])
    {
        return [self orderPairArrayForFHIRSlot];
    }
    else if([fhirOcType isEqualToString:@"FHIRSpecimen"])
    {
        return [self orderPairArrayForFHIRSpecimen];
    }
    else if([fhirOcType isEqualToString:@"FHIRSpecimenCollectionComponent"])
    {
        return [self orderPairArrayForFHIRSpecimenCollectionComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRSpecimenSourceComponent"])
    {
        return [self orderPairArrayForFHIRSpecimenSourceComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRSpecimenTreatmentComponent"])
    {
        return [self orderPairArrayForFHIRSpecimenTreatmentComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRSpecimenContainerComponent"])
    {
        return [self orderPairArrayForFHIRSpecimenContainerComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRStatusRequest"])
    {
        return [self orderPairArrayForFHIRStatusRequest];
    }
    else if([fhirOcType isEqualToString:@"FHIRStatusResponse"])
    {
        return [self orderPairArrayForFHIRStatusResponse];
    }
    else if([fhirOcType isEqualToString:@"FHIRStatusResponseNotesComponent"])
    {
        return [self orderPairArrayForFHIRStatusResponseNotesComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRSubscription"])
    {
        return [self orderPairArrayForFHIRSubscription];
    }
    else if([fhirOcType isEqualToString:@"FHIRSubscriptionChannelComponent"])
    {
        return [self orderPairArrayForFHIRSubscriptionChannelComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRSubscriptionTagComponent"])
    {
        return [self orderPairArrayForFHIRSubscriptionTagComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRSubstance"])
    {
        return [self orderPairArrayForFHIRSubstance];
    }
    else if([fhirOcType isEqualToString:@"FHIRSubstanceIngredientComponent"])
    {
        return [self orderPairArrayForFHIRSubstanceIngredientComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRSubstanceInstanceComponent"])
    {
        return [self orderPairArrayForFHIRSubstanceInstanceComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRSupply"])
    {
        return [self orderPairArrayForFHIRSupply];
    }
    else if([fhirOcType isEqualToString:@"FHIRSupplyDispenseComponent"])
    {
        return [self orderPairArrayForFHIRSupplyDispenseComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRSupportingDocumentation"])
    {
        return [self orderPairArrayForFHIRSupportingDocumentation];
    }
    else if([fhirOcType isEqualToString:@"FHIRSupportingDocumentationDetailComponent"])
    {
        return [self orderPairArrayForFHIRSupportingDocumentationDetailComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRValueSet"])
    {
        return [self orderPairArrayForFHIRValueSet];
    }
    else if([fhirOcType isEqualToString:@"FHIRValueSetDefineComponent"])
    {
        return [self orderPairArrayForFHIRValueSetDefineComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRValueSetExpansionContainsComponent"])
    {
        return [self orderPairArrayForFHIRValueSetExpansionContainsComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRConceptDefinitionDesignationComponent"])
    {
        return [self orderPairArrayForFHIRConceptDefinitionDesignationComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRConceptDefinitionComponent"])
    {
        return [self orderPairArrayForFHIRConceptDefinitionComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRConceptSetComponent"])
    {
        return [self orderPairArrayForFHIRConceptSetComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRConceptReferenceComponent"])
    {
        return [self orderPairArrayForFHIRConceptReferenceComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRConceptSetFilterComponent"])
    {
        return [self orderPairArrayForFHIRConceptSetFilterComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRValueSetComposeComponent"])
    {
        return [self orderPairArrayForFHIRValueSetComposeComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRValueSetExpansionComponent"])
    {
        return [self orderPairArrayForFHIRValueSetExpansionComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRVisionClaim"])
    {
        return [self orderPairArrayForFHIRVisionClaim];
    }
    else if([fhirOcType isEqualToString:@"FHIRItemsComponent"])
    {
        return [self orderPairArrayForFHIRItemsComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRDetailComponent"])
    {
        return [self orderPairArrayForFHIRDetailComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRCoverageComponent"])
    {
        return [self orderPairArrayForFHIRCoverageComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRPayeeComponent"])
    {
        return [self orderPairArrayForFHIRPayeeComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRDiagnosisComponent"])
    {
        return [self orderPairArrayForFHIRDiagnosisComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRSubDetailComponent"])
    {
        return [self orderPairArrayForFHIRSubDetailComponent];
    }
    else if([fhirOcType isEqualToString:@"FHIRVisionPrescription"])
    {
        return [self orderPairArrayForFHIRVisionPrescription];
    }
    else if([fhirOcType isEqualToString:@"FHIRVisionPrescriptionDispenseComponent"])
    {
        return [self orderPairArrayForFHIRVisionPrescriptionDispenseComponent];
    }
    else
        @throw [NSException exceptionWithName:@"Unknown Type" reason:[NSString stringWithFormat:@"Encountered unknown type %@", fhirOcType] userInfo:nil];
}
@end
