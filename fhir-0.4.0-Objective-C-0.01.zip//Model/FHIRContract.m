﻿/*
  Copyright (c) 2011+, HL7, Inc.
  All rights reserved.
  
  Redistribution and use in source and binary forms, with or without modification, 
  are permitted provided that the following conditions are met:
  
   * Redistributions of source code must retain the above copyright notice, this 
     list of conditions and the following disclaimer.
   * Redistributions in binary form must reproduce the above copyright notice, 
     this list of conditions and the following disclaimer in the documentation 
     and/or other materials provided with the distribution.
   * Neither the name of HL7 nor the names of its contributors may be used to 
     endorse or promote products derived from this software without specific 
     prior written permission.
  
  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND 
  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
  WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
  IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
  INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT 
  NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR 
  PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
  WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
  POSSIBILITY OF SUCH DAMAGE.
  

 * Generated on Tue, Dec 30, 2014 10:55+0000 for FHIR v0.4.0
 */
/*
 * null
 */
#import "FHIRContract.h"

#import "FHIRIdentifier.h"
#import "FHIRReference.h"
#import "FHIRCodeableConcept.h"
#import "FHIRDateTime.h"
#import "FHIRPeriod.h"
#import "FHIRQuantity.h"
#import "FHIRMoney.h"
#import "FHIRDecimal.h"
#import "FHIRContractSignerComponent.h"
#import "FHIRContractTermComponent.h"
#import "FHIRAttachment.h"

#import "FHIRErrorList.h"

@implementation FHIRContract

- (NSString *)issued
{
    if(self.issuedElement)
    {
        return [self.issuedElement value];
    }
    return nil;
}

- (void )setIssued:(NSString *)issued
{
    if(issued)
    {
        [self setIssuedElement:[[FHIRDateTime alloc] initWithValue:issued]];
    }
    else
    {
        [self setIssuedElement:nil];
    }
}


- (NSDecimalNumber *)factor
{
    if(self.factorElement)
    {
        return [self.factorElement value];
    }
    return nil;
}

- (void )setFactor:(NSDecimalNumber *)factor
{
    if(factor)
    {
        [self setFactorElement:[[FHIRDecimal alloc] initWithValue:factor]];
    }
    else
    {
        [self setFactorElement:nil];
    }
}


- (NSDecimalNumber *)points
{
    if(self.pointsElement)
    {
        return [self.pointsElement value];
    }
    return nil;
}

- (void )setPoints:(NSDecimalNumber *)points
{
    if(points)
    {
        [self setPointsElement:[[FHIRDecimal alloc] initWithValue:points]];
    }
    else
    {
        [self setPointsElement:nil];
    }
}


- (NSString *)bindingDateTime
{
    if(self.bindingDateTimeElement)
    {
        return [self.bindingDateTimeElement value];
    }
    return nil;
}

- (void )setBindingDateTime:(NSString *)bindingDateTime
{
    if(bindingDateTime)
    {
        [self setBindingDateTimeElement:[[FHIRDateTime alloc] initWithValue:bindingDateTime]];
    }
    else
    {
        [self setBindingDateTimeElement:nil];
    }
}


- (NSString *)friendlyDateTime
{
    if(self.friendlyDateTimeElement)
    {
        return [self.friendlyDateTimeElement value];
    }
    return nil;
}

- (void )setFriendlyDateTime:(NSString *)friendlyDateTime
{
    if(friendlyDateTime)
    {
        [self setFriendlyDateTimeElement:[[FHIRDateTime alloc] initWithValue:friendlyDateTime]];
    }
    else
    {
        [self setFriendlyDateTimeElement:nil];
    }
}


- (NSString *)legalDateTime
{
    if(self.legalDateTimeElement)
    {
        return [self.legalDateTimeElement value];
    }
    return nil;
}

- (void )setLegalDateTime:(NSString *)legalDateTime
{
    if(legalDateTime)
    {
        [self setLegalDateTimeElement:[[FHIRDateTime alloc] initWithValue:legalDateTime]];
    }
    else
    {
        [self setLegalDateTimeElement:nil];
    }
}


- (NSString *)ruleDateTime
{
    if(self.ruleDateTimeElement)
    {
        return [self.ruleDateTimeElement value];
    }
    return nil;
}

- (void )setRuleDateTime:(NSString *)ruleDateTime
{
    if(ruleDateTime)
    {
        [self setRuleDateTimeElement:[[FHIRDateTime alloc] initWithValue:ruleDateTime]];
    }
    else
    {
        [self setRuleDateTimeElement:nil];
    }
}


- (FHIRErrorList *)validate
{
    FHIRErrorList *result = [[FHIRErrorList alloc] init];
    
    [result addValidation:[super validate]];
    
    if(self.identifier != nil )
        for(FHIRIdentifier *elem in self.identifier)
            [result addValidationRange:[elem validate]];
    if(self.subject != nil )
        for(FHIRReference *elem in self.subject)
            [result addValidationRange:[elem validate]];
    if(self.authority != nil )
        for(FHIRReference *elem in self.authority)
            [result addValidationRange:[elem validate]];
    if(self.domain != nil )
        for(FHIRReference *elem in self.domain)
            [result addValidationRange:[elem validate]];
    if(self.type != nil )
        [result addValidationRange:[self.type validate]];
    if(self.subtype != nil )
        for(FHIRCodeableConcept *elem in self.subtype)
            [result addValidationRange:[elem validate]];
    if(self.issuedElement != nil )
        [result addValidationRange:[self.issuedElement validate]];
    if(self.applies != nil )
        [result addValidationRange:[self.applies validate]];
    if(self.quantity != nil )
        [result addValidationRange:[self.quantity validate]];
    if(self.unitPrice != nil )
        [result addValidationRange:[self.unitPrice validate]];
    if(self.factorElement != nil )
        [result addValidationRange:[self.factorElement validate]];
    if(self.pointsElement != nil )
        [result addValidationRange:[self.pointsElement validate]];
    if(self.net != nil )
        [result addValidationRange:[self.net validate]];
    if(self.author != nil )
        for(FHIRReference *elem in self.author)
            [result addValidationRange:[elem validate]];
    if(self.grantor != nil )
        for(FHIRReference *elem in self.grantor)
            [result addValidationRange:[elem validate]];
    if(self.grantee != nil )
        for(FHIRReference *elem in self.grantee)
            [result addValidationRange:[elem validate]];
    if(self.witness != nil )
        for(FHIRReference *elem in self.witness)
            [result addValidationRange:[elem validate]];
    if(self.executor != nil )
        for(FHIRReference *elem in self.executor)
            [result addValidationRange:[elem validate]];
    if(self.notary != nil )
        for(FHIRReference *elem in self.notary)
            [result addValidationRange:[elem validate]];
    if(self.signer != nil )
        for(FHIRContractSignerComponent *elem in self.signer)
            [result addValidationRange:[elem validate]];
    if(self.term != nil )
        for(FHIRContractTermComponent *elem in self.term)
            [result addValidationRange:[elem validate]];
    if(self.binding != nil )
        [result addValidationRange:[self.binding validate]];
    if(self.bindingDateTimeElement != nil )
        [result addValidationRange:[self.bindingDateTimeElement validate]];
    if(self.friendly != nil )
        for(FHIRAttachment *elem in self.friendly)
            [result addValidationRange:[elem validate]];
    if(self.friendlyDateTimeElement != nil )
        [result addValidationRange:[self.friendlyDateTimeElement validate]];
    if(self.legal != nil )
        for(FHIRAttachment *elem in self.legal)
            [result addValidationRange:[elem validate]];
    if(self.legalDateTimeElement != nil )
        [result addValidationRange:[self.legalDateTimeElement validate]];
    if(self.rule != nil )
        for(FHIRAttachment *elem in self.rule)
            [result addValidationRange:[elem validate]];
    if(self.ruleDateTimeElement != nil )
        [result addValidationRange:[self.ruleDateTimeElement validate]];
    
    return result;
}

@end
