﻿/*
  Copyright (c) 2011+, HL7, Inc.
  All rights reserved.
  
  Redistribution and use in source and binary forms, with or without modification, 
  are permitted provided that the following conditions are met:
  
   * Redistributions of source code must retain the above copyright notice, this 
     list of conditions and the following disclaimer.
   * Redistributions in binary form must reproduce the above copyright notice, 
     this list of conditions and the following disclaimer in the documentation 
     and/or other materials provided with the distribution.
   * Neither the name of HL7 nor the names of its contributors may be used to 
     endorse or promote products derived from this software without specific 
     prior written permission.
  
  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND 
  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
  WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
  IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
  INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT 
  NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR 
  PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
  WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
  POSSIBILITY OF SUCH DAMAGE.
  

 * Generated on Tue, Dec 30, 2014 10:55+0000 for FHIR v0.4.0
 */
/*
 * The details of a Healthcare Service available at a location
 */
#import "FHIRHealthcareService.h"

#import "FHIRIdentifier.h"
#import "FHIRReference.h"
#import "FHIRCodeableConcept.h"
#import "FHIRServiceTypeComponent.h"
#import "FHIRString.h"
#import "FHIRUri.h"
#import "FHIRHealthcareServiceAvailableTimeComponent.h"
#import "FHIRHealthcareServiceNotAvailableTimeComponent.h"
#import "FHIRContactPoint.h"

#import "FHIRErrorList.h"

@implementation FHIRHealthcareService

- (NSString *)serviceName
{
    if(self.serviceNameElement)
    {
        return [self.serviceNameElement value];
    }
    return nil;
}

- (void )setServiceName:(NSString *)serviceName
{
    if(serviceName)
    {
        [self setServiceNameElement:[[FHIRString alloc] initWithValue:serviceName]];
    }
    else
    {
        [self setServiceNameElement:nil];
    }
}


- (NSString *)comment
{
    if(self.commentElement)
    {
        return [self.commentElement value];
    }
    return nil;
}

- (void )setComment:(NSString *)comment
{
    if(comment)
    {
        [self setCommentElement:[[FHIRString alloc] initWithValue:comment]];
    }
    else
    {
        [self setCommentElement:nil];
    }
}


- (NSString *)extraDetails
{
    if(self.extraDetailsElement)
    {
        return [self.extraDetailsElement value];
    }
    return nil;
}

- (void )setExtraDetails:(NSString *)extraDetails
{
    if(extraDetails)
    {
        [self setExtraDetailsElement:[[FHIRString alloc] initWithValue:extraDetails]];
    }
    else
    {
        [self setExtraDetailsElement:nil];
    }
}


- (NSString *)eligibilityNote
{
    if(self.eligibilityNoteElement)
    {
        return [self.eligibilityNoteElement value];
    }
    return nil;
}

- (void )setEligibilityNote:(NSString *)eligibilityNote
{
    if(eligibilityNote)
    {
        [self setEligibilityNoteElement:[[FHIRString alloc] initWithValue:eligibilityNote]];
    }
    else
    {
        [self setEligibilityNoteElement:nil];
    }
}


- (NSString *)imageURI
{
    if(self.imageURIElement)
    {
        return [self.imageURIElement value];
    }
    return nil;
}

- (void )setImageURI:(NSString *)imageURI
{
    if(imageURI)
    {
        [self setImageURIElement:[[FHIRUri alloc] initWithValue:imageURI]];
    }
    else
    {
        [self setImageURIElement:nil];
    }
}


- (NSString *)availabilityExceptions
{
    if(self.availabilityExceptionsElement)
    {
        return [self.availabilityExceptionsElement value];
    }
    return nil;
}

- (void )setAvailabilityExceptions:(NSString *)availabilityExceptions
{
    if(availabilityExceptions)
    {
        [self setAvailabilityExceptionsElement:[[FHIRString alloc] initWithValue:availabilityExceptions]];
    }
    else
    {
        [self setAvailabilityExceptionsElement:nil];
    }
}


- (NSString *)publicKey
{
    if(self.publicKeyElement)
    {
        return [self.publicKeyElement value];
    }
    return nil;
}

- (void )setPublicKey:(NSString *)publicKey
{
    if(publicKey)
    {
        [self setPublicKeyElement:[[FHIRString alloc] initWithValue:publicKey]];
    }
    else
    {
        [self setPublicKeyElement:nil];
    }
}


- (NSArray /*<NSString>*/ *)programName
{
    if(self.programNameElement)
    {
        NSMutableArray *array = [NSMutableArray new];
        for(FHIRString *elem in self.programNameElement)
            [array addObject:[elem value]];
        return [NSArray arrayWithArray:array];
    }
    return nil;
}

- (void )setProgramName:(NSArray /*<NSString>*/ *)programName
{
    if(programName)
    {
        NSMutableArray *array = [NSMutableArray new];
        for(NSString *value in programName)
            [array addObject:[[FHIRString alloc] initWithValue:value]];
        [self setProgramNameElement:[NSArray arrayWithArray:array]];
    }
    else
    {
        [self setProgramNameElement:nil];
    }
}


- (FHIRErrorList *)validate
{
    FHIRErrorList *result = [[FHIRErrorList alloc] init];
    
    [result addValidation:[super validate]];
    
    if(self.identifier != nil )
        for(FHIRIdentifier *elem in self.identifier)
            [result addValidationRange:[elem validate]];
    if(self.location != nil )
        [result addValidationRange:[self.location validate]];
    if(self.serviceCategory != nil )
        [result addValidationRange:[self.serviceCategory validate]];
    if(self.serviceType != nil )
        for(FHIRServiceTypeComponent *elem in self.serviceType)
            [result addValidationRange:[elem validate]];
    if(self.serviceNameElement != nil )
        [result addValidationRange:[self.serviceNameElement validate]];
    if(self.commentElement != nil )
        [result addValidationRange:[self.commentElement validate]];
    if(self.extraDetailsElement != nil )
        [result addValidationRange:[self.extraDetailsElement validate]];
    if(self.freeProvisionCode != nil )
        [result addValidationRange:[self.freeProvisionCode validate]];
    if(self.eligibility != nil )
        [result addValidationRange:[self.eligibility validate]];
    if(self.eligibilityNoteElement != nil )
        [result addValidationRange:[self.eligibilityNoteElement validate]];
    if(self.appointmentRequired != nil )
        [result addValidationRange:[self.appointmentRequired validate]];
    if(self.imageURIElement != nil )
        [result addValidationRange:[self.imageURIElement validate]];
    if(self.availableTime != nil )
        for(FHIRHealthcareServiceAvailableTimeComponent *elem in self.availableTime)
            [result addValidationRange:[elem validate]];
    if(self.notAvailableTime != nil )
        for(FHIRHealthcareServiceNotAvailableTimeComponent *elem in self.notAvailableTime)
            [result addValidationRange:[elem validate]];
    if(self.availabilityExceptionsElement != nil )
        [result addValidationRange:[self.availabilityExceptionsElement validate]];
    if(self.publicKeyElement != nil )
        [result addValidationRange:[self.publicKeyElement validate]];
    if(self.programNameElement != nil )
        for(FHIRString *elem in self.programNameElement)
            [result addValidationRange:[elem validate]];
    if(self.contactPoint != nil )
        for(FHIRContactPoint *elem in self.contactPoint)
            [result addValidationRange:[elem validate]];
    if(self.characteristic != nil )
        for(FHIRCodeableConcept *elem in self.characteristic)
            [result addValidationRange:[elem validate]];
    if(self.referralMethod != nil )
        for(FHIRCodeableConcept *elem in self.referralMethod)
            [result addValidationRange:[elem validate]];
    if(self.setting != nil )
        for(FHIRCodeableConcept *elem in self.setting)
            [result addValidationRange:[elem validate]];
    if(self.targetGroup != nil )
        for(FHIRCodeableConcept *elem in self.targetGroup)
            [result addValidationRange:[elem validate]];
    if(self.coverageArea != nil )
        for(FHIRCodeableConcept *elem in self.coverageArea)
            [result addValidationRange:[elem validate]];
    if(self.catchmentArea != nil )
        for(FHIRCodeableConcept *elem in self.catchmentArea)
            [result addValidationRange:[elem validate]];
    if(self.serviceCode != nil )
        for(FHIRCodeableConcept *elem in self.serviceCode)
            [result addValidationRange:[elem validate]];
    
    return result;
}

@end
