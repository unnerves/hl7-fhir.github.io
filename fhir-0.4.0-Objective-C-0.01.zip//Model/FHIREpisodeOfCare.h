﻿/*
  Copyright (c) 2011+, HL7, Inc.
  All rights reserved.
  
  Redistribution and use in source and binary forms, with or without modification, 
  are permitted provided that the following conditions are met:
  
   * Redistributions of source code must retain the above copyright notice, this 
     list of conditions and the following disclaimer.
   * Redistributions in binary form must reproduce the above copyright notice, 
     this list of conditions and the following disclaimer in the documentation 
     and/or other materials provided with the distribution.
   * Neither the name of HL7 nor the names of its contributors may be used to 
     endorse or promote products derived from this software without specific 
     prior written permission.
  
  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND 
  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
  WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
  IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
  INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT 
  NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR 
  PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
  WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
  POSSIBILITY OF SUCH DAMAGE.
  

 * Generated on Tue, Dec 30, 2014 10:55+0000 for FHIR v0.4.0
 */
/*
 * An association of a Patient with an Organization and  Healthcare Provider(s) for a period of time that the Organization assumes some level of responsibility
 *
 * [FhirReference("EpisodeOfCare")]
 * [Serializable]
 */

#import "FHIRDomainResource.h"


@class FHIRIdentifier;
@class FHIRCode;
@class FHIREpisodeOfCareStatusHistoryComponent;
@class FHIRCodeableConcept;
@class FHIRReference;
@class FHIRPeriod;
@class FHIREpisodeOfCareCareTeamComponent;

@interface FHIREpisodeOfCare : FHIRDomainResource

/*
 * The status of the encounter
 */
typedef enum 
{
    kEpisodeOfCareStatusPlanned, // This episode of care is planned to start at the date specified in the period.start. During this status an organization may perform assessments to determine if they are eligible to receive services, or be organizing to make resources available to provide care services.
    kEpisodeOfCareStatusActive, // This episode of care is current.
    kEpisodeOfCareStatusOnhold, // This episode of care is on hold, the organization has limitted responsibility for the patient (such as while on respite).
    kEpisodeOfCareStatusFinished, // This episode of care is finished at the organization is not expecting to be providing care to the patient.
    kEpisodeOfCareStatusWithdrawn, // The episode of care was withdrawn from service, often selected during the planned stage as the patient may have gone elsewhere, or the circumstances have changed and the organization is unable to provide the care.
    kEpisodeOfCareStatusOther, // The status is outside one of these values, an extension should be used to define what the status reason is.
} kEpisodeOfCareStatus;

/*
 * Identifier(s) by which this EpisodeOfCare is known
 */
@property (nonatomic, strong) NSArray/*<Identifier>*/ *identifier;

/*
 * planned | active | onhold | finished | withdrawn | other
 */
@property (nonatomic, strong) FHIRCode/*<code>*/ *currentStatusElement;

@property (nonatomic) kEpisodeOfCareStatus currentStatus;

/*
 * The status history for the EpisodeOfCare
 */
@property (nonatomic, strong) NSArray/*<EpisodeOfCareStatusHistoryComponent>*/ *statusHistory;

/*
 * Specific type of EpisodeOfcare
 */
@property (nonatomic, strong) NSArray/*<CodeableConcept>*/ *type;

/*
 * The patient that this episodeofcare applies to
 */
@property (nonatomic, strong) FHIRReference *patient;

/*
 * The organization that has assumed the specific responsibilities for the specified duration
 */
@property (nonatomic, strong) FHIRReference *managingOrganization;

/*
 * The interval during which the managing organization assumes the defined responsibility
 */
@property (nonatomic, strong) FHIRPeriod *period;

/*
 * A list of conditions/problems/diagnoses that this episode of care is intended to be providing care for
 */
@property (nonatomic, strong) NSArray/*<Reference>*/ *condition;

/*
 * A Referral Request that this EpisodeOfCare manages activities within
 */
@property (nonatomic, strong) FHIRReference *referralRequest;

/*
 * The practitioner that is the care manager/care co-ordinator for this patient
 */
@property (nonatomic, strong) FHIRReference *careManager;

/*
 * The list of practitioners that may be facilitating this episode of care for specific purposes
 */
@property (nonatomic, strong) NSArray/*<EpisodeOfCareCareTeamComponent>*/ *careTeam;

- (FHIRErrorList *)validate;

@end
