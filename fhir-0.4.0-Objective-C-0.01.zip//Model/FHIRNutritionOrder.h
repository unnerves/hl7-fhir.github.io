﻿/*
  Copyright (c) 2011+, HL7, Inc.
  All rights reserved.
  
  Redistribution and use in source and binary forms, with or without modification, 
  are permitted provided that the following conditions are met:
  
   * Redistributions of source code must retain the above copyright notice, this 
     list of conditions and the following disclaimer.
   * Redistributions in binary form must reproduce the above copyright notice, 
     this list of conditions and the following disclaimer in the documentation 
     and/or other materials provided with the distribution.
   * Neither the name of HL7 nor the names of its contributors may be used to 
     endorse or promote products derived from this software without specific 
     prior written permission.
  
  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND 
  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
  WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
  IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
  INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT 
  NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR 
  PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
  WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
  POSSIBILITY OF SUCH DAMAGE.
  

 * Generated on Tue, Dec 30, 2014 10:55+0000 for FHIR v0.4.0
 */
/*
 * A request for a diet, formula or nutritional supplement
 *
 * [FhirReference("NutritionOrder")]
 * [Serializable]
 */

#import "FHIRDomainResource.h"


@class FHIRReference;
@class FHIRIdentifier;
@class FHIRDateTime;
@class FHIRCodeableConcept;
@class FHIRNutritionOrderItemComponent;
@class FHIRCode;

@interface FHIRNutritionOrder : FHIRDomainResource

/*
 * TODO
 */
typedef enum 
{
    kNutritionOrderStatusRequested, // TODO.
    kNutritionOrderStatusActive, // TODO.
    kNutritionOrderStatusInactive, // TODO.
    kNutritionOrderStatusHeld, // TODO.
    kNutritionOrderStatusCancelled, // TODO.
} kNutritionOrderStatus;

/*
 * The person who requires the diet, formula or nutritional supplement
 */
@property (nonatomic, strong) FHIRReference *subject;

/*
 * Who ordered the diet, formula or nutritional supplement
 */
@property (nonatomic, strong) FHIRReference *orderer;

/*
 * Identifiers assigned to this order
 */
@property (nonatomic, strong) NSArray/*<Identifier>*/ *identifier;

/*
 * The encounter associated with that this nutrition order
 */
@property (nonatomic, strong) FHIRReference *encounter;

/*
 * Date and time the nutrition order was requested
 */
@property (nonatomic, strong) FHIRDateTime *dateTimeElement;

@property (nonatomic, strong) NSString *dateTime;

/*
 * List of the patient's food and nutrition-related allergies and intolerances
 */
@property (nonatomic, strong) NSArray/*<Reference>*/ *allergyIntolerance;

/*
 * Order-specific modifier about the type of food that should be given
 */
@property (nonatomic, strong) NSArray/*<CodeableConcept>*/ *foodPreferenceModifier;

/*
 * Order-specific modifier about the type of food that should not be given
 */
@property (nonatomic, strong) NSArray/*<CodeableConcept>*/ *excludeFoodModifier;

/*
 * Set of nutrition items or components that comprise the nutrition order
 */
@property (nonatomic, strong) NSArray/*<NutritionOrderItemComponent>*/ *item;

/*
 * requested | active | inactive | held | cancelled
 */
@property (nonatomic, strong) FHIRCode/*<code>*/ *statusElement;

@property (nonatomic) kNutritionOrderStatus status;

- (FHIRErrorList *)validate;

@end
