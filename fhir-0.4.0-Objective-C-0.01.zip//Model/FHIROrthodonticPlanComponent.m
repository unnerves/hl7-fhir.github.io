﻿/*
  Copyright (c) 2011+, HL7, Inc.
  All rights reserved.
  
  Redistribution and use in source and binary forms, with or without modification, 
  are permitted provided that the following conditions are met:
  
   * Redistributions of source code must retain the above copyright notice, this 
     list of conditions and the following disclaimer.
   * Redistributions in binary form must reproduce the above copyright notice, 
     this list of conditions and the following disclaimer in the documentation 
     and/or other materials provided with the distribution.
   * Neither the name of HL7 nor the names of its contributors may be used to 
     endorse or promote products derived from this software without specific 
     prior written permission.
  
  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND 
  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
  WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
  IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
  INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT 
  NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR 
  PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
  WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
  POSSIBILITY OF SUCH DAMAGE.
  

 * Generated on Tue, Dec 30, 2014 10:55+0000 for FHIR v0.4.0
 */
/*
 * null
 */
#import "FHIROrthodonticPlanComponent.h"

#import "FHIRDate.h"
#import "FHIRMoney.h"
#import "FHIRInteger.h"

#import "FHIRErrorList.h"

@implementation FHIROrthodonticPlanComponent

- (NSString *)start
{
    if(self.startElement)
    {
        return [self.startElement value];
    }
    return nil;
}

- (void )setStart:(NSString *)start
{
    if(start)
    {
        [self setStartElement:[[FHIRDate alloc] initWithValue:start]];
    }
    else
    {
        [self setStartElement:nil];
    }
}


- (NSNumber *)durationMonths
{
    if(self.durationMonthsElement)
    {
        return [self.durationMonthsElement value];
    }
    return nil;
}

- (void )setDurationMonths:(NSNumber *)durationMonths
{
    if(durationMonths)
    {
        [self setDurationMonthsElement:[[FHIRInteger alloc] initWithValue:durationMonths]];
    }
    else
    {
        [self setDurationMonthsElement:nil];
    }
}


- (NSNumber *)paymentCount
{
    if(self.paymentCountElement)
    {
        return [self.paymentCountElement value];
    }
    return nil;
}

- (void )setPaymentCount:(NSNumber *)paymentCount
{
    if(paymentCount)
    {
        [self setPaymentCountElement:[[FHIRInteger alloc] initWithValue:paymentCount]];
    }
    else
    {
        [self setPaymentCountElement:nil];
    }
}


- (FHIRErrorList *)validate
{
    FHIRErrorList *result = [[FHIRErrorList alloc] init];
    
    [result addValidation:[super validate]];
    
    if(self.startElement != nil )
        [result addValidationRange:[self.startElement validate]];
    if(self.examFee != nil )
        [result addValidationRange:[self.examFee validate]];
    if(self.diagnosticFee != nil )
        [result addValidationRange:[self.diagnosticFee validate]];
    if(self.initialPayment != nil )
        [result addValidationRange:[self.initialPayment validate]];
    if(self.durationMonthsElement != nil )
        [result addValidationRange:[self.durationMonthsElement validate]];
    if(self.paymentCountElement != nil )
        [result addValidationRange:[self.paymentCountElement validate]];
    if(self.periodicPayment != nil )
        [result addValidationRange:[self.periodicPayment validate]];
    
    return result;
}

@end
