﻿/*
  Copyright (c) 2011+, HL7, Inc.
  All rights reserved.
  
  Redistribution and use in source and binary forms, with or without modification, 
  are permitted provided that the following conditions are met:
  
   * Redistributions of source code must retain the above copyright notice, this 
     list of conditions and the following disclaimer.
   * Redistributions in binary form must reproduce the above copyright notice, 
     this list of conditions and the following disclaimer in the documentation 
     and/or other materials provided with the distribution.
   * Neither the name of HL7 nor the names of its contributors may be used to 
     endorse or promote products derived from this software without specific 
     prior written permission.
  
  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND 
  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
  WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
  IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
  INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT 
  NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR 
  PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
  WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
  POSSIBILITY OF SUCH DAMAGE.
  

 * Generated on Tue, Dec 30, 2014 10:55+0000 for FHIR v0.4.0
 */
/*
 * An interaction during which services are provided to the patient
 *
 * [FhirReference("Encounter")]
 * [Serializable]
 */

#import "FHIRDomainResource.h"


@class FHIRIdentifier;
@class FHIRCode;
@class FHIREncounterStatusHistoryComponent;
@class FHIRCodeableConcept;
@class FHIRReference;
@class FHIREncounterParticipantComponent;
@class FHIRPeriod;
@class FHIRDuration;
@class FHIREncounterHospitalizationComponent;
@class FHIREncounterLocationComponent;

@interface FHIREncounter : FHIRDomainResource

/*
 * Classification of the encounter
 */
typedef enum 
{
    kEncounterClassInpatient, // An encounter during which the patient is hospitalized and stays overnight.
    kEncounterClassOutpatient, // An encounter during which the patient is not hospitalized overnight.
    kEncounterClassAmbulatory, // An encounter where the patient visits the practitioner in his/her office, e.g. a G.P. visit.
    kEncounterClassEmergency, // An encounter where the patient needs urgent care.
    kEncounterClassHome, // An encounter where the practitioner visits the patient at his/her home.
    kEncounterClassField, // An encounter taking place outside the regular environment for giving care.
    kEncounterClassDaytime, // An encounter where the patient needs more prolonged treatment or investigations than outpatients, but who do not need to stay in the hospital overnight.
    kEncounterClassVirtual, // An encounter that takes place where the patient and practitioner do not physically meet but use electronic means for contact.
    kEncounterClassOther, // Any other encounter type that is not described by one of the other values. Where this is used it is expected that an implementer will include an extension value to define what the actual other type is.
} kEncounterClass;

/*
 * The status of the location
 */
typedef enum 
{
    kEncounterLocationStatusPlanned, // The patient is planned to be moved to this location at some point in the future.
    kEncounterLocationStatusPresent, // The patient is currently at this location, or was between the period specified.
    kEncounterLocationStatusReserved, // This location is held empty for this patient.
} kEncounterLocationStatus;

/*
 * Current state of the encounter
 */
typedef enum 
{
    kEncounterStatePlanned, // The Encounter has not yet started.
    kEncounterStateArrived, // The Patient is present for the encounter, however is not currently meeting with a practitioner.
    kEncounterStateInProgress, // The Encounter has begun and the patient is present / the practitioner and the patient are meeting.
    kEncounterStateOnleave, // The Encounter has begun, but the patient is temporarily on leave.
    kEncounterStateFinished, // The Encounter has ended.
    kEncounterStateCancelled, // The Encounter has ended before it has begun.
} kEncounterState;

/*
 * Identifier(s) by which this encounter is known
 */
@property (nonatomic, strong) NSArray/*<Identifier>*/ *identifier;

/*
 * planned | arrived | in progress | onleave | finished | cancelled
 */
@property (nonatomic, strong) FHIRCode/*<code>*/ *statusElement;

@property (nonatomic) kEncounterState status;

/*
 * List of Encounter statuses
 */
@property (nonatomic, strong) NSArray/*<EncounterStatusHistoryComponent>*/ *statusHistory;

/*
 * inpatient | outpatient | ambulatory | emergency +
 */
@property (nonatomic, strong) FHIRCode/*<code>*/ *class_Element;

@property (nonatomic) kEncounterClass class_;

/*
 * Specific type of encounter
 */
@property (nonatomic, strong) NSArray/*<CodeableConcept>*/ *type;

/*
 * The patient present at the encounter
 */
@property (nonatomic, strong) FHIRReference *patient;

/*
 * An episode of care that this encounter should be recorded against
 */
@property (nonatomic, strong) FHIRReference *episodeOfCare;

/*
 * List of participants involved in the encounter
 */
@property (nonatomic, strong) NSArray/*<EncounterParticipantComponent>*/ *participant;

/*
 * The appointment that scheduled this encounter
 */
@property (nonatomic, strong) FHIRReference *fulfills;

/*
 * The start and end time of the encounter
 */
@property (nonatomic, strong) FHIRPeriod *period;

/*
 * Quantity of time the encounter lasted
 */
@property (nonatomic, strong) FHIRDuration *length;

/*
 * Reason the encounter takes place (code)
 */
@property (nonatomic, strong) FHIRCodeableConcept *reason;

/*
 * Reason the encounter takes place (resource)
 */
@property (nonatomic, strong) NSArray/*<Reference>*/ *indication;

/*
 * Indicates the urgency of the encounter
 */
@property (nonatomic, strong) FHIRCodeableConcept *priority;

/*
 * Details about an admission to a clinic
 */
@property (nonatomic, strong) FHIREncounterHospitalizationComponent *hospitalization;

/*
 * List of locations the patient has been at
 */
@property (nonatomic, strong) NSArray/*<EncounterLocationComponent>*/ *location;

/*
 * Department or team providing care
 */
@property (nonatomic, strong) FHIRReference *serviceProvider;

/*
 * Another Encounter this encounter is part of
 */
@property (nonatomic, strong) FHIRReference *partOf;

- (FHIRErrorList *)validate;

@end
