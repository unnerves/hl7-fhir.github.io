﻿/*
  Copyright (c) 2011+, HL7, Inc.
  All rights reserved.
  
  Redistribution and use in source and binary forms, with or without modification, 
  are permitted provided that the following conditions are met:
  
   * Redistributions of source code must retain the above copyright notice, this 
     list of conditions and the following disclaimer.
   * Redistributions in binary form must reproduce the above copyright notice, 
     this list of conditions and the following disclaimer in the documentation 
     and/or other materials provided with the distribution.
   * Neither the name of HL7 nor the names of its contributors may be used to 
     endorse or promote products derived from this software without specific 
     prior written permission.
  
  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND 
  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
  WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
  IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
  INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT 
  NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR 
  PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
  WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
  POSSIBILITY OF SUCH DAMAGE.
  

 * Generated on Tue, Dec 30, 2014 10:55+0000 for FHIR v0.4.0
 */
/*
 * An association of a Patient with an Organization and  Healthcare Provider(s) for a period of time that the Organization assumes some level of responsibility
 */
#import "FHIREpisodeOfCare.h"

#import "FHIRIdentifier.h"
#import "FHIRCode.h"
#import "FHIREpisodeOfCareStatusHistoryComponent.h"
#import "FHIRCodeableConcept.h"
#import "FHIRReference.h"
#import "FHIRPeriod.h"
#import "FHIREpisodeOfCareCareTeamComponent.h"

#import "FHIRErrorList.h"

@implementation FHIREpisodeOfCare

- (kEpisodeOfCareStatus )currentStatus
{
    return [FHIREnumHelper parseString:[self.currentStatusElement value] enumType:kEnumTypeEpisodeOfCareStatus];
}

- (void )setCurrentStatus:(kEpisodeOfCareStatus )currentStatus
{
    [self setCurrentStatusElement:[[FHIRCode/*<code>*/ alloc] initWithValue:[FHIREnumHelper enumToString:currentStatus enumType:kEnumTypeEpisodeOfCareStatus]]];
}


- (FHIRErrorList *)validate
{
    FHIRErrorList *result = [[FHIRErrorList alloc] init];
    
    [result addValidation:[super validate]];
    
    if(self.identifier != nil )
        for(FHIRIdentifier *elem in self.identifier)
            [result addValidationRange:[elem validate]];
    if(self.currentStatusElement != nil )
        [result addValidationRange:[self.currentStatusElement validate]];
    if(self.statusHistory != nil )
        for(FHIREpisodeOfCareStatusHistoryComponent *elem in self.statusHistory)
            [result addValidationRange:[elem validate]];
    if(self.type != nil )
        for(FHIRCodeableConcept *elem in self.type)
            [result addValidationRange:[elem validate]];
    if(self.patient != nil )
        [result addValidationRange:[self.patient validate]];
    if(self.managingOrganization != nil )
        [result addValidationRange:[self.managingOrganization validate]];
    if(self.period != nil )
        [result addValidationRange:[self.period validate]];
    if(self.condition != nil )
        for(FHIRReference *elem in self.condition)
            [result addValidationRange:[elem validate]];
    if(self.referralRequest != nil )
        [result addValidationRange:[self.referralRequest validate]];
    if(self.careManager != nil )
        [result addValidationRange:[self.careManager validate]];
    if(self.careTeam != nil )
        for(FHIREpisodeOfCareCareTeamComponent *elem in self.careTeam)
            [result addValidationRange:[elem validate]];
    
    return result;
}

@end
