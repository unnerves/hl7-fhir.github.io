﻿/*
  Copyright (c) 2011+, HL7, Inc.
  All rights reserved.
  
  Redistribution and use in source and binary forms, with or without modification, 
  are permitted provided that the following conditions are met:
  
   * Redistributions of source code must retain the above copyright notice, this 
     list of conditions and the following disclaimer.
   * Redistributions in binary form must reproduce the above copyright notice, 
     this list of conditions and the following disclaimer in the documentation 
     and/or other materials provided with the distribution.
   * Neither the name of HL7 nor the names of its contributors may be used to 
     endorse or promote products derived from this software without specific 
     prior written permission.
  
  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND 
  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
  WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
  IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
  INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT 
  NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR 
  PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
  WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
  POSSIBILITY OF SUCH DAMAGE.
  

 * Generated on Tue, Dec 30, 2014 10:55+0000 for FHIR v0.4.0
 */
/*
 * Communication Request
 *
 * [FhirReference("CommunicationRequest")]
 * [Serializable]
 */

#import "FHIRDomainResource.h"


@class FHIRIdentifier;
@class FHIRCodeableConcept;
@class FHIRReference;
@class FHIRCommunicationRequestPayloadComponent;
@class FHIRCode;
@class FHIRDateTime;

@interface FHIRCommunicationRequest : FHIRDomainResource

/*
 * The status of the communication
 */
typedef enum 
{
    kCommunicationRequestStatusProposed, // The request has been proposed.
    kCommunicationRequestStatusPlanned, // The request has been planned.
    kCommunicationRequestStatusRequested, // The request has been placed.
    kCommunicationRequestStatusReceived, // The receiving system has received the request but not yet decided whether it will be performed.
    kCommunicationRequestStatusAccepted, // The receiving system has accepted the order, but work has not yet commenced.
    kCommunicationRequestStatusInProgress, // The work to fulfill the order is happening.
    kCommunicationRequestStatusCompleted, // The work has been complete, the report(s) released, and no further work is planned.
    kCommunicationRequestStatusSuspended, // The request has been held by originating system/user request.
    kCommunicationRequestStatusRejected, // The receiving system has declined to fulfill the request.
    kCommunicationRequestStatusFailed, // The communication was attempted, but due to some procedural error, it could not be completed.
} kCommunicationRequestStatus;

/*
 * Unique identifier
 */
@property (nonatomic, strong) NSArray/*<Identifier>*/ *identifier;

/*
 * Message category
 */
@property (nonatomic, strong) FHIRCodeableConcept *category;

/*
 * Message sender
 */
@property (nonatomic, strong) FHIRReference *sender;

/*
 * Message recipient
 */
@property (nonatomic, strong) NSArray/*<Reference>*/ *recipient;

/*
 * Message payload
 */
@property (nonatomic, strong) NSArray/*<CommunicationRequestPayloadComponent>*/ *payload;

/*
 * Communication medium
 */
@property (nonatomic, strong) NSArray/*<CodeableConcept>*/ *medium;

/*
 * Requester of communication
 */
@property (nonatomic, strong) FHIRReference *requester;

/*
 * proposed | planned | requested | received | accepted | in progress | completed | suspended | rejected | failed
 */
@property (nonatomic, strong) FHIRCode/*<code>*/ *statusElement;

@property (nonatomic) kCommunicationRequestStatus status;

/*
 * Encounter leading to message
 */
@property (nonatomic, strong) FHIRReference *encounter;

/*
 * When scheduled
 */
@property (nonatomic, strong) FHIRDateTime *scheduledTimeElement;

@property (nonatomic, strong) NSString *scheduledTime;

/*
 * Indication for message
 */
@property (nonatomic, strong) NSArray/*<CodeableConcept>*/ *reason;

/*
 * When ordered or proposed
 */
@property (nonatomic, strong) FHIRDateTime *orderedOnElement;

@property (nonatomic, strong) NSString *orderedOn;

/*
 * Focus of message
 */
@property (nonatomic, strong) FHIRReference *subject;

/*
 * Message urgency
 */
@property (nonatomic, strong) FHIRCodeableConcept *priority;

- (FHIRErrorList *)validate;

@end
