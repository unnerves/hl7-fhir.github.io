﻿/*
  Copyright (c) 2011+, HL7, Inc.
  All rights reserved.
  
  Redistribution and use in source and binary forms, with or without modification, 
  are permitted provided that the following conditions are met:
  
   * Redistributions of source code must retain the above copyright notice, this 
     list of conditions and the following disclaimer.
   * Redistributions in binary form must reproduce the above copyright notice, 
     this list of conditions and the following disclaimer in the documentation 
     and/or other materials provided with the distribution.
   * Neither the name of HL7 nor the names of its contributors may be used to 
     endorse or promote products derived from this software without specific 
     prior written permission.
  
  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND 
  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
  WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
  IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
  INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT 
  NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR 
  PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
  WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
  POSSIBILITY OF SUCH DAMAGE.
  

 * Generated on Tue, Dec 30, 2014 10:55+0000 for FHIR v0.4.0
 */
/*
 * Claim, Pre-determination or Pre-authorization
 */
#import "FHIROralHealthClaim.h"

#import "FHIRIdentifier.h"
#import "FHIRCoding.h"
#import "FHIRDateTime.h"
#import "FHIRReference.h"
#import "FHIRCode.h"
#import "FHIRPayeeComponent.h"
#import "FHIRDiagnosisComponent.h"
#import "FHIRCoverageComponent.h"
#import "FHIRString.h"
#import "FHIRDate.h"
#import "FHIRMissingTeethComponent.h"
#import "FHIROrthodonticPlanComponent.h"
#import "FHIRItemsComponent.h"

#import "FHIRErrorList.h"

@implementation FHIROralHealthClaim

- (NSString *)created
{
    if(self.createdElement)
    {
        return [self.createdElement value];
    }
    return nil;
}

- (void )setCreated:(NSString *)created
{
    if(created)
    {
        [self setCreatedElement:[[FHIRDateTime alloc] initWithValue:created]];
    }
    else
    {
        [self setCreatedElement:nil];
    }
}


- (kUse )use
{
    return [FHIREnumHelper parseString:[self.useElement value] enumType:kEnumTypeUse];
}

- (void )setUse:(kUse )use
{
    [self setUseElement:[[FHIRCode/*<code>*/ alloc] initWithValue:[FHIREnumHelper enumToString:use enumType:kEnumTypeUse]]];
}


- (NSString *)school
{
    if(self.schoolElement)
    {
        return [self.schoolElement value];
    }
    return nil;
}

- (void )setSchool:(NSString *)school
{
    if(school)
    {
        [self setSchoolElement:[[FHIRString alloc] initWithValue:school]];
    }
    else
    {
        [self setSchoolElement:nil];
    }
}


- (NSString *)accident
{
    if(self.accidentElement)
    {
        return [self.accidentElement value];
    }
    return nil;
}

- (void )setAccident:(NSString *)accident
{
    if(accident)
    {
        [self setAccidentElement:[[FHIRDate alloc] initWithValue:accident]];
    }
    else
    {
        [self setAccidentElement:nil];
    }
}


- (FHIRErrorList *)validate
{
    FHIRErrorList *result = [[FHIRErrorList alloc] init];
    
    [result addValidation:[super validate]];
    
    if(self.identifier != nil )
        for(FHIRIdentifier *elem in self.identifier)
            [result addValidationRange:[elem validate]];
    if(self.ruleset != nil )
        [result addValidationRange:[self.ruleset validate]];
    if(self.originalRuleset != nil )
        [result addValidationRange:[self.originalRuleset validate]];
    if(self.createdElement != nil )
        [result addValidationRange:[self.createdElement validate]];
    if(self.target != nil )
        [result addValidationRange:[self.target validate]];
    if(self.provider != nil )
        [result addValidationRange:[self.provider validate]];
    if(self.organization != nil )
        [result addValidationRange:[self.organization validate]];
    if(self.useElement != nil )
        [result addValidationRange:[self.useElement validate]];
    if(self.priority != nil )
        [result addValidationRange:[self.priority validate]];
    if(self.fundsReserve != nil )
        [result addValidationRange:[self.fundsReserve validate]];
    if(self.enterer != nil )
        [result addValidationRange:[self.enterer validate]];
    if(self.facility != nil )
        [result addValidationRange:[self.facility validate]];
    if(self.payee != nil )
        [result addValidationRange:[self.payee validate]];
    if(self.referral != nil )
        [result addValidationRange:[self.referral validate]];
    if(self.diagnosis != nil )
        for(FHIRDiagnosisComponent *elem in self.diagnosis)
            [result addValidationRange:[elem validate]];
    if(self.condition != nil )
        for(FHIRCoding *elem in self.condition)
            [result addValidationRange:[elem validate]];
    if(self.patient != nil )
        [result addValidationRange:[self.patient validate]];
    if(self.coverage != nil )
        for(FHIRCoverageComponent *elem in self.coverage)
            [result addValidationRange:[elem validate]];
    if(self.exception != nil )
        for(FHIRCoding *elem in self.exception)
            [result addValidationRange:[elem validate]];
    if(self.schoolElement != nil )
        [result addValidationRange:[self.schoolElement validate]];
    if(self.accidentElement != nil )
        [result addValidationRange:[self.accidentElement validate]];
    if(self.accidentType != nil )
        [result addValidationRange:[self.accidentType validate]];
    if(self.interventionException != nil )
        for(FHIRCoding *elem in self.interventionException)
            [result addValidationRange:[elem validate]];
    if(self.missingteeth != nil )
        for(FHIRMissingTeethComponent *elem in self.missingteeth)
            [result addValidationRange:[elem validate]];
    if(self.orthoPlan != nil )
        [result addValidationRange:[self.orthoPlan validate]];
    if(self.item != nil )
        for(FHIRItemsComponent *elem in self.item)
            [result addValidationRange:[elem validate]];
    if(self.additionalMaterials != nil )
        for(FHIRCoding *elem in self.additionalMaterials)
            [result addValidationRange:[elem validate]];
    
    return result;
}

@end
