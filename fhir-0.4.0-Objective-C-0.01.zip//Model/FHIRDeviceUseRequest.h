﻿/*
  Copyright (c) 2011+, HL7, Inc.
  All rights reserved.
  
  Redistribution and use in source and binary forms, with or without modification, 
  are permitted provided that the following conditions are met:
  
   * Redistributions of source code must retain the above copyright notice, this 
     list of conditions and the following disclaimer.
   * Redistributions in binary form must reproduce the above copyright notice, 
     this list of conditions and the following disclaimer in the documentation 
     and/or other materials provided with the distribution.
   * Neither the name of HL7 nor the names of its contributors may be used to 
     endorse or promote products derived from this software without specific 
     prior written permission.
  
  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND 
  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
  WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
  IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
  INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT 
  NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR 
  PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
  WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
  POSSIBILITY OF SUCH DAMAGE.
  

 * Generated on Tue, Dec 30, 2014 10:55+0000 for FHIR v0.4.0
 */
/*
 * Request for device use
 *
 * [FhirReference("DeviceUseRequest")]
 * [Serializable]
 */

#import "FHIRDomainResource.h"


@class FHIRCodeableConcept;
@class FHIRCode;
@class FHIRReference;
@class FHIRIdentifier;
@class FHIRString;
@class FHIRDateTime;
@class FHIRElement;

@interface FHIRDeviceUseRequest : FHIRDomainResource

/*
 * Codes representing the status of the request
 */
typedef enum 
{
    kDeviceUseRequestStatusProposed, // The request has been proposed.
    kDeviceUseRequestStatusPlanned, // The request has been planned.
    kDeviceUseRequestStatusRequested, // The request has been placed.
    kDeviceUseRequestStatusReceived, // The receiving system has received the request but not yet decided whether it will be performed.
    kDeviceUseRequestStatusAccepted, // The receiving system has accepted the request but work has not yet commenced.
    kDeviceUseRequestStatusInProgress, // The work to fulfill the order is happening.
    kDeviceUseRequestStatusCompleted, // The work has been complete, the report(s) released, and no further work is planned.
    kDeviceUseRequestStatusSuspended, // The request has been held by originating system/user request.
    kDeviceUseRequestStatusRejected, // The receiving system has declined to fulfill the request.
    kDeviceUseRequestStatusAborted, // The request was attempted, but due to some procedural error, it could not be completed.
} kDeviceUseRequestStatus;

/*
 * Codes representing the priority of the request
 */
typedef enum 
{
    kDeviceUseRequestPriorityRoutine, // The request has a normal priority.
    kDeviceUseRequestPriorityUrgent, // The request should be done urgently.
    kDeviceUseRequestPriorityStat, // The request is time-critical.
    kDeviceUseRequestPriorityAsap, // The request should be acted on as soon as possible.
} kDeviceUseRequestPriority;

/*
 * Target body site
 */
@property (nonatomic, strong) NSArray/*<CodeableConcept>*/ *bodySite;

/*
 * proposed | planned | requested | received | accepted | in progress | completed | suspended | rejected | aborted
 */
@property (nonatomic, strong) FHIRCode/*<code>*/ *statusElement;

@property (nonatomic) kDeviceUseRequestStatus status;

/*
 * Device requested
 */
@property (nonatomic, strong) FHIRReference *device;

/*
 * Encounter motivating request
 */
@property (nonatomic, strong) FHIRReference *encounter;

/*
 * Request identifier
 */
@property (nonatomic, strong) NSArray/*<Identifier>*/ *identifier;

/*
 * Reason for request
 */
@property (nonatomic, strong) NSArray/*<CodeableConcept>*/ *indication;

/*
 * Notes or comments
 */
@property (nonatomic, strong) NSArray/*<string>*/ *notesElement;

@property (nonatomic, strong) NSArray /*<NSString>*/ *notes;

/*
 * PRN
 */
@property (nonatomic, strong) NSArray/*<CodeableConcept>*/ *prnReason;

/*
 * When ordered
 */
@property (nonatomic, strong) FHIRDateTime *orderedOnElement;

@property (nonatomic, strong) NSString *orderedOn;

/*
 * When recorded
 */
@property (nonatomic, strong) FHIRDateTime *recordedOnElement;

@property (nonatomic, strong) NSString *recordedOn;

/*
 * Focus of request
 */
@property (nonatomic, strong) FHIRReference *subject;

/*
 * Schedule for use
 */
@property (nonatomic, strong) FHIRElement *timing;

/*
 * routine | urgent | stat | asap
 */
@property (nonatomic, strong) FHIRCode/*<code>*/ *priorityElement;

@property (nonatomic) kDeviceUseRequestPriority priority;

- (FHIRErrorList *)validate;

@end
