﻿/*
  Copyright (c) 2011+, HL7, Inc.
  All rights reserved.
  
  Redistribution and use in source and binary forms, with or without modification, 
  are permitted provided that the following conditions are met:
  
   * Redistributions of source code must retain the above copyright notice, this 
     list of conditions and the following disclaimer.
   * Redistributions in binary form must reproduce the above copyright notice, 
     this list of conditions and the following disclaimer in the documentation 
     and/or other materials provided with the distribution.
   * Neither the name of HL7 nor the names of its contributors may be used to 
     endorse or promote products derived from this software without specific 
     prior written permission.
  
  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND 
  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
  WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
  IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
  INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT 
  NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR 
  PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
  WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
  POSSIBILITY OF SUCH DAMAGE.
  

 * Generated on Tue, Dec 30, 2014 10:55+0000 for FHIR v0.4.0
 */
/*
 * The details of a Healthcare Service available at a location
 *
 * [FhirReference("HealthcareService")]
 * [Serializable]
 */

#import "FHIRDomainResource.h"


@class FHIRIdentifier;
@class FHIRReference;
@class FHIRCodeableConcept;
@class FHIRServiceTypeComponent;
@class FHIRString;
@class FHIRUri;
@class FHIRHealthcareServiceAvailableTimeComponent;
@class FHIRHealthcareServiceNotAvailableTimeComponent;
@class FHIRContactPoint;

@interface FHIRHealthcareService : FHIRDomainResource

/*
 * External Ids for this item
 */
@property (nonatomic, strong) NSArray/*<Identifier>*/ *identifier;

/*
 * The location where this healthcare service may be provided
 */
@property (nonatomic, strong) FHIRReference *location;

/*
 * Identifies the broad category of service being performed or delivered. Selecting a Service Category then determines the list of relevant service types that can be selected in the Primary Service Type
 */
@property (nonatomic, strong) FHIRCodeableConcept *serviceCategory;

/*
 * A specific type of service that may be delivered or performed
 */
@property (nonatomic, strong) NSArray/*<ServiceTypeComponent>*/ *serviceType;

/*
 * Further description of the service as it would be presented to a consumer while searching
 */
@property (nonatomic, strong) FHIRString *serviceNameElement;

@property (nonatomic, strong) NSString *serviceName;

/*
 * Additional description of the  or any specific issues not covered by the other attributes, which can be displayed as further detail under the serviceName
 */
@property (nonatomic, strong) FHIRString *commentElement;

@property (nonatomic, strong) NSString *comment;

/*
 * Extra details about the service that can't be placed in the other fields
 */
@property (nonatomic, strong) FHIRString *extraDetailsElement;

@property (nonatomic, strong) NSString *extraDetails;

/*
 * The free provision code provides a link to the Free Provision reference entity to enable the selection of one free provision type
 */
@property (nonatomic, strong) FHIRCodeableConcept *freeProvisionCode;

/*
 * Does this service have specific eligibility requirements that need to be met in order to use the service
 */
@property (nonatomic, strong) FHIRCodeableConcept *eligibility;

/*
 * Describes the eligibility conditions for the service
 */
@property (nonatomic, strong) FHIRString *eligibilityNoteElement;

@property (nonatomic, strong) NSString *eligibilityNote;

/*
 * Indicates whether or not a prospective consumer will require an appointment for a particular service at a Site to be provided by the Organization. Indicates if an appointment is required for access to this service. If this flag is 'NotDefined', then this flag is overridden by the Site's availability flag. (ConditionalIndicator Enum)
 */
@property (nonatomic, strong) FHIRCodeableConcept *appointmentRequired;

/*
 * If there is an image associated with this Service Site, its URI can be included here
 */
@property (nonatomic, strong) FHIRUri *imageURIElement;

@property (nonatomic, strong) NSString *imageURI;

/*
 * A Collection of times that the Service Site is available
 */
@property (nonatomic, strong) NSArray/*<HealthcareServiceAvailableTimeComponent>*/ *availableTime;

/*
 * Not avail times - need better description
 */
@property (nonatomic, strong) NSArray/*<HealthcareServiceNotAvailableTimeComponent>*/ *notAvailableTime;

/*
 * A description of Site availability exceptions, e.g., public holiday availability. Succinctly describing all possible exceptions to normal Site availability as details in the Available Times and Not Available Times
 */
@property (nonatomic, strong) FHIRString *availabilityExceptionsElement;

@property (nonatomic, strong) NSString *availabilityExceptions;

/*
 * The public part of the 'keys' allocated to an Organization by an accredited body to support secure exchange of data over the internet. To be provided by the Organization, where available
 */
@property (nonatomic, strong) FHIRString *publicKeyElement;

@property (nonatomic, strong) NSString *publicKey;

/*
 * Program Names that can be used to categorize the service
 */
@property (nonatomic, strong) NSArray/*<string>*/ *programNameElement;

@property (nonatomic, strong) NSArray /*<NSString>*/ *programName;

/*
 * List of contacts related to this specific healthcare service. If this is empty, then refer to the location's contacts
 */
@property (nonatomic, strong) NSArray/*<ContactPoint>*/ *contactPoint;

/*
 * Collection of Characteristics (attributes)
 */
@property (nonatomic, strong) NSArray/*<CodeableConcept>*/ *characteristic;

/*
 * Ways that the service accepts referrals
 */
@property (nonatomic, strong) NSArray/*<CodeableConcept>*/ *referralMethod;

/*
 * The setting where this service can be provided, such is in home, or at location in organisation
 */
@property (nonatomic, strong) NSArray/*<CodeableConcept>*/ *setting;

/*
 * Collection of Target Groups for the Service Site (The target audience that this service is for)
 */
@property (nonatomic, strong) NSArray/*<CodeableConcept>*/ *targetGroup;

/*
 * Need better description
 */
@property (nonatomic, strong) NSArray/*<CodeableConcept>*/ *coverageArea;

/*
 * Need better description
 */
@property (nonatomic, strong) NSArray/*<CodeableConcept>*/ *catchmentArea;

/*
 * List of the specific
 */
@property (nonatomic, strong) NSArray/*<CodeableConcept>*/ *serviceCode;

- (FHIRErrorList *)validate;

@end
