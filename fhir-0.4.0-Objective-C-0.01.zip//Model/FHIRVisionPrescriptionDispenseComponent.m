﻿/*
  Copyright (c) 2011+, HL7, Inc.
  All rights reserved.
  
  Redistribution and use in source and binary forms, with or without modification, 
  are permitted provided that the following conditions are met:
  
   * Redistributions of source code must retain the above copyright notice, this 
     list of conditions and the following disclaimer.
   * Redistributions in binary form must reproduce the above copyright notice, 
     this list of conditions and the following disclaimer in the documentation 
     and/or other materials provided with the distribution.
   * Neither the name of HL7 nor the names of its contributors may be used to 
     endorse or promote products derived from this software without specific 
     prior written permission.
  
  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND 
  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
  WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
  IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
  INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT 
  NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR 
  PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
  WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
  POSSIBILITY OF SUCH DAMAGE.
  

 * Generated on Tue, Dec 30, 2014 10:55+0000 for FHIR v0.4.0
 */
/*
 * null
 */
#import "FHIRVisionPrescriptionDispenseComponent.h"

#import "FHIRCoding.h"
#import "FHIRCode.h"
#import "FHIRDecimal.h"
#import "FHIRInteger.h"
#import "FHIRQuantity.h"
#import "FHIRString.h"

#import "FHIRErrorList.h"

@implementation FHIRVisionPrescriptionDispenseComponent

- (kVisionEyes )eye
{
    return [FHIREnumHelper parseString:[self.eyeElement value] enumType:kEnumTypeVisionEyes];
}

- (void )setEye:(kVisionEyes )eye
{
    [self setEyeElement:[[FHIRCode/*<code>*/ alloc] initWithValue:[FHIREnumHelper enumToString:eye enumType:kEnumTypeVisionEyes]]];
}


- (NSDecimalNumber *)sphere
{
    if(self.sphereElement)
    {
        return [self.sphereElement value];
    }
    return nil;
}

- (void )setSphere:(NSDecimalNumber *)sphere
{
    if(sphere)
    {
        [self setSphereElement:[[FHIRDecimal alloc] initWithValue:sphere]];
    }
    else
    {
        [self setSphereElement:nil];
    }
}


- (NSDecimalNumber *)cylinder
{
    if(self.cylinderElement)
    {
        return [self.cylinderElement value];
    }
    return nil;
}

- (void )setCylinder:(NSDecimalNumber *)cylinder
{
    if(cylinder)
    {
        [self setCylinderElement:[[FHIRDecimal alloc] initWithValue:cylinder]];
    }
    else
    {
        [self setCylinderElement:nil];
    }
}


- (NSNumber *)axis
{
    if(self.axisElement)
    {
        return [self.axisElement value];
    }
    return nil;
}

- (void )setAxis:(NSNumber *)axis
{
    if(axis)
    {
        [self setAxisElement:[[FHIRInteger alloc] initWithValue:axis]];
    }
    else
    {
        [self setAxisElement:nil];
    }
}


- (NSDecimalNumber *)prism
{
    if(self.prismElement)
    {
        return [self.prismElement value];
    }
    return nil;
}

- (void )setPrism:(NSDecimalNumber *)prism
{
    if(prism)
    {
        [self setPrismElement:[[FHIRDecimal alloc] initWithValue:prism]];
    }
    else
    {
        [self setPrismElement:nil];
    }
}


- (kVisionBase )base_
{
    return [FHIREnumHelper parseString:[self.base_Element value] enumType:kEnumTypeVisionBase];
}

- (void )setBase_:(kVisionBase )base_
{
    [self setBase_Element:[[FHIRCode/*<code>*/ alloc] initWithValue:[FHIREnumHelper enumToString:base_ enumType:kEnumTypeVisionBase]]];
}


- (NSDecimalNumber *)add
{
    if(self.addElement)
    {
        return [self.addElement value];
    }
    return nil;
}

- (void )setAdd:(NSDecimalNumber *)add
{
    if(add)
    {
        [self setAddElement:[[FHIRDecimal alloc] initWithValue:add]];
    }
    else
    {
        [self setAddElement:nil];
    }
}


- (NSDecimalNumber *)power
{
    if(self.powerElement)
    {
        return [self.powerElement value];
    }
    return nil;
}

- (void )setPower:(NSDecimalNumber *)power
{
    if(power)
    {
        [self setPowerElement:[[FHIRDecimal alloc] initWithValue:power]];
    }
    else
    {
        [self setPowerElement:nil];
    }
}


- (NSDecimalNumber *)backCurve
{
    if(self.backCurveElement)
    {
        return [self.backCurveElement value];
    }
    return nil;
}

- (void )setBackCurve:(NSDecimalNumber *)backCurve
{
    if(backCurve)
    {
        [self setBackCurveElement:[[FHIRDecimal alloc] initWithValue:backCurve]];
    }
    else
    {
        [self setBackCurveElement:nil];
    }
}


- (NSDecimalNumber *)diameter
{
    if(self.diameterElement)
    {
        return [self.diameterElement value];
    }
    return nil;
}

- (void )setDiameter:(NSDecimalNumber *)diameter
{
    if(diameter)
    {
        [self setDiameterElement:[[FHIRDecimal alloc] initWithValue:diameter]];
    }
    else
    {
        [self setDiameterElement:nil];
    }
}


- (NSString *)color
{
    if(self.colorElement)
    {
        return [self.colorElement value];
    }
    return nil;
}

- (void )setColor:(NSString *)color
{
    if(color)
    {
        [self setColorElement:[[FHIRString alloc] initWithValue:color]];
    }
    else
    {
        [self setColorElement:nil];
    }
}


- (NSString *)brand
{
    if(self.brandElement)
    {
        return [self.brandElement value];
    }
    return nil;
}

- (void )setBrand:(NSString *)brand
{
    if(brand)
    {
        [self setBrandElement:[[FHIRString alloc] initWithValue:brand]];
    }
    else
    {
        [self setBrandElement:nil];
    }
}


- (NSString *)notes
{
    if(self.notesElement)
    {
        return [self.notesElement value];
    }
    return nil;
}

- (void )setNotes:(NSString *)notes
{
    if(notes)
    {
        [self setNotesElement:[[FHIRString alloc] initWithValue:notes]];
    }
    else
    {
        [self setNotesElement:nil];
    }
}


- (FHIRErrorList *)validate
{
    FHIRErrorList *result = [[FHIRErrorList alloc] init];
    
    [result addValidation:[super validate]];
    
    if(self.product != nil )
        [result addValidationRange:[self.product validate]];
    if(self.eyeElement != nil )
        [result addValidationRange:[self.eyeElement validate]];
    if(self.sphereElement != nil )
        [result addValidationRange:[self.sphereElement validate]];
    if(self.cylinderElement != nil )
        [result addValidationRange:[self.cylinderElement validate]];
    if(self.axisElement != nil )
        [result addValidationRange:[self.axisElement validate]];
    if(self.prismElement != nil )
        [result addValidationRange:[self.prismElement validate]];
    if(self.base_Element != nil )
        [result addValidationRange:[self.base_Element validate]];
    if(self.addElement != nil )
        [result addValidationRange:[self.addElement validate]];
    if(self.powerElement != nil )
        [result addValidationRange:[self.powerElement validate]];
    if(self.backCurveElement != nil )
        [result addValidationRange:[self.backCurveElement validate]];
    if(self.diameterElement != nil )
        [result addValidationRange:[self.diameterElement validate]];
    if(self.duration != nil )
        [result addValidationRange:[self.duration validate]];
    if(self.colorElement != nil )
        [result addValidationRange:[self.colorElement validate]];
    if(self.brandElement != nil )
        [result addValidationRange:[self.brandElement validate]];
    if(self.notesElement != nil )
        [result addValidationRange:[self.notesElement validate]];
    
    return result;
}

@end
