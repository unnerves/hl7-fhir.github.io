﻿/*
  Copyright (c) 2011+, HL7, Inc.
  All rights reserved.
  
  Redistribution and use in source and binary forms, with or without modification, 
  are permitted provided that the following conditions are met:
  
   * Redistributions of source code must retain the above copyright notice, this 
     list of conditions and the following disclaimer.
   * Redistributions in binary form must reproduce the above copyright notice, 
     this list of conditions and the following disclaimer in the documentation 
     and/or other materials provided with the distribution.
   * Neither the name of HL7 nor the names of its contributors may be used to 
     endorse or promote products derived from this software without specific 
     prior written permission.
  
  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND 
  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
  WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
  IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
  INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT 
  NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR 
  PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
  WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
  POSSIBILITY OF SUCH DAMAGE.
  

 * Generated on Tue, Dec 30, 2014 10:55+0000 for FHIR v0.4.0
 */
/*
 * Extension Definition
 */
#import "FHIRExtensionDefinition.h"

#import "FHIRUri.h"
#import "FHIRIdentifier.h"
#import "FHIRString.h"
#import "FHIRContactPoint.h"
#import "FHIRCoding.h"
#import "FHIRCode.h"
#import "FHIRBoolean.h"
#import "FHIRDateTime.h"
#import "FHIRExtensionDefinitionMappingComponent.h"
#import "FHIRElementDefinition.h"

#import "FHIRErrorList.h"

@implementation FHIRExtensionDefinition

- (NSString *)url
{
    if(self.urlElement)
    {
        return [self.urlElement value];
    }
    return nil;
}

- (void )setUrl:(NSString *)url
{
    if(url)
    {
        [self setUrlElement:[[FHIRUri alloc] initWithValue:url]];
    }
    else
    {
        [self setUrlElement:nil];
    }
}


- (NSString *)name
{
    if(self.nameElement)
    {
        return [self.nameElement value];
    }
    return nil;
}

- (void )setName:(NSString *)name
{
    if(name)
    {
        [self setNameElement:[[FHIRString alloc] initWithValue:name]];
    }
    else
    {
        [self setNameElement:nil];
    }
}


- (NSString *)display
{
    if(self.displayElement)
    {
        return [self.displayElement value];
    }
    return nil;
}

- (void )setDisplay:(NSString *)display
{
    if(display)
    {
        [self setDisplayElement:[[FHIRString alloc] initWithValue:display]];
    }
    else
    {
        [self setDisplayElement:nil];
    }
}


- (NSString *)publisher
{
    if(self.publisherElement)
    {
        return [self.publisherElement value];
    }
    return nil;
}

- (void )setPublisher:(NSString *)publisher
{
    if(publisher)
    {
        [self setPublisherElement:[[FHIRString alloc] initWithValue:publisher]];
    }
    else
    {
        [self setPublisherElement:nil];
    }
}


- (NSString *)description
{
    if(self.descriptionElement)
    {
        return [self.descriptionElement value];
    }
    return nil;
}

- (void )setDescription:(NSString *)description
{
    if(description)
    {
        [self setDescriptionElement:[[FHIRString alloc] initWithValue:description]];
    }
    else
    {
        [self setDescriptionElement:nil];
    }
}


- (NSString *)status
{
    if(self.statusElement)
    {
        return [self.statusElement value];
    }
    return nil;
}

- (void )setStatus:(NSString *)status
{
    if(status)
    {
        [self setStatusElement:[[FHIRCode alloc] initWithValue:status]];
    }
    else
    {
        [self setStatusElement:nil];
    }
}


- (NSNumber *)experimental
{
    if(self.experimentalElement)
    {
        return [self.experimentalElement value];
    }
    return nil;
}

- (void )setExperimental:(NSNumber *)experimental
{
    if(experimental)
    {
        [self setExperimentalElement:[[FHIRBoolean alloc] initWithValue:experimental]];
    }
    else
    {
        [self setExperimentalElement:nil];
    }
}


- (NSString *)date
{
    if(self.dateElement)
    {
        return [self.dateElement value];
    }
    return nil;
}

- (void )setDate:(NSString *)date
{
    if(date)
    {
        [self setDateElement:[[FHIRDateTime alloc] initWithValue:date]];
    }
    else
    {
        [self setDateElement:nil];
    }
}


- (NSString *)requirements
{
    if(self.requirementsElement)
    {
        return [self.requirementsElement value];
    }
    return nil;
}

- (void )setRequirements:(NSString *)requirements
{
    if(requirements)
    {
        [self setRequirementsElement:[[FHIRString alloc] initWithValue:requirements]];
    }
    else
    {
        [self setRequirementsElement:nil];
    }
}


- (kExtensionContext )contextType
{
    return [FHIREnumHelper parseString:[self.contextTypeElement value] enumType:kEnumTypeExtensionContext];
}

- (void )setContextType:(kExtensionContext )contextType
{
    [self setContextTypeElement:[[FHIRCode/*<code>*/ alloc] initWithValue:[FHIREnumHelper enumToString:contextType enumType:kEnumTypeExtensionContext]]];
}


- (NSArray /*<NSString>*/ *)context
{
    if(self.contextElement)
    {
        NSMutableArray *array = [NSMutableArray new];
        for(FHIRString *elem in self.contextElement)
            [array addObject:[elem value]];
        return [NSArray arrayWithArray:array];
    }
    return nil;
}

- (void )setContext:(NSArray /*<NSString>*/ *)context
{
    if(context)
    {
        NSMutableArray *array = [NSMutableArray new];
        for(NSString *value in context)
            [array addObject:[[FHIRString alloc] initWithValue:value]];
        [self setContextElement:[NSArray arrayWithArray:array]];
    }
    else
    {
        [self setContextElement:nil];
    }
}


- (FHIRErrorList *)validate
{
    FHIRErrorList *result = [[FHIRErrorList alloc] init];
    
    [result addValidation:[super validate]];
    
    if(self.urlElement != nil )
        [result addValidationRange:[self.urlElement validate]];
    if(self.identifier != nil )
        for(FHIRIdentifier *elem in self.identifier)
            [result addValidationRange:[elem validate]];
    if(self.nameElement != nil )
        [result addValidationRange:[self.nameElement validate]];
    if(self.displayElement != nil )
        [result addValidationRange:[self.displayElement validate]];
    if(self.publisherElement != nil )
        [result addValidationRange:[self.publisherElement validate]];
    if(self.telecom != nil )
        for(FHIRContactPoint *elem in self.telecom)
            [result addValidationRange:[elem validate]];
    if(self.descriptionElement != nil )
        [result addValidationRange:[self.descriptionElement validate]];
    if(self.code != nil )
        for(FHIRCoding *elem in self.code)
            [result addValidationRange:[elem validate]];
    if(self.statusElement != nil )
        [result addValidationRange:[self.statusElement validate]];
    if(self.experimentalElement != nil )
        [result addValidationRange:[self.experimentalElement validate]];
    if(self.dateElement != nil )
        [result addValidationRange:[self.dateElement validate]];
    if(self.requirementsElement != nil )
        [result addValidationRange:[self.requirementsElement validate]];
    if(self.mapping != nil )
        for(FHIRExtensionDefinitionMappingComponent *elem in self.mapping)
            [result addValidationRange:[elem validate]];
    if(self.contextTypeElement != nil )
        [result addValidationRange:[self.contextTypeElement validate]];
    if(self.contextElement != nil )
        for(FHIRString *elem in self.contextElement)
            [result addValidationRange:[elem validate]];
    if(self.element != nil )
        for(FHIRElementDefinition *elem in self.element)
            [result addValidationRange:[elem validate]];
    
    return result;
}

@end
