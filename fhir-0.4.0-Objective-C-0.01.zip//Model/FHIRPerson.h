﻿/*
  Copyright (c) 2011+, HL7, Inc.
  All rights reserved.
  
  Redistribution and use in source and binary forms, with or without modification, 
  are permitted provided that the following conditions are met:
  
   * Redistributions of source code must retain the above copyright notice, this 
     list of conditions and the following disclaimer.
   * Redistributions in binary form must reproduce the above copyright notice, 
     this list of conditions and the following disclaimer in the documentation 
     and/or other materials provided with the distribution.
   * Neither the name of HL7 nor the names of its contributors may be used to 
     endorse or promote products derived from this software without specific 
     prior written permission.
  
  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND 
  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
  WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
  IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
  INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT 
  NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR 
  PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
  WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
  POSSIBILITY OF SUCH DAMAGE.
  

 * Generated on Tue, Dec 30, 2014 10:55+0000 for FHIR v0.4.0
 */
/*
 * A generic person record
 *
 * [FhirReference("Person")]
 * [Serializable]
 */

#import "FHIRDomainResource.h"


@class FHIRIdentifier;
@class FHIRHumanName;
@class FHIRContactPoint;
@class FHIRCode;
@class FHIRDateTime;
@class FHIRAddress;
@class FHIRAttachment;
@class FHIRReference;
@class FHIRBoolean;
@class FHIRPersonLinkComponent;

@interface FHIRPerson : FHIRDomainResource

/*
 * The level of confidence that this link represents the same actual person, based on NIST Authentication Levels
 */
typedef enum 
{
    kIdentityAssuranceLevelLevel1, // Little or no confidence in the asserted identity's accuracy.
    kIdentityAssuranceLevelLevel2, // Some confidence in the asserted identity's accuracy.
    kIdentityAssuranceLevelLevel3, // High confidence in the asserted identity's accuracy.
    kIdentityAssuranceLevelLevel4, // Very high confidence in the asserted identity's accuracy.
} kIdentityAssuranceLevel;

/*
 * A Human identifier for this person
 */
@property (nonatomic, strong) NSArray/*<Identifier>*/ *identifier;

/*
 * A name associated with the person
 */
@property (nonatomic, strong) NSArray/*<HumanName>*/ *name;

/*
 * A contact detail for the person
 */
@property (nonatomic, strong) NSArray/*<ContactPoint>*/ *telecom;

/*
 * male | female | other | unknown
 */
@property (nonatomic, strong) FHIRCode/*<code>*/ *genderElement;

@property (nonatomic) kAdministrativeGender gender;

/*
 * The birth date for the person
 */
@property (nonatomic, strong) FHIRDateTime *birthDateElement;

@property (nonatomic, strong) NSString *birthDate;

/*
 * One or more addresses for the person
 */
@property (nonatomic, strong) NSArray/*<Address>*/ *address;

/*
 * Image of the Person
 */
@property (nonatomic, strong) FHIRAttachment *photo;

/*
 * The Organization that is the custodian of the person record
 */
@property (nonatomic, strong) FHIRReference *managingOrganization;

/*
 * This person's record is in active use
 */
@property (nonatomic, strong) FHIRBoolean *activeElement;

@property (nonatomic, strong) NSNumber *active;

/*
 * Link to a resource that converns the same actual person
 */
@property (nonatomic, strong) NSArray/*<PersonLinkComponent>*/ *link;

- (FHIRErrorList *)validate;

@end
