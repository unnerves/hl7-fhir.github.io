﻿/*
  Copyright (c) 2011+, HL7, Inc.
  All rights reserved.
  
  Redistribution and use in source and binary forms, with or without modification, 
  are permitted provided that the following conditions are met:
  
   * Redistributions of source code must retain the above copyright notice, this 
     list of conditions and the following disclaimer.
   * Redistributions in binary form must reproduce the above copyright notice, 
     this list of conditions and the following disclaimer in the documentation 
     and/or other materials provided with the distribution.
   * Neither the name of HL7 nor the names of its contributors may be used to 
     endorse or promote products derived from this software without specific 
     prior written permission.
  
  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND 
  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
  WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
  IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
  INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT 
  NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR 
  PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
  WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
  POSSIBILITY OF SUCH DAMAGE.
  

 * Generated on Tue, Dec 30, 2014 10:55+0000 for FHIR v0.4.0
 */

/*
 * Order of dictionaries
 */

#import "FHIRSerializerOrder.h"

@interface FHIRSerializerOrder()

+ (NSArray *)orderArrayForFHIRAddress;
+ (NSArray *)orderArrayForFHIRAttachment;
+ (NSArray *)orderArrayForFHIRBackboneElement;
+ (NSArray *)orderArrayForFHIRCodeableConcept;
+ (NSArray *)orderArrayForFHIRCoding;
+ (NSArray *)orderArrayForFHIRContactPoint;
+ (NSArray *)orderArrayForFHIRElement;
+ (NSArray *)orderArrayForFHIRElementDefinition;
+ (NSArray *)orderArrayForFHIRElementDefinitionSlicingComponent;
+ (NSArray *)orderArrayForFHIRTypeRefComponent;
+ (NSArray *)orderArrayForFHIRElementDefinitionMappingComponent;
+ (NSArray *)orderArrayForFHIRElementDefinitionBindingComponent;
+ (NSArray *)orderArrayForFHIRElementDefinitionConstraintComponent;
+ (NSArray *)orderArrayForFHIRExtension;
+ (NSArray *)orderArrayForFHIRHumanName;
+ (NSArray *)orderArrayForFHIRIdentifier;
+ (NSArray *)orderArrayForFHIRNarrative;
+ (NSArray *)orderArrayForFHIRPeriod;
+ (NSArray *)orderArrayForFHIRQuantity;
+ (NSArray *)orderArrayForFHIRRange;
+ (NSArray *)orderArrayForFHIRRatio;
+ (NSArray *)orderArrayForFHIRReference;
+ (NSArray *)orderArrayForFHIRSampledData;
+ (NSArray *)orderArrayForFHIRTiming;
+ (NSArray *)orderArrayForFHIRTimingRepeatComponent;
+ (NSArray *)orderArrayForFHIRBase64Binary;
+ (NSArray *)orderArrayForFHIRBoolean;
+ (NSArray *)orderArrayForFHIRCode;
+ (NSArray *)orderArrayForFHIRDate;
+ (NSArray *)orderArrayForFHIRDateTime;
+ (NSArray *)orderArrayForFHIRDecimal;
+ (NSArray *)orderArrayForFHIRId;
+ (NSArray *)orderArrayForFHIRInstant;
+ (NSArray *)orderArrayForFHIRInteger;
+ (NSArray *)orderArrayForFHIROid;
+ (NSArray *)orderArrayForFHIRString;
+ (NSArray *)orderArrayForFHIRTime;
+ (NSArray *)orderArrayForFHIRUri;
+ (NSArray *)orderArrayForFHIRUuid;
+ (NSArray *)orderArrayForFHIRXhtml;
+ (NSArray *)orderArrayForFHIRDomainResource;
+ (NSArray *)orderArrayForFHIRParameters;
+ (NSArray *)orderArrayForFHIRParametersParameterComponent;
+ (NSArray *)orderArrayForFHIRParametersParameterPartComponent;
+ (NSArray *)orderArrayForFHIRBaseResource;
+ (NSArray *)orderArrayForFHIRResourceMetaComponent;
+ (NSArray *)orderArrayForFHIRAlert;
+ (NSArray *)orderArrayForFHIRAllergyIntolerance;
+ (NSArray *)orderArrayForFHIRAllergyIntoleranceEventComponent;
+ (NSArray *)orderArrayForFHIRAppointment;
+ (NSArray *)orderArrayForFHIRAppointmentParticipantComponent;
+ (NSArray *)orderArrayForFHIRAppointmentResponse;
+ (NSArray *)orderArrayForFHIRBasic;
+ (NSArray *)orderArrayForFHIRBinary;
+ (NSArray *)orderArrayForFHIRBundle;
+ (NSArray *)orderArrayForFHIRBundleEntryDeletedComponent;
+ (NSArray *)orderArrayForFHIRBundleEntryComponent;
+ (NSArray *)orderArrayForFHIRBundleLinkComponent;
+ (NSArray *)orderArrayForFHIRCarePlan;
+ (NSArray *)orderArrayForFHIRCarePlanGoalComponent;
+ (NSArray *)orderArrayForFHIRCarePlanParticipantComponent;
+ (NSArray *)orderArrayForFHIRCarePlanActivityComponent;
+ (NSArray *)orderArrayForFHIRCarePlanActivitySimpleComponent;
+ (NSArray *)orderArrayForFHIRCarePlan2;
+ (NSArray *)orderArrayForFHIRCarePlan2ParticipantComponent;
+ (NSArray *)orderArrayForFHIRClaimResponse;
+ (NSArray *)orderArrayForFHIRNotesComponent;
+ (NSArray *)orderArrayForFHIRItemsComponent;
+ (NSArray *)orderArrayForFHIRItemSubdetailComponent;
+ (NSArray *)orderArrayForFHIRAddedItemDetailAdjudicationComponent;
+ (NSArray *)orderArrayForFHIRAddedItemAdjudicationComponent;
+ (NSArray *)orderArrayForFHIRDetailAdjudicationComponent;
+ (NSArray *)orderArrayForFHIRErrorsComponent;
+ (NSArray *)orderArrayForFHIRAddedItemComponent;
+ (NSArray *)orderArrayForFHIRItemAdjudicationComponent;
+ (NSArray *)orderArrayForFHIRAddedItemsDetailComponent;
+ (NSArray *)orderArrayForFHIRSubdetailAdjudicationComponent;
+ (NSArray *)orderArrayForFHIRItemDetailComponent;
+ (NSArray *)orderArrayForFHIRClinicalAssessment;
+ (NSArray *)orderArrayForFHIRClinicalAssessmentRuledOutComponent;
+ (NSArray *)orderArrayForFHIRClinicalAssessmentInvestigationsComponent;
+ (NSArray *)orderArrayForFHIRClinicalAssessmentDiagnosisComponent;
+ (NSArray *)orderArrayForFHIRCommunication;
+ (NSArray *)orderArrayForFHIRCommunicationPayloadComponent;
+ (NSArray *)orderArrayForFHIRCommunicationRequest;
+ (NSArray *)orderArrayForFHIRCommunicationRequestPayloadComponent;
+ (NSArray *)orderArrayForFHIRComposition;
+ (NSArray *)orderArrayForFHIRSectionComponent;
+ (NSArray *)orderArrayForFHIRCompositionEventComponent;
+ (NSArray *)orderArrayForFHIRCompositionAttesterComponent;
+ (NSArray *)orderArrayForFHIRConceptMap;
+ (NSArray *)orderArrayForFHIRConceptMapElementComponent;
+ (NSArray *)orderArrayForFHIRConceptMapElementMapComponent;
+ (NSArray *)orderArrayForFHIROtherElementComponent;
+ (NSArray *)orderArrayForFHIRCondition;
+ (NSArray *)orderArrayForFHIRConditionEvidenceComponent;
+ (NSArray *)orderArrayForFHIRConditionDueToComponent;
+ (NSArray *)orderArrayForFHIRConditionOccurredFollowingComponent;
+ (NSArray *)orderArrayForFHIRConditionStageComponent;
+ (NSArray *)orderArrayForFHIRConditionLocationComponent;
+ (NSArray *)orderArrayForFHIRConformance;
+ (NSArray *)orderArrayForFHIRConformanceRestComponent;
+ (NSArray *)orderArrayForFHIRConformanceSoftwareComponent;
+ (NSArray *)orderArrayForFHIRConformanceMessagingComponent;
+ (NSArray *)orderArrayForFHIRConformanceDocumentComponent;
+ (NSArray *)orderArrayForFHIRConformanceRestResourceComponent;
+ (NSArray *)orderArrayForFHIRConformanceImplementationComponent;
+ (NSArray *)orderArrayForFHIRConformanceMessagingEventComponent;
+ (NSArray *)orderArrayForFHIRSystemInteractionComponent;
+ (NSArray *)orderArrayForFHIRResourceInteractionComponent;
+ (NSArray *)orderArrayForFHIRConformanceRestSecurityComponent;
+ (NSArray *)orderArrayForFHIRConformanceRestSecurityCertificateComponent;
+ (NSArray *)orderArrayForFHIRConformanceRestOperationComponent;
+ (NSArray *)orderArrayForFHIRConformanceRestResourceSearchParamComponent;
+ (NSArray *)orderArrayForFHIRContract;
+ (NSArray *)orderArrayForFHIRContractSignerComponent;
+ (NSArray *)orderArrayForFHIRContractTermComponent;
+ (NSArray *)orderArrayForFHIRContraindication;
+ (NSArray *)orderArrayForFHIRContraindicationMitigationComponent;
+ (NSArray *)orderArrayForFHIRCoverage;
+ (NSArray *)orderArrayForFHIRDataElement;
+ (NSArray *)orderArrayForFHIRDataElementMappingComponent;
+ (NSArray *)orderArrayForFHIRDataElementBindingComponent;
+ (NSArray *)orderArrayForFHIRDevice;
+ (NSArray *)orderArrayForFHIRDeviceComponent;
+ (NSArray *)orderArrayForFHIRDeviceComponentProductionSpecificationComponent;
+ (NSArray *)orderArrayForFHIRDeviceMetric;
+ (NSArray *)orderArrayForFHIRDeviceMetricCalibrationInfoComponent;
+ (NSArray *)orderArrayForFHIRDeviceUseRequest;
+ (NSArray *)orderArrayForFHIRDeviceUseStatement;
+ (NSArray *)orderArrayForFHIRDiagnosticOrder;
+ (NSArray *)orderArrayForFHIRDiagnosticOrderItemComponent;
+ (NSArray *)orderArrayForFHIRDiagnosticOrderEventComponent;
+ (NSArray *)orderArrayForFHIRDiagnosticReport;
+ (NSArray *)orderArrayForFHIRDiagnosticReportImageComponent;
+ (NSArray *)orderArrayForFHIRDocumentManifest;
+ (NSArray *)orderArrayForFHIRDocumentReference;
+ (NSArray *)orderArrayForFHIRDocumentReferenceContextComponent;
+ (NSArray *)orderArrayForFHIRDocumentReferenceRelatesToComponent;
+ (NSArray *)orderArrayForFHIRDocumentReferenceServiceParameterComponent;
+ (NSArray *)orderArrayForFHIRDocumentReferenceServiceComponent;
+ (NSArray *)orderArrayForFHIREligibilityRequest;
+ (NSArray *)orderArrayForFHIREligibilityResponse;
+ (NSArray *)orderArrayForFHIREncounter;
+ (NSArray *)orderArrayForFHIREncounterHospitalizationComponent;
+ (NSArray *)orderArrayForFHIREncounterStatusHistoryComponent;
+ (NSArray *)orderArrayForFHIREncounterLocationComponent;
+ (NSArray *)orderArrayForFHIREncounterParticipantComponent;
+ (NSArray *)orderArrayForFHIREnrollmentRequest;
+ (NSArray *)orderArrayForFHIREnrollmentResponse;
+ (NSArray *)orderArrayForFHIREpisodeOfCare;
+ (NSArray *)orderArrayForFHIREpisodeOfCareStatusHistoryComponent;
+ (NSArray *)orderArrayForFHIREpisodeOfCareCareTeamComponent;
+ (NSArray *)orderArrayForFHIRExplanationOfBenefit;
+ (NSArray *)orderArrayForFHIRExtensionDefinition;
+ (NSArray *)orderArrayForFHIRExtensionDefinitionMappingComponent;
+ (NSArray *)orderArrayForFHIRFamilyHistory;
+ (NSArray *)orderArrayForFHIRFamilyHistoryRelationConditionComponent;
+ (NSArray *)orderArrayForFHIRFamilyHistoryRelationComponent;
+ (NSArray *)orderArrayForFHIRGoal;
+ (NSArray *)orderArrayForFHIRGroup;
+ (NSArray *)orderArrayForFHIRGroupCharacteristicComponent;
+ (NSArray *)orderArrayForFHIRHealthcareService;
+ (NSArray *)orderArrayForFHIRServiceTypeComponent;
+ (NSArray *)orderArrayForFHIRHealthcareServiceAvailableTimeComponent;
+ (NSArray *)orderArrayForFHIRHealthcareServiceNotAvailableTimeComponent;
+ (NSArray *)orderArrayForFHIRImagingObjectSelection;
+ (NSArray *)orderArrayForFHIRStudyComponent;
+ (NSArray *)orderArrayForFHIRInstanceComponent;
+ (NSArray *)orderArrayForFHIRSeriesComponent;
+ (NSArray *)orderArrayForFHIRImagingStudy;
+ (NSArray *)orderArrayForFHIRImagingStudySeriesComponent;
+ (NSArray *)orderArrayForFHIRImagingStudySeriesInstanceComponent;
+ (NSArray *)orderArrayForFHIRImmunization;
+ (NSArray *)orderArrayForFHIRImmunizationVaccinationProtocolComponent;
+ (NSArray *)orderArrayForFHIRImmunizationExplanationComponent;
+ (NSArray *)orderArrayForFHIRImmunizationReactionComponent;
+ (NSArray *)orderArrayForFHIRImmunizationRecommendation;
+ (NSArray *)orderArrayForFHIRImmunizationRecommendationRecommendationDateCriterionComponent;
+ (NSArray *)orderArrayForFHIRImmunizationRecommendationRecommendationProtocolComponent;
+ (NSArray *)orderArrayForFHIRImmunizationRecommendationRecommendationComponent;
+ (NSArray *)orderArrayForFHIRInstitutionalClaim;
+ (NSArray *)orderArrayForFHIRItemsComponent;
+ (NSArray *)orderArrayForFHIRDetailComponent;
+ (NSArray *)orderArrayForFHIRCoverageComponent;
+ (NSArray *)orderArrayForFHIRPayeeComponent;
+ (NSArray *)orderArrayForFHIRDiagnosisComponent;
+ (NSArray *)orderArrayForFHIRSubDetailComponent;
+ (NSArray *)orderArrayForFHIRList;
+ (NSArray *)orderArrayForFHIRListEntryComponent;
+ (NSArray *)orderArrayForFHIRLocation;
+ (NSArray *)orderArrayForFHIRLocationPositionComponent;
+ (NSArray *)orderArrayForFHIRMedia;
+ (NSArray *)orderArrayForFHIRMedication;
+ (NSArray *)orderArrayForFHIRMedicationPackageContentComponent;
+ (NSArray *)orderArrayForFHIRMedicationPackageComponent;
+ (NSArray *)orderArrayForFHIRMedicationProductIngredientComponent;
+ (NSArray *)orderArrayForFHIRMedicationProductComponent;
+ (NSArray *)orderArrayForFHIRMedicationAdministration;
+ (NSArray *)orderArrayForFHIRMedicationAdministrationDosageComponent;
+ (NSArray *)orderArrayForFHIRMedicationDispense;
+ (NSArray *)orderArrayForFHIRMedicationDispenseDispenseDosageComponent;
+ (NSArray *)orderArrayForFHIRMedicationDispenseSubstitutionComponent;
+ (NSArray *)orderArrayForFHIRMedicationDispenseDispenseComponent;
+ (NSArray *)orderArrayForFHIRMedicationPrescription;
+ (NSArray *)orderArrayForFHIRMedicationPrescriptionDosageInstructionComponent;
+ (NSArray *)orderArrayForFHIRMedicationPrescriptionSubstitutionComponent;
+ (NSArray *)orderArrayForFHIRMedicationPrescriptionDispenseComponent;
+ (NSArray *)orderArrayForFHIRMedicationStatement;
+ (NSArray *)orderArrayForFHIRMedicationStatementDosageComponent;
+ (NSArray *)orderArrayForFHIRMessageHeader;
+ (NSArray *)orderArrayForFHIRMessageDestinationComponent;
+ (NSArray *)orderArrayForFHIRMessageSourceComponent;
+ (NSArray *)orderArrayForFHIRMessageHeaderResponseComponent;
+ (NSArray *)orderArrayForFHIRNamingSystem;
+ (NSArray *)orderArrayForFHIRNamingSystemContactComponent;
+ (NSArray *)orderArrayForFHIRNamingSystemUniqueIdComponent;
+ (NSArray *)orderArrayForFHIRNutritionOrder;
+ (NSArray *)orderArrayForFHIRNutritionOrderItemSupplementComponent;
+ (NSArray *)orderArrayForFHIRNutritionOrderItemOralDietTextureComponent;
+ (NSArray *)orderArrayForFHIRNutritionOrderItemComponent;
+ (NSArray *)orderArrayForFHIRNutritionOrderItemEnteralFormulaComponent;
+ (NSArray *)orderArrayForFHIRNutritionOrderItemOralDietComponent;
+ (NSArray *)orderArrayForFHIRNutritionOrderItemOralDietNutrientsComponent;
+ (NSArray *)orderArrayForFHIRObservation;
+ (NSArray *)orderArrayForFHIRObservationReferenceRangeComponent;
+ (NSArray *)orderArrayForFHIRObservationRelatedComponent;
+ (NSArray *)orderArrayForFHIROperationDefinition;
+ (NSArray *)orderArrayForFHIROperationDefinitionParameterPartComponent;
+ (NSArray *)orderArrayForFHIROperationDefinitionParameterComponent;
+ (NSArray *)orderArrayForFHIROperationOutcome;
+ (NSArray *)orderArrayForFHIROperationOutcomeIssueComponent;
+ (NSArray *)orderArrayForFHIROralHealthClaim;
+ (NSArray *)orderArrayForFHIRItemsComponent;
+ (NSArray *)orderArrayForFHIROrthodonticPlanComponent;
+ (NSArray *)orderArrayForFHIRDetailComponent;
+ (NSArray *)orderArrayForFHIRCoverageComponent;
+ (NSArray *)orderArrayForFHIRPayeeComponent;
+ (NSArray *)orderArrayForFHIRDiagnosisComponent;
+ (NSArray *)orderArrayForFHIRProsthesisComponent;
+ (NSArray *)orderArrayForFHIRSubDetailComponent;
+ (NSArray *)orderArrayForFHIRMissingTeethComponent;
+ (NSArray *)orderArrayForFHIROrder;
+ (NSArray *)orderArrayForFHIROrderWhenComponent;
+ (NSArray *)orderArrayForFHIROrderResponse;
+ (NSArray *)orderArrayForFHIROrganization;
+ (NSArray *)orderArrayForFHIROrganizationContactComponent;
+ (NSArray *)orderArrayForFHIROther;
+ (NSArray *)orderArrayForFHIRPatient;
+ (NSArray *)orderArrayForFHIRContactComponent;
+ (NSArray *)orderArrayForFHIRAnimalComponent;
+ (NSArray *)orderArrayForFHIRPatientLinkComponent;
+ (NSArray *)orderArrayForFHIRPaymentNotice;
+ (NSArray *)orderArrayForFHIRPaymentReconciliation;
+ (NSArray *)orderArrayForFHIRNotesComponent;
+ (NSArray *)orderArrayForFHIRDetailsComponent;
+ (NSArray *)orderArrayForFHIRPendedRequest;
+ (NSArray *)orderArrayForFHIRPerson;
+ (NSArray *)orderArrayForFHIRPersonLinkComponent;
+ (NSArray *)orderArrayForFHIRPharmacyClaim;
+ (NSArray *)orderArrayForFHIRItemsComponent;
+ (NSArray *)orderArrayForFHIRDetailComponent;
+ (NSArray *)orderArrayForFHIRCoverageComponent;
+ (NSArray *)orderArrayForFHIRPayeeComponent;
+ (NSArray *)orderArrayForFHIRDiagnosisComponent;
+ (NSArray *)orderArrayForFHIRSubDetailComponent;
+ (NSArray *)orderArrayForFHIRPractitioner;
+ (NSArray *)orderArrayForFHIRPractitionerQualificationComponent;
+ (NSArray *)orderArrayForFHIRProcedure;
+ (NSArray *)orderArrayForFHIRProcedureRelatedItemComponent;
+ (NSArray *)orderArrayForFHIRProcedurePerformerComponent;
+ (NSArray *)orderArrayForFHIRProcedureRequest;
+ (NSArray *)orderArrayForFHIRProfessionalClaim;
+ (NSArray *)orderArrayForFHIRItemsComponent;
+ (NSArray *)orderArrayForFHIRDetailComponent;
+ (NSArray *)orderArrayForFHIRCoverageComponent;
+ (NSArray *)orderArrayForFHIRPayeeComponent;
+ (NSArray *)orderArrayForFHIRDiagnosisComponent;
+ (NSArray *)orderArrayForFHIRSubDetailComponent;
+ (NSArray *)orderArrayForFHIRProfile;
+ (NSArray *)orderArrayForFHIRConstraintComponent;
+ (NSArray *)orderArrayForFHIRProfileMappingComponent;
+ (NSArray *)orderArrayForFHIRProvenance;
+ (NSArray *)orderArrayForFHIRProvenanceAgentComponent;
+ (NSArray *)orderArrayForFHIRProvenanceEntityComponent;
+ (NSArray *)orderArrayForFHIRQuestionnaire;
+ (NSArray *)orderArrayForFHIRQuestionComponent;
+ (NSArray *)orderArrayForFHIRGroupComponent;
+ (NSArray *)orderArrayForFHIRQuestionnaireAnswers;
+ (NSArray *)orderArrayForFHIRQuestionAnswerComponent;
+ (NSArray *)orderArrayForFHIRQuestionComponent;
+ (NSArray *)orderArrayForFHIRGroupComponent;
+ (NSArray *)orderArrayForFHIRReadjudicate;
+ (NSArray *)orderArrayForFHIRItemsComponent;
+ (NSArray *)orderArrayForFHIRReferralRequest;
+ (NSArray *)orderArrayForFHIRRelatedPerson;
+ (NSArray *)orderArrayForFHIRReversal;
+ (NSArray *)orderArrayForFHIRPayeeComponent;
+ (NSArray *)orderArrayForFHIRReversalCoverageComponent;
+ (NSArray *)orderArrayForFHIRRiskAssessment;
+ (NSArray *)orderArrayForFHIRRiskAssessmentPredictionComponent;
+ (NSArray *)orderArrayForFHIRSchedule;
+ (NSArray *)orderArrayForFHIRSearchParameter;
+ (NSArray *)orderArrayForFHIRSecurityEvent;
+ (NSArray *)orderArrayForFHIRSecurityEventObjectDetailComponent;
+ (NSArray *)orderArrayForFHIRSecurityEventObjectComponent;
+ (NSArray *)orderArrayForFHIRSecurityEventSourceComponent;
+ (NSArray *)orderArrayForFHIRSecurityEventEventComponent;
+ (NSArray *)orderArrayForFHIRSecurityEventParticipantNetworkComponent;
+ (NSArray *)orderArrayForFHIRSecurityEventParticipantComponent;
+ (NSArray *)orderArrayForFHIRSlot;
+ (NSArray *)orderArrayForFHIRSpecimen;
+ (NSArray *)orderArrayForFHIRSpecimenCollectionComponent;
+ (NSArray *)orderArrayForFHIRSpecimenSourceComponent;
+ (NSArray *)orderArrayForFHIRSpecimenTreatmentComponent;
+ (NSArray *)orderArrayForFHIRSpecimenContainerComponent;
+ (NSArray *)orderArrayForFHIRStatusRequest;
+ (NSArray *)orderArrayForFHIRStatusResponse;
+ (NSArray *)orderArrayForFHIRStatusResponseNotesComponent;
+ (NSArray *)orderArrayForFHIRSubscription;
+ (NSArray *)orderArrayForFHIRSubscriptionChannelComponent;
+ (NSArray *)orderArrayForFHIRSubscriptionTagComponent;
+ (NSArray *)orderArrayForFHIRSubstance;
+ (NSArray *)orderArrayForFHIRSubstanceIngredientComponent;
+ (NSArray *)orderArrayForFHIRSubstanceInstanceComponent;
+ (NSArray *)orderArrayForFHIRSupply;
+ (NSArray *)orderArrayForFHIRSupplyDispenseComponent;
+ (NSArray *)orderArrayForFHIRSupportingDocumentation;
+ (NSArray *)orderArrayForFHIRSupportingDocumentationDetailComponent;
+ (NSArray *)orderArrayForFHIRValueSet;
+ (NSArray *)orderArrayForFHIRValueSetDefineComponent;
+ (NSArray *)orderArrayForFHIRValueSetExpansionContainsComponent;
+ (NSArray *)orderArrayForFHIRConceptDefinitionDesignationComponent;
+ (NSArray *)orderArrayForFHIRConceptDefinitionComponent;
+ (NSArray *)orderArrayForFHIRConceptSetComponent;
+ (NSArray *)orderArrayForFHIRConceptReferenceComponent;
+ (NSArray *)orderArrayForFHIRConceptSetFilterComponent;
+ (NSArray *)orderArrayForFHIRValueSetComposeComponent;
+ (NSArray *)orderArrayForFHIRValueSetExpansionComponent;
+ (NSArray *)orderArrayForFHIRVisionClaim;
+ (NSArray *)orderArrayForFHIRItemsComponent;
+ (NSArray *)orderArrayForFHIRDetailComponent;
+ (NSArray *)orderArrayForFHIRCoverageComponent;
+ (NSArray *)orderArrayForFHIRPayeeComponent;
+ (NSArray *)orderArrayForFHIRDiagnosisComponent;
+ (NSArray *)orderArrayForFHIRSubDetailComponent;
+ (NSArray *)orderArrayForFHIRVisionPrescription;
+ (NSArray *)orderArrayForFHIRVisionPrescriptionDispenseComponent;

@end

@implementation FHIRSerializerOrder

+ (NSArray *)orderArrayForFHIRAddress
{
    return @[
    
        @"id",
        @"extension",
        @"use",
        @"text",
        @"line",
        @"city",
        @"state",
        @"postalCode",
        @"country",
        @"period",
    ];
}

+ (NSArray *)orderArrayForFHIRAttachment
{
    return @[
    
        @"id",
        @"extension",
        @"contentType",
        @"language",
        @"data",
        @"url",
        @"size",
        @"hash",
        @"title",
    ];
}

+ (NSArray *)orderArrayForFHIRBackboneElement
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
    ];
}

+ (NSArray *)orderArrayForFHIRCodeableConcept
{
    return @[
    
        @"id",
        @"extension",
        @"coding",
        @"text",
    ];
}

+ (NSArray *)orderArrayForFHIRCoding
{
    return @[
    
        @"id",
        @"extension",
        @"system",
        @"version",
        @"code",
        @"display",
        @"primary",
        @"valueSet",
    ];
}

+ (NSArray *)orderArrayForFHIRContactPoint
{
    return @[
    
        @"id",
        @"extension",
        @"system",
        @"value",
        @"use",
        @"period",
    ];
}

+ (NSArray *)orderArrayForFHIRElement
{
    return @[
    
        @"id",
        @"extension",
    ];
}

+ (NSArray *)orderArrayForFHIRElementDefinition
{
    return @[
    
        @"id",
        @"extension",
        @"path",
        @"representation",
        @"name",
        @"slicing",
        @"short_",
        @"formal",
        @"comments",
        @"requirements",
        @"synonym",
        @"min",
        @"max",
        @"type",
        @"nameReference",
        @"defaultValue",
        @"meaningWhenMissing",
        @"fixed_",
        @"pattern",
        @"example",
        @"maxLength",
        @"condition",
        @"constraint",
        @"mustSupport",
        @"isModifier",
        @"isSummary",
        @"binding",
        @"mapping",
    ];
}

+ (NSArray *)orderArrayForFHIRElementDefinitionSlicingComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"discriminator",
        @"description",
        @"ordered",
        @"rules",
    ];
}

+ (NSArray *)orderArrayForFHIRTypeRefComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"code",
        @"profile",
        @"aggregation",
    ];
}

+ (NSArray *)orderArrayForFHIRElementDefinitionMappingComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"identity",
        @"map",
    ];
}

+ (NSArray *)orderArrayForFHIRElementDefinitionBindingComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"name",
        @"isExtensible",
        @"conformance",
        @"description",
        @"reference",
    ];
}

+ (NSArray *)orderArrayForFHIRElementDefinitionConstraintComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"key",
        @"name",
        @"severity",
        @"human",
        @"xpath",
    ];
}

+ (NSArray *)orderArrayForFHIRExtension
{
    return @[
    
        @"id",
        @"extension",
        @"url",
        @"value",
    ];
}

+ (NSArray *)orderArrayForFHIRHumanName
{
    return @[
    
        @"id",
        @"extension",
        @"use",
        @"text",
        @"family",
        @"given",
        @"prefix",
        @"suffix",
        @"period",
    ];
}

+ (NSArray *)orderArrayForFHIRIdentifier
{
    return @[
    
        @"id",
        @"extension",
        @"use",
        @"label",
        @"system",
        @"value",
        @"period",
        @"assigner",
    ];
}

+ (NSArray *)orderArrayForFHIRNarrative
{
    return @[
    
        @"id",
        @"extension",
        @"status",
        @"div",
    ];
}

+ (NSArray *)orderArrayForFHIRPeriod
{
    return @[
    
        @"id",
        @"extension",
        @"start",
        @"end",
    ];
}

+ (NSArray *)orderArrayForFHIRQuantity
{
    return @[
    
        @"id",
        @"extension",
        @"value",
        @"comparator",
        @"units",
        @"system",
        @"code",
    ];
}

+ (NSArray *)orderArrayForFHIRRange
{
    return @[
    
        @"id",
        @"extension",
        @"low",
        @"high",
    ];
}

+ (NSArray *)orderArrayForFHIRRatio
{
    return @[
    
        @"id",
        @"extension",
        @"numerator",
        @"denominator",
    ];
}

+ (NSArray *)orderArrayForFHIRReference
{
    return @[
    
        @"id",
        @"extension",
        @"reference",
        @"display",
    ];
}

+ (NSArray *)orderArrayForFHIRSampledData
{
    return @[
    
        @"id",
        @"extension",
        @"origin",
        @"period",
        @"factor",
        @"lowerLimit",
        @"upperLimit",
        @"dimensions",
        @"data",
    ];
}

+ (NSArray *)orderArrayForFHIRTiming
{
    return @[
    
        @"id",
        @"extension",
        @"event_",
        @"repeat",
    ];
}

+ (NSArray *)orderArrayForFHIRTimingRepeatComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"frequency",
        @"when",
        @"duration",
        @"units",
        @"count",
        @"end",
    ];
}

+ (NSArray *)orderArrayForFHIRBase64Binary
{
    return @[
    
        @"id",
        @"extension",
        @"value",
    ];
}

+ (NSArray *)orderArrayForFHIRBoolean
{
    return @[
    
        @"id",
        @"extension",
        @"value",
    ];
}

+ (NSArray *)orderArrayForFHIRCode
{
    return @[
    
        @"id",
        @"extension",
        @"value",
    ];
}

+ (NSArray *)orderArrayForFHIRDate
{
    return @[
    
        @"id",
        @"extension",
        @"value",
    ];
}

+ (NSArray *)orderArrayForFHIRDateTime
{
    return @[
    
        @"id",
        @"extension",
        @"value",
    ];
}

+ (NSArray *)orderArrayForFHIRDecimal
{
    return @[
    
        @"id",
        @"extension",
        @"value",
    ];
}

+ (NSArray *)orderArrayForFHIRId
{
    return @[
    
        @"id",
        @"extension",
        @"value",
    ];
}

+ (NSArray *)orderArrayForFHIRInstant
{
    return @[
    
        @"id",
        @"extension",
        @"value",
    ];
}

+ (NSArray *)orderArrayForFHIRInteger
{
    return @[
    
        @"id",
        @"extension",
        @"value",
    ];
}

+ (NSArray *)orderArrayForFHIROid
{
    return @[
    
        @"id",
        @"extension",
        @"value",
    ];
}

+ (NSArray *)orderArrayForFHIRString
{
    return @[
    
        @"id",
        @"extension",
        @"value",
    ];
}

+ (NSArray *)orderArrayForFHIRTime
{
    return @[
    
        @"id",
        @"extension",
        @"value",
    ];
}

+ (NSArray *)orderArrayForFHIRUri
{
    return @[
    
        @"id",
        @"extension",
        @"value",
    ];
}

+ (NSArray *)orderArrayForFHIRUuid
{
    return @[
    
        @"id",
        @"extension",
        @"value",
    ];
}

+ (NSArray *)orderArrayForFHIRXhtml
{
    return @[
    
        @"id",
        @"extension",
        @"value",
    ];
}

+ (NSArray *)orderArrayForFHIRDomainResource
{
    return @[
    
        @"id",
        @"meta",
        @"implicitRules",
        @"language",
        @"text",
        @"contained",
        @"extension",
        @"modifierExtension",
    ];
}

+ (NSArray *)orderArrayForFHIRParameters
{
    return @[
    
        @"id",
        @"meta",
        @"implicitRules",
        @"language",
        @"parameter",
    ];
}

+ (NSArray *)orderArrayForFHIRParametersParameterComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"name",
        @"value",
        @"resource",
        @"part",
    ];
}

+ (NSArray *)orderArrayForFHIRParametersParameterPartComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"name",
        @"value",
    ];
}

+ (NSArray *)orderArrayForFHIRBaseResource
{
    return @[
    
        @"id",
        @"meta",
        @"implicitRules",
        @"language",
    ];
}

+ (NSArray *)orderArrayForFHIRResourceMetaComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"versionId",
        @"lastUpdated",
        @"profile",
        @"security",
        @"tag",
    ];
}

+ (NSArray *)orderArrayForFHIRAlert
{
    return @[
    
        @"id",
        @"meta",
        @"implicitRules",
        @"language",
        @"text",
        @"contained",
        @"extension",
        @"modifierExtension",
        @"identifier",
        @"category",
        @"status",
        @"subject",
        @"author",
        @"note",
    ];
}

+ (NSArray *)orderArrayForFHIRAllergyIntolerance
{
    return @[
    
        @"id",
        @"meta",
        @"implicitRules",
        @"language",
        @"text",
        @"contained",
        @"extension",
        @"modifierExtension",
        @"identifier",
        @"recordedDate",
        @"recorder",
        @"subject",
        @"substance",
        @"status",
        @"criticality",
        @"type",
        @"category",
        @"lastOccurence",
        @"comment",
        @"event_",
    ];
}

+ (NSArray *)orderArrayForFHIRAllergyIntoleranceEventComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"substance",
        @"certainty",
        @"manifestation",
        @"description",
        @"onset",
        @"duration",
        @"severity",
        @"exposureRoute",
        @"comment",
    ];
}

+ (NSArray *)orderArrayForFHIRAppointment
{
    return @[
    
        @"id",
        @"meta",
        @"implicitRules",
        @"language",
        @"text",
        @"contained",
        @"extension",
        @"modifierExtension",
        @"identifier",
        @"priority",
        @"status",
        @"type",
        @"reason",
        @"description",
        @"start",
        @"end",
        @"slot",
        @"location",
        @"comment",
        @"order",
        @"participant",
        @"lastModifiedBy",
        @"lastModified",
    ];
}

+ (NSArray *)orderArrayForFHIRAppointmentParticipantComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"type",
        @"actor",
        @"required",
        @"status",
    ];
}

+ (NSArray *)orderArrayForFHIRAppointmentResponse
{
    return @[
    
        @"id",
        @"meta",
        @"implicitRules",
        @"language",
        @"text",
        @"contained",
        @"extension",
        @"modifierExtension",
        @"identifier",
        @"appointment",
        @"participantType",
        @"individual",
        @"participantStatus",
        @"comment",
        @"start",
        @"end",
        @"lastModifiedBy",
        @"lastModified",
    ];
}

+ (NSArray *)orderArrayForFHIRBasic
{
    return @[
    
        @"id",
        @"meta",
        @"implicitRules",
        @"language",
        @"text",
        @"contained",
        @"extension",
        @"modifierExtension",
        @"identifier",
        @"code",
        @"subject",
        @"author",
        @"created",
    ];
}

+ (NSArray *)orderArrayForFHIRBinary
{
    return @[
    
        @"id",
        @"meta",
        @"implicitRules",
        @"language",
        @"contentType",
        @"content",
    ];
}

+ (NSArray *)orderArrayForFHIRBundle
{
    return @[
    
        @"id",
        @"meta",
        @"implicitRules",
        @"language",
        @"type",
        @"base_",
        @"total",
        @"link",
        @"entry",
        @"signature",
    ];
}

+ (NSArray *)orderArrayForFHIRBundleEntryDeletedComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"type",
        @"resourceId",
        @"versionId",
        @"instant",
    ];
}

+ (NSArray *)orderArrayForFHIRBundleEntryComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"base_",
        @"status",
        @"search",
        @"score",
        @"deleted",
        @"resource",
    ];
}

+ (NSArray *)orderArrayForFHIRBundleLinkComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"relation",
        @"url",
    ];
}

+ (NSArray *)orderArrayForFHIRCarePlan
{
    return @[
    
        @"id",
        @"meta",
        @"implicitRules",
        @"language",
        @"text",
        @"contained",
        @"extension",
        @"modifierExtension",
        @"identifier",
        @"patient",
        @"status",
        @"period",
        @"modified",
        @"concern",
        @"participant",
        @"goal",
        @"activity",
        @"notes",
    ];
}

+ (NSArray *)orderArrayForFHIRCarePlanGoalComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"description",
        @"status",
        @"notes",
        @"concern",
    ];
}

+ (NSArray *)orderArrayForFHIRCarePlanParticipantComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"role",
        @"member",
    ];
}

+ (NSArray *)orderArrayForFHIRCarePlanActivityComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"goal",
        @"status",
        @"prohibited",
        @"actionResulting",
        @"notes",
        @"detail",
        @"simple",
    ];
}

+ (NSArray *)orderArrayForFHIRCarePlanActivitySimpleComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"category",
        @"code",
        @"scheduled",
        @"location",
        @"performer",
        @"product",
        @"dailyAmount",
        @"quantity",
        @"details",
    ];
}

+ (NSArray *)orderArrayForFHIRCarePlan2
{
    return @[
    
        @"id",
        @"meta",
        @"implicitRules",
        @"language",
        @"text",
        @"contained",
        @"extension",
        @"modifierExtension",
        @"identifier",
        @"patient",
        @"status",
        @"period",
        @"modified",
        @"concern",
        @"participant",
        @"notes",
        @"goal",
        @"activity",
    ];
}

+ (NSArray *)orderArrayForFHIRCarePlan2ParticipantComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"role",
        @"member",
    ];
}

+ (NSArray *)orderArrayForFHIRClaimResponse
{
    return @[
    
        @"id",
        @"meta",
        @"implicitRules",
        @"language",
        @"text",
        @"contained",
        @"extension",
        @"modifierExtension",
        @"identifier",
        @"request",
        @"ruleset",
        @"originalRuleset",
        @"created",
        @"organization",
        @"requestProvider",
        @"requestOrganization",
        @"outcome",
        @"disposition",
        @"payeeType",
        @"item",
        @"additem",
        @"error",
        @"totalCost",
        @"unallocDeductable",
        @"totalBenefit",
        @"paymentAdjustment",
        @"paymentAdjustmentReason",
        @"paymentDate",
        @"paymentAmount",
        @"paymentRef",
        @"reserved",
        @"form",
        @"note",
    ];
}

+ (NSArray *)orderArrayForFHIRNotesComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"number",
        @"type",
        @"text",
    ];
}

+ (NSArray *)orderArrayForFHIRItemsComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"sequenceLinkId",
        @"noteNumber",
        @"adjudication",
        @"detail",
    ];
}

+ (NSArray *)orderArrayForFHIRItemSubdetailComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"sequenceLinkId",
        @"adjudication",
    ];
}

+ (NSArray *)orderArrayForFHIRAddedItemDetailAdjudicationComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"code",
        @"amount",
        @"value",
    ];
}

+ (NSArray *)orderArrayForFHIRAddedItemAdjudicationComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"code",
        @"amount",
        @"value",
    ];
}

+ (NSArray *)orderArrayForFHIRDetailAdjudicationComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"code",
        @"amount",
        @"value",
    ];
}

+ (NSArray *)orderArrayForFHIRErrorsComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"sequenceLinkId",
        @"detailSequenceLinkId",
        @"subdetailSequenceLinkId",
        @"code",
    ];
}

+ (NSArray *)orderArrayForFHIRAddedItemComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"sequenceLinkId",
        @"service",
        @"fee",
        @"noteNumberLinkId",
        @"adjudication",
        @"detail",
    ];
}

+ (NSArray *)orderArrayForFHIRItemAdjudicationComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"code",
        @"amount",
        @"value",
    ];
}

+ (NSArray *)orderArrayForFHIRAddedItemsDetailComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"service",
        @"fee",
        @"adjudication",
    ];
}

+ (NSArray *)orderArrayForFHIRSubdetailAdjudicationComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"code",
        @"amount",
        @"value",
    ];
}

+ (NSArray *)orderArrayForFHIRItemDetailComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"sequenceLinkId",
        @"adjudication",
        @"subdetail",
    ];
}

+ (NSArray *)orderArrayForFHIRClinicalAssessment
{
    return @[
    
        @"id",
        @"meta",
        @"implicitRules",
        @"language",
        @"text",
        @"contained",
        @"extension",
        @"modifierExtension",
        @"patient",
        @"assessor",
        @"date",
        @"description",
        @"previous",
        @"problem",
        @"careplan",
        @"referral",
        @"investigations",
        @"protocol",
        @"summary",
        @"diagnosis",
        @"resolved",
        @"ruledOut",
        @"prognosis",
        @"plan",
        @"action",
    ];
}

+ (NSArray *)orderArrayForFHIRClinicalAssessmentRuledOutComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"item",
        @"reason",
    ];
}

+ (NSArray *)orderArrayForFHIRClinicalAssessmentInvestigationsComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"code",
        @"item",
    ];
}

+ (NSArray *)orderArrayForFHIRClinicalAssessmentDiagnosisComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"item",
        @"cause",
    ];
}

+ (NSArray *)orderArrayForFHIRCommunication
{
    return @[
    
        @"id",
        @"meta",
        @"implicitRules",
        @"language",
        @"text",
        @"contained",
        @"extension",
        @"modifierExtension",
        @"identifier",
        @"category",
        @"sender",
        @"recipient",
        @"payload",
        @"medium",
        @"status",
        @"encounter",
        @"sent",
        @"received",
        @"reason",
        @"subject",
    ];
}

+ (NSArray *)orderArrayForFHIRCommunicationPayloadComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"content",
    ];
}

+ (NSArray *)orderArrayForFHIRCommunicationRequest
{
    return @[
    
        @"id",
        @"meta",
        @"implicitRules",
        @"language",
        @"text",
        @"contained",
        @"extension",
        @"modifierExtension",
        @"identifier",
        @"category",
        @"sender",
        @"recipient",
        @"payload",
        @"medium",
        @"requester",
        @"status",
        @"encounter",
        @"scheduledTime",
        @"reason",
        @"orderedOn",
        @"subject",
        @"priority",
    ];
}

+ (NSArray *)orderArrayForFHIRCommunicationRequestPayloadComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"content",
    ];
}

+ (NSArray *)orderArrayForFHIRComposition
{
    return @[
    
        @"id",
        @"meta",
        @"implicitRules",
        @"language",
        @"text",
        @"contained",
        @"extension",
        @"modifierExtension",
        @"identifier",
        @"date",
        @"type",
        @"class_",
        @"title",
        @"status",
        @"confidentiality",
        @"subject",
        @"author",
        @"attester",
        @"custodian",
        @"event_",
        @"encounter",
        @"section",
    ];
}

+ (NSArray *)orderArrayForFHIRSectionComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"title",
        @"code",
        @"section",
        @"content",
    ];
}

+ (NSArray *)orderArrayForFHIRCompositionEventComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"code",
        @"period",
        @"detail",
    ];
}

+ (NSArray *)orderArrayForFHIRCompositionAttesterComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"mode",
        @"time",
        @"party",
    ];
}

+ (NSArray *)orderArrayForFHIRConceptMap
{
    return @[
    
        @"id",
        @"meta",
        @"implicitRules",
        @"language",
        @"text",
        @"contained",
        @"extension",
        @"modifierExtension",
        @"identifier",
        @"version",
        @"name",
        @"publisher",
        @"telecom",
        @"description",
        @"copyright",
        @"status",
        @"experimental",
        @"date",
        @"source",
        @"target",
        @"element",
    ];
}

+ (NSArray *)orderArrayForFHIRConceptMapElementComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"codeSystem",
        @"code",
        @"dependsOn",
        @"map",
    ];
}

+ (NSArray *)orderArrayForFHIRConceptMapElementMapComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"codeSystem",
        @"code",
        @"equivalence",
        @"comments",
        @"product",
    ];
}

+ (NSArray *)orderArrayForFHIROtherElementComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"element",
        @"codeSystem",
        @"code",
    ];
}

+ (NSArray *)orderArrayForFHIRCondition
{
    return @[
    
        @"id",
        @"meta",
        @"implicitRules",
        @"language",
        @"text",
        @"contained",
        @"extension",
        @"modifierExtension",
        @"identifier",
        @"subject",
        @"encounter",
        @"asserter",
        @"dateAsserted",
        @"code",
        @"category",
        @"status",
        @"certainty",
        @"severity",
        @"onset",
        @"abatement",
        @"stage",
        @"evidence",
        @"location",
        @"dueTo",
        @"occurredFollowing",
        @"notes",
    ];
}

+ (NSArray *)orderArrayForFHIRConditionEvidenceComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"code",
        @"detail",
    ];
}

+ (NSArray *)orderArrayForFHIRConditionDueToComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"codeableConcept",
        @"target",
    ];
}

+ (NSArray *)orderArrayForFHIRConditionOccurredFollowingComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"codeableConcept",
        @"target",
    ];
}

+ (NSArray *)orderArrayForFHIRConditionStageComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"summary",
        @"assessment",
    ];
}

+ (NSArray *)orderArrayForFHIRConditionLocationComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"code",
        @"detail",
    ];
}

+ (NSArray *)orderArrayForFHIRConformance
{
    return @[
    
        @"id",
        @"meta",
        @"implicitRules",
        @"language",
        @"text",
        @"contained",
        @"extension",
        @"modifierExtension",
        @"identifier",
        @"version",
        @"name",
        @"publisher",
        @"telecom",
        @"description",
        @"status",
        @"experimental",
        @"date",
        @"software",
        @"implementation",
        @"fhirVersion",
        @"acceptUnknown",
        @"format",
        @"profile",
        @"rest",
        @"messaging",
        @"document",
    ];
}

+ (NSArray *)orderArrayForFHIRConformanceRestComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"mode",
        @"documentation",
        @"security",
        @"resource",
        @"interaction",
        @"operation",
        @"documentMailbox",
    ];
}

+ (NSArray *)orderArrayForFHIRConformanceSoftwareComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"name",
        @"version",
        @"releaseDate",
    ];
}

+ (NSArray *)orderArrayForFHIRConformanceMessagingComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"endpoint",
        @"reliableCache",
        @"documentation",
        @"event_",
    ];
}

+ (NSArray *)orderArrayForFHIRConformanceDocumentComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"mode",
        @"documentation",
        @"profile",
    ];
}

+ (NSArray *)orderArrayForFHIRConformanceRestResourceComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"type",
        @"profile",
        @"interaction",
        @"versioning",
        @"readHistory",
        @"updateCreate",
        @"searchInclude",
        @"searchParam",
    ];
}

+ (NSArray *)orderArrayForFHIRConformanceImplementationComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"description",
        @"url",
    ];
}

+ (NSArray *)orderArrayForFHIRConformanceMessagingEventComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"code",
        @"category",
        @"mode",
        @"protocol",
        @"focus",
        @"request",
        @"response",
        @"documentation",
    ];
}

+ (NSArray *)orderArrayForFHIRSystemInteractionComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"code",
        @"documentation",
    ];
}

+ (NSArray *)orderArrayForFHIRResourceInteractionComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"code",
        @"documentation",
    ];
}

+ (NSArray *)orderArrayForFHIRConformanceRestSecurityComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"cors",
        @"service",
        @"description",
        @"certificate",
    ];
}

+ (NSArray *)orderArrayForFHIRConformanceRestSecurityCertificateComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"type",
        @"blob",
    ];
}

+ (NSArray *)orderArrayForFHIRConformanceRestOperationComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"name",
        @"definition",
    ];
}

+ (NSArray *)orderArrayForFHIRConformanceRestResourceSearchParamComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"name",
        @"definition",
        @"type",
        @"documentation",
        @"target",
        @"chain",
    ];
}

+ (NSArray *)orderArrayForFHIRContract
{
    return @[
    
        @"id",
        @"meta",
        @"implicitRules",
        @"language",
        @"text",
        @"contained",
        @"extension",
        @"modifierExtension",
        @"identifier",
        @"subject",
        @"authority",
        @"domain",
        @"type",
        @"subtype",
        @"issued",
        @"applies",
        @"quantity",
        @"unitPrice",
        @"factor",
        @"points",
        @"net",
        @"author",
        @"grantor",
        @"grantee",
        @"witness",
        @"executor",
        @"notary",
        @"signer",
        @"term",
        @"binding",
        @"bindingDateTime",
        @"friendly",
        @"friendlyDateTime",
        @"legal",
        @"legalDateTime",
        @"rule",
        @"ruleDateTime",
    ];
}

+ (NSArray *)orderArrayForFHIRContractSignerComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"type",
        @"signature",
    ];
}

+ (NSArray *)orderArrayForFHIRContractTermComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"identifier",
        @"type",
        @"subtype",
        @"subject",
        @"text",
        @"issued",
        @"applies",
        @"quantity",
        @"unitPrice",
        @"factor",
        @"points",
        @"net",
    ];
}

+ (NSArray *)orderArrayForFHIRContraindication
{
    return @[
    
        @"id",
        @"meta",
        @"implicitRules",
        @"language",
        @"text",
        @"contained",
        @"extension",
        @"modifierExtension",
        @"patient",
        @"category",
        @"severity",
        @"implicated",
        @"detail",
        @"date",
        @"author",
        @"identifier",
        @"reference",
        @"mitigation",
    ];
}

+ (NSArray *)orderArrayForFHIRContraindicationMitigationComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"action",
        @"date",
        @"author",
    ];
}

+ (NSArray *)orderArrayForFHIRCoverage
{
    return @[
    
        @"id",
        @"meta",
        @"implicitRules",
        @"language",
        @"text",
        @"contained",
        @"extension",
        @"modifierExtension",
        @"issuer",
        @"period",
        @"type",
        @"identifier",
        @"group",
        @"plan",
        @"subplan",
        @"dependent",
        @"sequence",
        @"subscriber",
        @"network",
        @"contract",
    ];
}

+ (NSArray *)orderArrayForFHIRDataElement
{
    return @[
    
        @"id",
        @"meta",
        @"implicitRules",
        @"language",
        @"text",
        @"contained",
        @"extension",
        @"modifierExtension",
        @"identifier",
        @"version",
        @"publisher",
        @"telecom",
        @"status",
        @"date",
        @"name",
        @"category",
        @"granularity",
        @"code",
        @"question",
        @"label",
        @"definition",
        @"comments",
        @"requirements",
        @"synonym",
        @"type",
        @"example",
        @"maxLength",
        @"units",
        @"binding",
        @"mapping",
    ];
}

+ (NSArray *)orderArrayForFHIRDataElementMappingComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"uri",
        @"definitional",
        @"name",
        @"comments",
        @"map",
    ];
}

+ (NSArray *)orderArrayForFHIRDataElementBindingComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"isExtensible",
        @"conformance",
        @"description",
        @"valueSet",
    ];
}

+ (NSArray *)orderArrayForFHIRDevice
{
    return @[
    
        @"id",
        @"meta",
        @"implicitRules",
        @"language",
        @"text",
        @"contained",
        @"extension",
        @"modifierExtension",
        @"identifier",
        @"type",
        @"manufacturer",
        @"model",
        @"version",
        @"expiry",
        @"udi",
        @"lotNumber",
        @"owner",
        @"location",
        @"patient",
        @"contact",
        @"url",
    ];
}

+ (NSArray *)orderArrayForFHIRDeviceComponent
{
    return @[
    
        @"id",
        @"meta",
        @"implicitRules",
        @"language",
        @"text",
        @"contained",
        @"extension",
        @"modifierExtension",
        @"type",
        @"identifier",
        @"lastSystemChange",
        @"source",
        @"parent",
        @"operationalStatus",
        @"parameterGroup",
        @"measurementPrinciple",
        @"productionSpecification",
        @"languageCode",
    ];
}

+ (NSArray *)orderArrayForFHIRDeviceComponentProductionSpecificationComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"specType",
        @"componentId",
        @"productionSpec",
    ];
}

+ (NSArray *)orderArrayForFHIRDeviceMetric
{
    return @[
    
        @"id",
        @"meta",
        @"implicitRules",
        @"language",
        @"type",
        @"identifier",
        @"unit",
        @"source",
        @"parent",
        @"operationalState",
        @"measurementMode",
        @"color",
        @"category",
        @"measurementPeriod",
        @"calibrationInfo",
    ];
}

+ (NSArray *)orderArrayForFHIRDeviceMetricCalibrationInfoComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"type",
        @"state",
        @"time",
    ];
}

+ (NSArray *)orderArrayForFHIRDeviceUseRequest
{
    return @[
    
        @"id",
        @"meta",
        @"implicitRules",
        @"language",
        @"text",
        @"contained",
        @"extension",
        @"modifierExtension",
        @"bodySite",
        @"status",
        @"device",
        @"encounter",
        @"identifier",
        @"indication",
        @"notes",
        @"prnReason",
        @"orderedOn",
        @"recordedOn",
        @"subject",
        @"timing",
        @"priority",
    ];
}

+ (NSArray *)orderArrayForFHIRDeviceUseStatement
{
    return @[
    
        @"id",
        @"meta",
        @"implicitRules",
        @"language",
        @"text",
        @"contained",
        @"extension",
        @"modifierExtension",
        @"bodySite",
        @"whenUsed",
        @"device",
        @"identifier",
        @"indication",
        @"notes",
        @"recordedOn",
        @"subject",
        @"timing",
    ];
}

+ (NSArray *)orderArrayForFHIRDiagnosticOrder
{
    return @[
    
        @"id",
        @"meta",
        @"implicitRules",
        @"language",
        @"text",
        @"contained",
        @"extension",
        @"modifierExtension",
        @"subject",
        @"orderer",
        @"identifier",
        @"encounter",
        @"clinicalNotes",
        @"supportingInformation",
        @"specimen",
        @"status",
        @"priority",
        @"event_",
        @"item",
    ];
}

+ (NSArray *)orderArrayForFHIRDiagnosticOrderItemComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"code",
        @"specimen",
        @"bodySite",
        @"status",
        @"event_",
    ];
}

+ (NSArray *)orderArrayForFHIRDiagnosticOrderEventComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"status",
        @"description",
        @"dateTime",
        @"actor",
    ];
}

+ (NSArray *)orderArrayForFHIRDiagnosticReport
{
    return @[
    
        @"id",
        @"meta",
        @"implicitRules",
        @"language",
        @"text",
        @"contained",
        @"extension",
        @"modifierExtension",
        @"name",
        @"status",
        @"issued",
        @"subject",
        @"performer",
        @"identifier",
        @"requestDetail",
        @"serviceCategory",
        @"diagnostic",
        @"specimen",
        @"result",
        @"imagingStudy",
        @"image",
        @"conclusion",
        @"codedDiagnosis",
        @"presentedForm",
    ];
}

+ (NSArray *)orderArrayForFHIRDiagnosticReportImageComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"comment",
        @"link",
    ];
}

+ (NSArray *)orderArrayForFHIRDocumentManifest
{
    return @[
    
        @"id",
        @"meta",
        @"implicitRules",
        @"language",
        @"text",
        @"contained",
        @"extension",
        @"modifierExtension",
        @"masterIdentifier",
        @"identifier",
        @"subject",
        @"recipient",
        @"type",
        @"author",
        @"created",
        @"source",
        @"status",
        @"supercedes",
        @"description",
        @"confidentiality",
        @"content",
    ];
}

+ (NSArray *)orderArrayForFHIRDocumentReference
{
    return @[
    
        @"id",
        @"meta",
        @"implicitRules",
        @"language",
        @"text",
        @"contained",
        @"extension",
        @"modifierExtension",
        @"masterIdentifier",
        @"identifier",
        @"subject",
        @"type",
        @"class_",
        @"author",
        @"custodian",
        @"policyManager",
        @"authenticator",
        @"created",
        @"indexed",
        @"status",
        @"docStatus",
        @"relatesTo",
        @"description",
        @"confidentiality",
        @"primaryLanguage",
        @"mimeType",
        @"format",
        @"size",
        @"hash",
        @"location",
        @"service",
        @"context",
    ];
}

+ (NSArray *)orderArrayForFHIRDocumentReferenceContextComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"event_",
        @"period",
        @"facilityType",
    ];
}

+ (NSArray *)orderArrayForFHIRDocumentReferenceRelatesToComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"code",
        @"target",
    ];
}

+ (NSArray *)orderArrayForFHIRDocumentReferenceServiceParameterComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"name",
        @"value",
    ];
}

+ (NSArray *)orderArrayForFHIRDocumentReferenceServiceComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"type",
        @"address",
        @"parameter",
    ];
}

+ (NSArray *)orderArrayForFHIREligibilityRequest
{
    return @[
    
        @"id",
        @"meta",
        @"implicitRules",
        @"language",
        @"text",
        @"contained",
        @"extension",
        @"modifierExtension",
        @"identifier",
        @"ruleset",
        @"originalRuleset",
        @"created",
        @"target",
        @"provider",
        @"organization",
    ];
}

+ (NSArray *)orderArrayForFHIREligibilityResponse
{
    return @[
    
        @"id",
        @"meta",
        @"implicitRules",
        @"language",
        @"text",
        @"contained",
        @"extension",
        @"modifierExtension",
        @"identifier",
        @"request",
        @"outcome",
        @"disposition",
        @"ruleset",
        @"originalRuleset",
        @"created",
        @"organization",
        @"requestProvider",
        @"requestOrganization",
    ];
}

+ (NSArray *)orderArrayForFHIREncounter
{
    return @[
    
        @"id",
        @"meta",
        @"implicitRules",
        @"language",
        @"text",
        @"contained",
        @"extension",
        @"modifierExtension",
        @"identifier",
        @"status",
        @"statusHistory",
        @"class_",
        @"type",
        @"patient",
        @"episodeOfCare",
        @"participant",
        @"fulfills",
        @"period",
        @"length",
        @"reason",
        @"indication",
        @"priority",
        @"hospitalization",
        @"location",
        @"serviceProvider",
        @"partOf",
    ];
}

+ (NSArray *)orderArrayForFHIREncounterHospitalizationComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"preAdmissionIdentifier",
        @"origin",
        @"admitSource",
        @"diet",
        @"specialCourtesy",
        @"specialArrangement",
        @"destination",
        @"dischargeDisposition",
        @"dischargeDiagnosis",
        @"reAdmission",
    ];
}

+ (NSArray *)orderArrayForFHIREncounterStatusHistoryComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"status",
        @"period",
    ];
}

+ (NSArray *)orderArrayForFHIREncounterLocationComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"location",
        @"status",
        @"period",
    ];
}

+ (NSArray *)orderArrayForFHIREncounterParticipantComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"type",
        @"period",
        @"individual",
    ];
}

+ (NSArray *)orderArrayForFHIREnrollmentRequest
{
    return @[
    
        @"id",
        @"meta",
        @"implicitRules",
        @"language",
        @"text",
        @"contained",
        @"extension",
        @"modifierExtension",
        @"identifier",
        @"ruleset",
        @"originalRuleset",
        @"created",
        @"target",
        @"provider",
        @"organization",
        @"subject",
        @"coverage",
        @"relationship",
    ];
}

+ (NSArray *)orderArrayForFHIREnrollmentResponse
{
    return @[
    
        @"id",
        @"meta",
        @"implicitRules",
        @"language",
        @"text",
        @"contained",
        @"extension",
        @"modifierExtension",
        @"identifier",
        @"request",
        @"outcome",
        @"disposition",
        @"ruleset",
        @"originalRuleset",
        @"created",
        @"organization",
        @"requestProvider",
        @"requestOrganization",
    ];
}

+ (NSArray *)orderArrayForFHIREpisodeOfCare
{
    return @[
    
        @"id",
        @"meta",
        @"implicitRules",
        @"language",
        @"text",
        @"contained",
        @"extension",
        @"modifierExtension",
        @"identifier",
        @"currentStatus",
        @"statusHistory",
        @"type",
        @"patient",
        @"managingOrganization",
        @"period",
        @"condition",
        @"referralRequest",
        @"careManager",
        @"careTeam",
    ];
}

+ (NSArray *)orderArrayForFHIREpisodeOfCareStatusHistoryComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"status",
        @"period",
    ];
}

+ (NSArray *)orderArrayForFHIREpisodeOfCareCareTeamComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"member",
        @"role",
        @"period",
    ];
}

+ (NSArray *)orderArrayForFHIRExplanationOfBenefit
{
    return @[
    
        @"id",
        @"meta",
        @"implicitRules",
        @"language",
        @"text",
        @"contained",
        @"extension",
        @"modifierExtension",
        @"identifier",
        @"request",
        @"outcome",
        @"disposition",
        @"ruleset",
        @"originalRuleset",
        @"created",
        @"organization",
        @"requestProvider",
        @"requestOrganization",
    ];
}

+ (NSArray *)orderArrayForFHIRExtensionDefinition
{
    return @[
    
        @"id",
        @"meta",
        @"implicitRules",
        @"language",
        @"text",
        @"contained",
        @"extension",
        @"modifierExtension",
        @"url",
        @"identifier",
        @"name",
        @"display",
        @"publisher",
        @"telecom",
        @"description",
        @"code",
        @"status",
        @"experimental",
        @"date",
        @"requirements",
        @"mapping",
        @"contextType",
        @"context",
        @"element",
    ];
}

+ (NSArray *)orderArrayForFHIRExtensionDefinitionMappingComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"identity",
        @"uri",
        @"name",
        @"comments",
    ];
}

+ (NSArray *)orderArrayForFHIRFamilyHistory
{
    return @[
    
        @"id",
        @"meta",
        @"implicitRules",
        @"language",
        @"text",
        @"contained",
        @"extension",
        @"modifierExtension",
        @"identifier",
        @"patient",
        @"date",
        @"note",
        @"relation",
    ];
}

+ (NSArray *)orderArrayForFHIRFamilyHistoryRelationConditionComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"type",
        @"outcome",
        @"onset",
        @"note",
    ];
}

+ (NSArray *)orderArrayForFHIRFamilyHistoryRelationComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"name",
        @"relationship",
        @"born",
        @"age",
        @"deceased",
        @"note",
        @"condition",
    ];
}

+ (NSArray *)orderArrayForFHIRGoal
{
    return @[
    
        @"id",
        @"meta",
        @"implicitRules",
        @"language",
        @"text",
        @"contained",
        @"extension",
        @"modifierExtension",
        @"identifier",
        @"patient",
        @"description",
        @"status",
        @"notes",
        @"concern",
    ];
}

+ (NSArray *)orderArrayForFHIRGroup
{
    return @[
    
        @"id",
        @"meta",
        @"implicitRules",
        @"language",
        @"text",
        @"contained",
        @"extension",
        @"modifierExtension",
        @"identifier",
        @"type",
        @"actual",
        @"code",
        @"name",
        @"quantity",
        @"characteristic",
        @"member",
    ];
}

+ (NSArray *)orderArrayForFHIRGroupCharacteristicComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"code",
        @"value",
        @"exclude",
    ];
}

+ (NSArray *)orderArrayForFHIRHealthcareService
{
    return @[
    
        @"id",
        @"meta",
        @"implicitRules",
        @"language",
        @"text",
        @"contained",
        @"extension",
        @"modifierExtension",
        @"identifier",
        @"location",
        @"serviceCategory",
        @"serviceType",
        @"serviceName",
        @"comment",
        @"extraDetails",
        @"freeProvisionCode",
        @"eligibility",
        @"eligibilityNote",
        @"appointmentRequired",
        @"imageURI",
        @"availableTime",
        @"notAvailableTime",
        @"availabilityExceptions",
        @"publicKey",
        @"programName",
        @"contactPoint",
        @"characteristic",
        @"referralMethod",
        @"setting",
        @"targetGroup",
        @"coverageArea",
        @"catchmentArea",
        @"serviceCode",
    ];
}

+ (NSArray *)orderArrayForFHIRServiceTypeComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"type",
        @"specialty",
    ];
}

+ (NSArray *)orderArrayForFHIRHealthcareServiceAvailableTimeComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"daysOfWeek",
        @"allDay",
        @"availableStartTime",
        @"availableEndTime",
    ];
}

+ (NSArray *)orderArrayForFHIRHealthcareServiceNotAvailableTimeComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"description",
        @"startDate",
        @"endDate",
    ];
}

+ (NSArray *)orderArrayForFHIRImagingObjectSelection
{
    return @[
    
        @"id",
        @"meta",
        @"implicitRules",
        @"language",
        @"text",
        @"contained",
        @"extension",
        @"modifierExtension",
        @"uid",
        @"patient",
        @"title",
        @"description",
        @"author",
        @"authoringTime",
        @"study",
    ];
}

+ (NSArray *)orderArrayForFHIRStudyComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"uid",
        @"retrieveAETitle",
        @"retrieveUrl",
        @"series",
    ];
}

+ (NSArray *)orderArrayForFHIRInstanceComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"sopClass",
        @"uid",
        @"retrieveAETitle",
        @"retrieveUrl",
    ];
}

+ (NSArray *)orderArrayForFHIRSeriesComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"uid",
        @"retrieveAETitle",
        @"retrieveUrl",
        @"instance",
    ];
}

+ (NSArray *)orderArrayForFHIRImagingStudy
{
    return @[
    
        @"id",
        @"meta",
        @"implicitRules",
        @"language",
        @"text",
        @"contained",
        @"extension",
        @"modifierExtension",
        @"started",
        @"patient",
        @"uid",
        @"accession",
        @"identifier",
        @"order",
        @"modalityList",
        @"referrer",
        @"availability",
        @"url",
        @"numberOfSeries",
        @"numberOfInstances",
        @"clinicalInformation",
        @"procedure",
        @"interpreter",
        @"description",
        @"series",
    ];
}

+ (NSArray *)orderArrayForFHIRImagingStudySeriesComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"number",
        @"modality",
        @"uid",
        @"description",
        @"numberOfInstances",
        @"availability",
        @"url",
        @"bodySite",
        @"dateTime",
        @"instance",
    ];
}

+ (NSArray *)orderArrayForFHIRImagingStudySeriesInstanceComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"number",
        @"uid",
        @"sopclass",
        @"type",
        @"title",
        @"url",
        @"attachment",
    ];
}

+ (NSArray *)orderArrayForFHIRImmunization
{
    return @[
    
        @"id",
        @"meta",
        @"implicitRules",
        @"language",
        @"text",
        @"contained",
        @"extension",
        @"modifierExtension",
        @"identifier",
        @"date",
        @"vaccineType",
        @"subject",
        @"refusedIndicator",
        @"reported",
        @"performer",
        @"requester",
        @"manufacturer",
        @"location",
        @"lotNumber",
        @"expirationDate",
        @"site",
        @"route",
        @"doseQuantity",
        @"explanation",
        @"reaction",
        @"vaccinationProtocol",
    ];
}

+ (NSArray *)orderArrayForFHIRImmunizationVaccinationProtocolComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"doseSequence",
        @"description",
        @"authority",
        @"series",
        @"seriesDoses",
        @"doseTarget",
        @"doseStatus",
        @"doseStatusReason",
    ];
}

+ (NSArray *)orderArrayForFHIRImmunizationExplanationComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"reason",
        @"refusalReason",
    ];
}

+ (NSArray *)orderArrayForFHIRImmunizationReactionComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"date",
        @"detail",
        @"reported",
    ];
}

+ (NSArray *)orderArrayForFHIRImmunizationRecommendation
{
    return @[
    
        @"id",
        @"meta",
        @"implicitRules",
        @"language",
        @"text",
        @"contained",
        @"extension",
        @"modifierExtension",
        @"identifier",
        @"subject",
        @"recommendation",
    ];
}

+ (NSArray *)orderArrayForFHIRImmunizationRecommendationRecommendationDateCriterionComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"code",
        @"value",
    ];
}

+ (NSArray *)orderArrayForFHIRImmunizationRecommendationRecommendationProtocolComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"doseSequence",
        @"description",
        @"authority",
        @"series",
    ];
}

+ (NSArray *)orderArrayForFHIRImmunizationRecommendationRecommendationComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"date",
        @"vaccineType",
        @"doseNumber",
        @"forecastStatus",
        @"dateCriterion",
        @"protocol",
        @"supportingImmunization",
        @"supportingPatientInformation",
    ];
}

+ (NSArray *)orderArrayForFHIRInstitutionalClaim
{
    return @[
    
        @"id",
        @"meta",
        @"implicitRules",
        @"language",
        @"text",
        @"contained",
        @"extension",
        @"modifierExtension",
        @"identifier",
        @"ruleset",
        @"originalRuleset",
        @"created",
        @"target",
        @"provider",
        @"organization",
        @"use",
        @"priority",
        @"fundsReserve",
        @"enterer",
        @"facility",
        @"payee",
        @"referral",
        @"diagnosis",
        @"condition",
        @"patient",
        @"coverage",
        @"exception",
        @"school",
        @"accident",
        @"accidentType",
        @"interventionException",
        @"item",
        @"additionalMaterials",
    ];
}

+ (NSArray *)orderArrayForFHIRItemsComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"sequence",
        @"type",
        @"provider",
        @"diagnosisLinkId",
        @"service",
        @"serviceDate",
        @"quantity",
        @"unitPrice",
        @"factor",
        @"points",
        @"net",
        @"udi",
        @"bodySite",
        @"subsite",
        @"modifier",
        @"detail",
    ];
}

+ (NSArray *)orderArrayForFHIRDetailComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"sequence",
        @"type",
        @"service",
        @"quantity",
        @"unitPrice",
        @"factor",
        @"points",
        @"net",
        @"udi",
        @"subDetail",
    ];
}

+ (NSArray *)orderArrayForFHIRCoverageComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"sequence",
        @"focal",
        @"coverage",
        @"businessArrangement",
        @"relationship",
        @"preauthref",
        @"claimResponse",
        @"originalRuleset",
    ];
}

+ (NSArray *)orderArrayForFHIRPayeeComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"type",
        @"provider",
        @"organization",
        @"person",
    ];
}

+ (NSArray *)orderArrayForFHIRDiagnosisComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"sequence",
        @"diagnosis",
    ];
}

+ (NSArray *)orderArrayForFHIRSubDetailComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"sequence",
        @"type",
        @"service",
        @"quantity",
        @"unitPrice",
        @"factor",
        @"points",
        @"net",
        @"udi",
    ];
}

+ (NSArray *)orderArrayForFHIRList
{
    return @[
    
        @"id",
        @"meta",
        @"implicitRules",
        @"language",
        @"text",
        @"contained",
        @"extension",
        @"modifierExtension",
        @"identifier",
        @"code",
        @"subject",
        @"source",
        @"date",
        @"ordered",
        @"mode",
        @"entry",
        @"emptyReason",
    ];
}

+ (NSArray *)orderArrayForFHIRListEntryComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"flag",
        @"deleted",
        @"date",
        @"item",
    ];
}

+ (NSArray *)orderArrayForFHIRLocation
{
    return @[
    
        @"id",
        @"meta",
        @"implicitRules",
        @"language",
        @"text",
        @"contained",
        @"extension",
        @"modifierExtension",
        @"identifier",
        @"name",
        @"description",
        @"type",
        @"telecom",
        @"address",
        @"physicalType",
        @"position",
        @"managingOrganization",
        @"status",
        @"partOf",
        @"mode",
    ];
}

+ (NSArray *)orderArrayForFHIRLocationPositionComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"longitude",
        @"latitude",
        @"altitude",
    ];
}

+ (NSArray *)orderArrayForFHIRMedia
{
    return @[
    
        @"id",
        @"meta",
        @"implicitRules",
        @"language",
        @"text",
        @"contained",
        @"extension",
        @"modifierExtension",
        @"type",
        @"subtype",
        @"identifier",
        @"created",
        @"subject",
        @"operator_",
        @"view",
        @"deviceName",
        @"height",
        @"width",
        @"frames",
        @"duration",
        @"content",
    ];
}

+ (NSArray *)orderArrayForFHIRMedication
{
    return @[
    
        @"id",
        @"meta",
        @"implicitRules",
        @"language",
        @"text",
        @"contained",
        @"extension",
        @"modifierExtension",
        @"name",
        @"code",
        @"isBrand",
        @"manufacturer",
        @"kind",
        @"product",
        @"package",
    ];
}

+ (NSArray *)orderArrayForFHIRMedicationPackageContentComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"item",
        @"amount",
    ];
}

+ (NSArray *)orderArrayForFHIRMedicationPackageComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"container",
        @"content",
    ];
}

+ (NSArray *)orderArrayForFHIRMedicationProductIngredientComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"item",
        @"amount",
    ];
}

+ (NSArray *)orderArrayForFHIRMedicationProductComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"form",
        @"ingredient",
    ];
}

+ (NSArray *)orderArrayForFHIRMedicationAdministration
{
    return @[
    
        @"id",
        @"meta",
        @"implicitRules",
        @"language",
        @"text",
        @"contained",
        @"extension",
        @"modifierExtension",
        @"identifier",
        @"status",
        @"patient",
        @"practitioner",
        @"encounter",
        @"prescription",
        @"wasNotGiven",
        @"reasonNotGiven",
        @"effectiveTime",
        @"medication",
        @"device",
        @"dosage",
    ];
}

+ (NSArray *)orderArrayForFHIRMedicationAdministrationDosageComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"timing",
        @"asNeeded",
        @"site",
        @"route",
        @"method",
        @"quantity",
        @"rate",
        @"maxDosePerPeriod",
    ];
}

+ (NSArray *)orderArrayForFHIRMedicationDispense
{
    return @[
    
        @"id",
        @"meta",
        @"implicitRules",
        @"language",
        @"text",
        @"contained",
        @"extension",
        @"modifierExtension",
        @"identifier",
        @"status",
        @"patient",
        @"dispenser",
        @"authorizingPrescription",
        @"dispense",
        @"substitution",
    ];
}

+ (NSArray *)orderArrayForFHIRMedicationDispenseDispenseDosageComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"additionalInstructions",
        @"schedule",
        @"asNeeded",
        @"site",
        @"route",
        @"method",
        @"quantity",
        @"rate",
        @"maxDosePerPeriod",
    ];
}

+ (NSArray *)orderArrayForFHIRMedicationDispenseSubstitutionComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"type",
        @"reason",
        @"responsibleParty",
    ];
}

+ (NSArray *)orderArrayForFHIRMedicationDispenseDispenseComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"identifier",
        @"status",
        @"type",
        @"quantity",
        @"medication",
        @"whenPrepared",
        @"whenHandedOver",
        @"destination",
        @"receiver",
        @"dosage",
    ];
}

+ (NSArray *)orderArrayForFHIRMedicationPrescription
{
    return @[
    
        @"id",
        @"meta",
        @"implicitRules",
        @"language",
        @"text",
        @"contained",
        @"extension",
        @"modifierExtension",
        @"identifier",
        @"dateWritten",
        @"status",
        @"patient",
        @"prescriber",
        @"encounter",
        @"reason",
        @"medication",
        @"dosageInstruction",
        @"dispense",
        @"substitution",
    ];
}

+ (NSArray *)orderArrayForFHIRMedicationPrescriptionDosageInstructionComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"text",
        @"additionalInstructions",
        @"scheduled",
        @"asNeeded",
        @"site",
        @"route",
        @"method",
        @"doseQuantity",
        @"rate",
        @"maxDosePerPeriod",
    ];
}

+ (NSArray *)orderArrayForFHIRMedicationPrescriptionSubstitutionComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"type",
        @"reason",
    ];
}

+ (NSArray *)orderArrayForFHIRMedicationPrescriptionDispenseComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"medication",
        @"validityPeriod",
        @"numberOfRepeatsAllowed",
        @"quantity",
        @"expectedSupplyDuration",
    ];
}

+ (NSArray *)orderArrayForFHIRMedicationStatement
{
    return @[
    
        @"id",
        @"meta",
        @"implicitRules",
        @"language",
        @"text",
        @"contained",
        @"extension",
        @"modifierExtension",
        @"identifier",
        @"patient",
        @"wasNotGiven",
        @"reasonNotGiven",
        @"whenGiven",
        @"medication",
        @"device",
        @"dosage",
    ];
}

+ (NSArray *)orderArrayForFHIRMedicationStatementDosageComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"schedule",
        @"asNeeded",
        @"site",
        @"route",
        @"method",
        @"quantity",
        @"rate",
        @"maxDosePerPeriod",
    ];
}

+ (NSArray *)orderArrayForFHIRMessageHeader
{
    return @[
    
        @"id",
        @"meta",
        @"implicitRules",
        @"language",
        @"text",
        @"contained",
        @"extension",
        @"modifierExtension",
        @"identifier",
        @"timestamp",
        @"event_",
        @"response",
        @"source",
        @"destination",
        @"enterer",
        @"author",
        @"receiver",
        @"responsible",
        @"reason",
        @"data",
    ];
}

+ (NSArray *)orderArrayForFHIRMessageDestinationComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"name",
        @"target",
        @"endpoint",
    ];
}

+ (NSArray *)orderArrayForFHIRMessageSourceComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"name",
        @"software",
        @"version",
        @"contact",
        @"endpoint",
    ];
}

+ (NSArray *)orderArrayForFHIRMessageHeaderResponseComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"identifier",
        @"code",
        @"details",
    ];
}

+ (NSArray *)orderArrayForFHIRNamingSystem
{
    return @[
    
        @"id",
        @"meta",
        @"implicitRules",
        @"language",
        @"text",
        @"contained",
        @"extension",
        @"modifierExtension",
        @"type",
        @"name",
        @"status",
        @"country",
        @"category",
        @"responsible",
        @"description",
        @"usage",
        @"uniqueId",
        @"contact",
        @"replacedBy",
    ];
}

+ (NSArray *)orderArrayForFHIRNamingSystemContactComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"name",
        @"telecom",
    ];
}

+ (NSArray *)orderArrayForFHIRNamingSystemUniqueIdComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"type",
        @"value",
        @"preferred",
        @"period",
    ];
}

+ (NSArray *)orderArrayForFHIRNutritionOrder
{
    return @[
    
        @"id",
        @"meta",
        @"implicitRules",
        @"language",
        @"text",
        @"contained",
        @"extension",
        @"modifierExtension",
        @"subject",
        @"orderer",
        @"identifier",
        @"encounter",
        @"dateTime",
        @"allergyIntolerance",
        @"foodPreferenceModifier",
        @"excludeFoodModifier",
        @"item",
        @"status",
    ];
}

+ (NSArray *)orderArrayForFHIRNutritionOrderItemSupplementComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"type",
        @"quantity",
        @"name",
    ];
}

+ (NSArray *)orderArrayForFHIRNutritionOrderItemOralDietTextureComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"modifier",
        @"foodType",
    ];
}

+ (NSArray *)orderArrayForFHIRNutritionOrderItemComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"scheduled",
        @"isInEffect",
        @"oralDiet",
        @"supplement",
        @"enteralFormula",
    ];
}

+ (NSArray *)orderArrayForFHIRNutritionOrderItemEnteralFormulaComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"administrationInstructions",
        @"baseFormulaType",
        @"baseFormulaName",
        @"additiveType",
        @"additiveName",
        @"caloricDensity",
        @"routeofAdministration",
        @"quantity",
        @"rate",
        @"rateAdjustment",
        @"maxVolumeToDeliver",
    ];
}

+ (NSArray *)orderArrayForFHIRNutritionOrderItemOralDietComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"type",
        @"nutrients",
        @"texture",
        @"fluidConsistencyType",
        @"instruction",
    ];
}

+ (NSArray *)orderArrayForFHIRNutritionOrderItemOralDietNutrientsComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"modifier",
        @"amount",
    ];
}

+ (NSArray *)orderArrayForFHIRObservation
{
    return @[
    
        @"id",
        @"meta",
        @"implicitRules",
        @"language",
        @"text",
        @"contained",
        @"extension",
        @"modifierExtension",
        @"name",
        @"value",
        @"dataAbsentReason",
        @"interpretation",
        @"comments",
        @"applies",
        @"issued",
        @"status",
        @"reliability",
        @"bodySite",
        @"method",
        @"identifier",
        @"subject",
        @"specimen",
        @"performer",
        @"encounter",
        @"referenceRange",
        @"related",
    ];
}

+ (NSArray *)orderArrayForFHIRObservationReferenceRangeComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"low",
        @"high",
        @"meaning",
        @"age",
        @"text",
    ];
}

+ (NSArray *)orderArrayForFHIRObservationRelatedComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"type",
        @"target",
    ];
}

+ (NSArray *)orderArrayForFHIROperationDefinition
{
    return @[
    
        @"id",
        @"meta",
        @"implicitRules",
        @"language",
        @"text",
        @"contained",
        @"extension",
        @"modifierExtension",
        @"identifier",
        @"version",
        @"title",
        @"publisher",
        @"telecom",
        @"description",
        @"code",
        @"status",
        @"experimental",
        @"date",
        @"kind",
        @"name",
        @"notes",
        @"base_",
        @"system",
        @"type",
        @"instance",
        @"parameter",
    ];
}

+ (NSArray *)orderArrayForFHIROperationDefinitionParameterPartComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"name",
        @"min",
        @"max",
        @"documentation",
        @"type",
        @"profile",
    ];
}

+ (NSArray *)orderArrayForFHIROperationDefinitionParameterComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"name",
        @"use",
        @"min",
        @"max",
        @"documentation",
        @"type",
        @"profile",
        @"part",
    ];
}

+ (NSArray *)orderArrayForFHIROperationOutcome
{
    return @[
    
        @"id",
        @"meta",
        @"implicitRules",
        @"language",
        @"text",
        @"contained",
        @"extension",
        @"modifierExtension",
        @"issue",
    ];
}

+ (NSArray *)orderArrayForFHIROperationOutcomeIssueComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"severity",
        @"type",
        @"details",
        @"location",
    ];
}

+ (NSArray *)orderArrayForFHIROralHealthClaim
{
    return @[
    
        @"id",
        @"meta",
        @"implicitRules",
        @"language",
        @"text",
        @"contained",
        @"extension",
        @"modifierExtension",
        @"identifier",
        @"ruleset",
        @"originalRuleset",
        @"created",
        @"target",
        @"provider",
        @"organization",
        @"use",
        @"priority",
        @"fundsReserve",
        @"enterer",
        @"facility",
        @"payee",
        @"referral",
        @"diagnosis",
        @"condition",
        @"patient",
        @"coverage",
        @"exception",
        @"school",
        @"accident",
        @"accidentType",
        @"interventionException",
        @"missingteeth",
        @"orthoPlan",
        @"item",
        @"additionalMaterials",
    ];
}

+ (NSArray *)orderArrayForFHIRItemsComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"sequence",
        @"type",
        @"provider",
        @"diagnosisLinkId",
        @"service",
        @"serviceDate",
        @"quantity",
        @"unitPrice",
        @"factor",
        @"points",
        @"net",
        @"udi",
        @"bodySite",
        @"subsite",
        @"modifier",
        @"detail",
        @"prosthesis",
    ];
}

+ (NSArray *)orderArrayForFHIROrthodonticPlanComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"start",
        @"examFee",
        @"diagnosticFee",
        @"initialPayment",
        @"durationMonths",
        @"paymentCount",
        @"periodicPayment",
    ];
}

+ (NSArray *)orderArrayForFHIRDetailComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"sequence",
        @"type",
        @"service",
        @"quantity",
        @"unitPrice",
        @"factor",
        @"points",
        @"net",
        @"udi",
        @"subDetail",
    ];
}

+ (NSArray *)orderArrayForFHIRCoverageComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"sequence",
        @"focal",
        @"coverage",
        @"businessArrangement",
        @"relationship",
        @"preauthref",
        @"claimResponse",
        @"originalRuleset",
    ];
}

+ (NSArray *)orderArrayForFHIRPayeeComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"type",
        @"provider",
        @"organization",
        @"person",
    ];
}

+ (NSArray *)orderArrayForFHIRDiagnosisComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"sequence",
        @"diagnosis",
    ];
}

+ (NSArray *)orderArrayForFHIRProsthesisComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"initial",
        @"priorDate",
        @"priorMaterial",
    ];
}

+ (NSArray *)orderArrayForFHIRSubDetailComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"sequence",
        @"type",
        @"service",
        @"quantity",
        @"unitPrice",
        @"factor",
        @"points",
        @"net",
        @"udi",
    ];
}

+ (NSArray *)orderArrayForFHIRMissingTeethComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"tooth",
        @"reason",
        @"extractiondate",
    ];
}

+ (NSArray *)orderArrayForFHIROrder
{
    return @[
    
        @"id",
        @"meta",
        @"implicitRules",
        @"language",
        @"text",
        @"contained",
        @"extension",
        @"modifierExtension",
        @"identifier",
        @"date",
        @"subject",
        @"source",
        @"target",
        @"reason",
        @"authority",
        @"when",
        @"detail",
    ];
}

+ (NSArray *)orderArrayForFHIROrderWhenComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"code",
        @"schedule",
    ];
}

+ (NSArray *)orderArrayForFHIROrderResponse
{
    return @[
    
        @"id",
        @"meta",
        @"implicitRules",
        @"language",
        @"text",
        @"contained",
        @"extension",
        @"modifierExtension",
        @"identifier",
        @"request",
        @"date",
        @"who",
        @"authority",
        @"code",
        @"description",
        @"fulfillment",
    ];
}

+ (NSArray *)orderArrayForFHIROrganization
{
    return @[
    
        @"id",
        @"meta",
        @"implicitRules",
        @"language",
        @"text",
        @"contained",
        @"extension",
        @"modifierExtension",
        @"identifier",
        @"name",
        @"type",
        @"telecom",
        @"address",
        @"partOf",
        @"contact",
        @"location",
        @"active",
    ];
}

+ (NSArray *)orderArrayForFHIROrganizationContactComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"purpose",
        @"name",
        @"telecom",
        @"address",
        @"gender",
    ];
}

+ (NSArray *)orderArrayForFHIROther
{
    return @[
    
        @"id",
        @"meta",
        @"implicitRules",
        @"language",
        @"text",
        @"contained",
        @"extension",
        @"modifierExtension",
        @"identifier",
        @"code",
        @"subject",
        @"author",
        @"created",
    ];
}

+ (NSArray *)orderArrayForFHIRPatient
{
    return @[
    
        @"id",
        @"meta",
        @"implicitRules",
        @"language",
        @"text",
        @"contained",
        @"extension",
        @"modifierExtension",
        @"identifier",
        @"name",
        @"telecom",
        @"gender",
        @"birthDate",
        @"deceased",
        @"address",
        @"maritalStatus",
        @"multipleBirth",
        @"photo",
        @"contact",
        @"animal",
        @"communication",
        @"careProvider",
        @"managingOrganization",
        @"link",
        @"active",
    ];
}

+ (NSArray *)orderArrayForFHIRContactComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"relationship",
        @"name",
        @"telecom",
        @"address",
        @"gender",
        @"organization",
        @"period",
    ];
}

+ (NSArray *)orderArrayForFHIRAnimalComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"species",
        @"breed",
        @"genderStatus",
    ];
}

+ (NSArray *)orderArrayForFHIRPatientLinkComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"other",
        @"type",
    ];
}

+ (NSArray *)orderArrayForFHIRPaymentNotice
{
    return @[
    
        @"id",
        @"meta",
        @"implicitRules",
        @"language",
        @"text",
        @"contained",
        @"extension",
        @"modifierExtension",
        @"identifier",
        @"ruleset",
        @"originalRuleset",
        @"created",
        @"target",
        @"provider",
        @"organization",
        @"request",
        @"response",
        @"paymentStatus",
    ];
}

+ (NSArray *)orderArrayForFHIRPaymentReconciliation
{
    return @[
    
        @"id",
        @"meta",
        @"implicitRules",
        @"language",
        @"text",
        @"contained",
        @"extension",
        @"modifierExtension",
        @"identifier",
        @"request",
        @"outcome",
        @"disposition",
        @"ruleset",
        @"originalRuleset",
        @"created",
        @"period",
        @"organization",
        @"requestProvider",
        @"requestOrganization",
        @"detail",
        @"form",
        @"total",
        @"note",
    ];
}

+ (NSArray *)orderArrayForFHIRNotesComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"type",
        @"text",
    ];
}

+ (NSArray *)orderArrayForFHIRDetailsComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"type",
        @"request",
        @"responce",
        @"submitter",
        @"payee",
        @"date",
        @"amount",
    ];
}

+ (NSArray *)orderArrayForFHIRPendedRequest
{
    return @[
    
        @"id",
        @"meta",
        @"implicitRules",
        @"language",
        @"text",
        @"contained",
        @"extension",
        @"modifierExtension",
        @"identifier",
        @"ruleset",
        @"originalRuleset",
        @"created",
        @"target",
        @"provider",
        @"organization",
        @"request",
        @"include",
        @"exclude",
        @"period",
    ];
}

+ (NSArray *)orderArrayForFHIRPerson
{
    return @[
    
        @"id",
        @"meta",
        @"implicitRules",
        @"language",
        @"text",
        @"contained",
        @"extension",
        @"modifierExtension",
        @"identifier",
        @"name",
        @"telecom",
        @"gender",
        @"birthDate",
        @"address",
        @"photo",
        @"managingOrganization",
        @"active",
        @"link",
    ];
}

+ (NSArray *)orderArrayForFHIRPersonLinkComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"other",
        @"assurance",
    ];
}

+ (NSArray *)orderArrayForFHIRPharmacyClaim
{
    return @[
    
        @"id",
        @"meta",
        @"implicitRules",
        @"language",
        @"text",
        @"contained",
        @"extension",
        @"modifierExtension",
        @"identifier",
        @"ruleset",
        @"originalRuleset",
        @"created",
        @"target",
        @"provider",
        @"organization",
        @"use",
        @"priority",
        @"fundsReserve",
        @"enterer",
        @"facility",
        @"prescription",
        @"originalPrescription",
        @"payee",
        @"referral",
        @"diagnosis",
        @"condition",
        @"patient",
        @"coverage",
        @"exception",
        @"school",
        @"accident",
        @"accidentType",
        @"interventionException",
        @"item",
        @"additionalMaterials",
    ];
}

+ (NSArray *)orderArrayForFHIRItemsComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"sequence",
        @"type",
        @"provider",
        @"diagnosisLinkId",
        @"service",
        @"serviceDate",
        @"quantity",
        @"unitPrice",
        @"factor",
        @"points",
        @"net",
        @"udi",
        @"bodySite",
        @"subsite",
        @"modifier",
        @"detail",
    ];
}

+ (NSArray *)orderArrayForFHIRDetailComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"sequence",
        @"type",
        @"service",
        @"quantity",
        @"unitPrice",
        @"factor",
        @"points",
        @"net",
        @"udi",
        @"subDetail",
    ];
}

+ (NSArray *)orderArrayForFHIRCoverageComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"sequence",
        @"focal",
        @"coverage",
        @"businessArrangement",
        @"relationship",
        @"preauthref",
        @"claimResponse",
        @"originalRuleset",
    ];
}

+ (NSArray *)orderArrayForFHIRPayeeComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"type",
        @"provider",
        @"organization",
        @"person",
    ];
}

+ (NSArray *)orderArrayForFHIRDiagnosisComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"sequence",
        @"diagnosis",
    ];
}

+ (NSArray *)orderArrayForFHIRSubDetailComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"sequence",
        @"type",
        @"service",
        @"quantity",
        @"unitPrice",
        @"factor",
        @"points",
        @"net",
        @"udi",
    ];
}

+ (NSArray *)orderArrayForFHIRPractitioner
{
    return @[
    
        @"id",
        @"meta",
        @"implicitRules",
        @"language",
        @"text",
        @"contained",
        @"extension",
        @"modifierExtension",
        @"identifier",
        @"name",
        @"telecom",
        @"address",
        @"gender",
        @"birthDate",
        @"photo",
        @"organization",
        @"role",
        @"specialty",
        @"period",
        @"location",
        @"qualification",
        @"communication",
    ];
}

+ (NSArray *)orderArrayForFHIRPractitionerQualificationComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"identifier",
        @"code",
        @"period",
        @"issuer",
    ];
}

+ (NSArray *)orderArrayForFHIRProcedure
{
    return @[
    
        @"id",
        @"meta",
        @"implicitRules",
        @"language",
        @"text",
        @"contained",
        @"extension",
        @"modifierExtension",
        @"identifier",
        @"patient",
        @"type",
        @"bodySite",
        @"indication",
        @"performer",
        @"date",
        @"encounter",
        @"outcome",
        @"report",
        @"complication",
        @"followUp",
        @"relatedItem",
        @"notes",
    ];
}

+ (NSArray *)orderArrayForFHIRProcedureRelatedItemComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"type",
        @"target",
    ];
}

+ (NSArray *)orderArrayForFHIRProcedurePerformerComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"person",
        @"role",
    ];
}

+ (NSArray *)orderArrayForFHIRProcedureRequest
{
    return @[
    
        @"id",
        @"meta",
        @"implicitRules",
        @"language",
        @"text",
        @"contained",
        @"extension",
        @"modifierExtension",
        @"identifier",
        @"subject",
        @"type",
        @"bodySite",
        @"indication",
        @"timing",
        @"encounter",
        @"performer",
        @"status",
        @"notes",
        @"asNeeded",
        @"orderedOn",
        @"orderer",
        @"priority",
    ];
}

+ (NSArray *)orderArrayForFHIRProfessionalClaim
{
    return @[
    
        @"id",
        @"meta",
        @"implicitRules",
        @"language",
        @"text",
        @"contained",
        @"extension",
        @"modifierExtension",
        @"identifier",
        @"ruleset",
        @"originalRuleset",
        @"created",
        @"target",
        @"provider",
        @"organization",
        @"use",
        @"priority",
        @"fundsReserve",
        @"enterer",
        @"facility",
        @"payee",
        @"referral",
        @"diagnosis",
        @"condition",
        @"patient",
        @"coverage",
        @"exception",
        @"school",
        @"accident",
        @"accidentType",
        @"interventionException",
        @"item",
        @"additionalMaterials",
    ];
}

+ (NSArray *)orderArrayForFHIRItemsComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"sequence",
        @"type",
        @"provider",
        @"diagnosisLinkId",
        @"service",
        @"serviceDate",
        @"quantity",
        @"unitPrice",
        @"factor",
        @"points",
        @"net",
        @"udi",
        @"bodySite",
        @"subsite",
        @"modifier",
        @"detail",
    ];
}

+ (NSArray *)orderArrayForFHIRDetailComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"sequence",
        @"type",
        @"service",
        @"quantity",
        @"unitPrice",
        @"factor",
        @"points",
        @"net",
        @"udi",
        @"subDetail",
    ];
}

+ (NSArray *)orderArrayForFHIRCoverageComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"sequence",
        @"focal",
        @"coverage",
        @"businessArrangement",
        @"relationship",
        @"preauthref",
        @"claimResponse",
        @"originalRuleset",
    ];
}

+ (NSArray *)orderArrayForFHIRPayeeComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"type",
        @"provider",
        @"organization",
        @"person",
    ];
}

+ (NSArray *)orderArrayForFHIRDiagnosisComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"sequence",
        @"diagnosis",
    ];
}

+ (NSArray *)orderArrayForFHIRSubDetailComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"sequence",
        @"type",
        @"service",
        @"quantity",
        @"unitPrice",
        @"factor",
        @"points",
        @"net",
        @"udi",
    ];
}

+ (NSArray *)orderArrayForFHIRProfile
{
    return @[
    
        @"id",
        @"meta",
        @"implicitRules",
        @"language",
        @"text",
        @"contained",
        @"extension",
        @"modifierExtension",
        @"url",
        @"identifier",
        @"version",
        @"name",
        @"publisher",
        @"telecom",
        @"description",
        @"code",
        @"status",
        @"experimental",
        @"date",
        @"requirements",
        @"fhirVersion",
        @"mapping",
        @"type",
        @"base_",
        @"snapshot",
        @"differential",
    ];
}

+ (NSArray *)orderArrayForFHIRConstraintComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"element",
    ];
}

+ (NSArray *)orderArrayForFHIRProfileMappingComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"identity",
        @"uri",
        @"name",
        @"comments",
    ];
}

+ (NSArray *)orderArrayForFHIRProvenance
{
    return @[
    
        @"id",
        @"meta",
        @"implicitRules",
        @"language",
        @"text",
        @"contained",
        @"extension",
        @"modifierExtension",
        @"target",
        @"period",
        @"recorded",
        @"reason",
        @"location",
        @"policy",
        @"agent",
        @"entity",
        @"integritySignature",
    ];
}

+ (NSArray *)orderArrayForFHIRProvenanceAgentComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"role",
        @"type",
        @"reference",
        @"display",
    ];
}

+ (NSArray *)orderArrayForFHIRProvenanceEntityComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"role",
        @"type",
        @"reference",
        @"display",
        @"agent",
    ];
}

+ (NSArray *)orderArrayForFHIRQuestionnaire
{
    return @[
    
        @"id",
        @"meta",
        @"implicitRules",
        @"language",
        @"text",
        @"contained",
        @"extension",
        @"modifierExtension",
        @"identifier",
        @"version",
        @"status",
        @"date",
        @"publisher",
        @"group",
    ];
}

+ (NSArray *)orderArrayForFHIRQuestionComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"linkId",
        @"concept",
        @"text",
        @"type",
        @"required",
        @"repeats",
        @"options",
        @"group",
    ];
}

+ (NSArray *)orderArrayForFHIRGroupComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"linkId",
        @"title",
        @"concept",
        @"text",
        @"required",
        @"repeats",
        @"group",
        @"question",
    ];
}

+ (NSArray *)orderArrayForFHIRQuestionnaireAnswers
{
    return @[
    
        @"id",
        @"meta",
        @"implicitRules",
        @"language",
        @"text",
        @"contained",
        @"extension",
        @"modifierExtension",
        @"identifier",
        @"questionnaire",
        @"status",
        @"subject",
        @"author",
        @"authored",
        @"source",
        @"encounter",
        @"group",
    ];
}

+ (NSArray *)orderArrayForFHIRQuestionAnswerComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"value",
    ];
}

+ (NSArray *)orderArrayForFHIRQuestionComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"linkId",
        @"text",
        @"answer",
        @"group",
    ];
}

+ (NSArray *)orderArrayForFHIRGroupComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"linkId",
        @"title",
        @"text",
        @"subject",
        @"group",
        @"question",
    ];
}

+ (NSArray *)orderArrayForFHIRReadjudicate
{
    return @[
    
        @"id",
        @"meta",
        @"implicitRules",
        @"language",
        @"text",
        @"contained",
        @"extension",
        @"modifierExtension",
        @"identifier",
        @"ruleset",
        @"originalRuleset",
        @"created",
        @"target",
        @"provider",
        @"organization",
        @"request",
        @"response",
        @"reference",
        @"item",
    ];
}

+ (NSArray *)orderArrayForFHIRItemsComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"sequenceLinkId",
    ];
}

+ (NSArray *)orderArrayForFHIRReferralRequest
{
    return @[
    
        @"id",
        @"meta",
        @"implicitRules",
        @"language",
        @"text",
        @"contained",
        @"extension",
        @"modifierExtension",
        @"status",
        @"identifier",
        @"type",
        @"specialty",
        @"priority",
        @"patient",
        @"requester",
        @"recipient",
        @"encounter",
        @"dateSent",
        @"reason",
        @"description",
        @"serviceRequested",
        @"supportingInformation",
        @"fulfillmentTime",
    ];
}

+ (NSArray *)orderArrayForFHIRRelatedPerson
{
    return @[
    
        @"id",
        @"meta",
        @"implicitRules",
        @"language",
        @"text",
        @"contained",
        @"extension",
        @"modifierExtension",
        @"identifier",
        @"patient",
        @"relationship",
        @"name",
        @"telecom",
        @"gender",
        @"address",
        @"photo",
        @"period",
    ];
}

+ (NSArray *)orderArrayForFHIRReversal
{
    return @[
    
        @"id",
        @"meta",
        @"implicitRules",
        @"language",
        @"text",
        @"contained",
        @"extension",
        @"modifierExtension",
        @"identifier",
        @"ruleset",
        @"originalRuleset",
        @"created",
        @"target",
        @"provider",
        @"organization",
        @"request",
        @"response",
        @"payee",
        @"coverage",
        @"nullify",
    ];
}

+ (NSArray *)orderArrayForFHIRPayeeComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"type",
        @"provider",
        @"organization",
        @"person",
    ];
}

+ (NSArray *)orderArrayForFHIRReversalCoverageComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"sequence",
        @"focal",
        @"coverage",
        @"businessArrangement",
        @"relationship",
    ];
}

+ (NSArray *)orderArrayForFHIRRiskAssessment
{
    return @[
    
        @"id",
        @"meta",
        @"implicitRules",
        @"language",
        @"text",
        @"contained",
        @"extension",
        @"modifierExtension",
        @"subject",
        @"date",
        @"condition",
        @"performer",
        @"identifier",
        @"method",
        @"basis",
        @"prediction",
        @"mitigation",
    ];
}

+ (NSArray *)orderArrayForFHIRRiskAssessmentPredictionComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"outcome",
        @"probability",
        @"relativeRisk",
        @"when",
        @"rationale",
    ];
}

+ (NSArray *)orderArrayForFHIRSchedule
{
    return @[
    
        @"id",
        @"meta",
        @"implicitRules",
        @"language",
        @"text",
        @"contained",
        @"extension",
        @"modifierExtension",
        @"identifier",
        @"type",
        @"actor",
        @"planningHorizon",
        @"comment",
        @"lastModified",
    ];
}

+ (NSArray *)orderArrayForFHIRSearchParameter
{
    return @[
    
        @"id",
        @"meta",
        @"implicitRules",
        @"language",
        @"text",
        @"contained",
        @"extension",
        @"modifierExtension",
        @"url",
        @"name",
        @"publisher",
        @"telecom",
        @"requirements",
        @"base_",
        @"type",
        @"description",
        @"xpath",
        @"target",
    ];
}

+ (NSArray *)orderArrayForFHIRSecurityEvent
{
    return @[
    
        @"id",
        @"meta",
        @"implicitRules",
        @"language",
        @"text",
        @"contained",
        @"extension",
        @"modifierExtension",
        @"event_",
        @"participant",
        @"source",
        @"object_",
    ];
}

+ (NSArray *)orderArrayForFHIRSecurityEventObjectDetailComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"type",
        @"value",
    ];
}

+ (NSArray *)orderArrayForFHIRSecurityEventObjectComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"identifier",
        @"reference",
        @"type",
        @"role",
        @"lifecycle",
        @"sensitivity",
        @"name",
        @"description",
        @"query",
        @"detail",
    ];
}

+ (NSArray *)orderArrayForFHIRSecurityEventSourceComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"site",
        @"identifier",
        @"type",
    ];
}

+ (NSArray *)orderArrayForFHIRSecurityEventEventComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"type",
        @"subtype",
        @"action",
        @"dateTime",
        @"outcome",
        @"outcomeDesc",
    ];
}

+ (NSArray *)orderArrayForFHIRSecurityEventParticipantNetworkComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"identifier",
        @"type",
    ];
}

+ (NSArray *)orderArrayForFHIRSecurityEventParticipantComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"role",
        @"reference",
        @"userId",
        @"altId",
        @"name",
        @"requestor",
        @"media",
        @"network",
    ];
}

+ (NSArray *)orderArrayForFHIRSlot
{
    return @[
    
        @"id",
        @"meta",
        @"implicitRules",
        @"language",
        @"text",
        @"contained",
        @"extension",
        @"modifierExtension",
        @"identifier",
        @"type",
        @"schedule",
        @"freeBusyType",
        @"start",
        @"end",
        @"overbooked",
        @"comment",
        @"lastModified",
    ];
}

+ (NSArray *)orderArrayForFHIRSpecimen
{
    return @[
    
        @"id",
        @"meta",
        @"implicitRules",
        @"language",
        @"text",
        @"contained",
        @"extension",
        @"modifierExtension",
        @"identifier",
        @"type",
        @"source",
        @"subject",
        @"accessionIdentifier",
        @"receivedTime",
        @"collection",
        @"treatment",
        @"container",
    ];
}

+ (NSArray *)orderArrayForFHIRSpecimenCollectionComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"collector",
        @"comment",
        @"collected",
        @"quantity",
        @"method",
        @"sourceSite",
    ];
}

+ (NSArray *)orderArrayForFHIRSpecimenSourceComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"relationship",
        @"target",
    ];
}

+ (NSArray *)orderArrayForFHIRSpecimenTreatmentComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"description",
        @"procedure",
        @"additive",
    ];
}

+ (NSArray *)orderArrayForFHIRSpecimenContainerComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"identifier",
        @"description",
        @"type",
        @"capacity",
        @"specimenQuantity",
        @"additive",
    ];
}

+ (NSArray *)orderArrayForFHIRStatusRequest
{
    return @[
    
        @"id",
        @"meta",
        @"implicitRules",
        @"language",
        @"text",
        @"contained",
        @"extension",
        @"modifierExtension",
        @"identifier",
        @"ruleset",
        @"originalRuleset",
        @"created",
        @"target",
        @"provider",
        @"organization",
        @"request",
        @"response",
    ];
}

+ (NSArray *)orderArrayForFHIRStatusResponse
{
    return @[
    
        @"id",
        @"meta",
        @"implicitRules",
        @"language",
        @"text",
        @"contained",
        @"extension",
        @"modifierExtension",
        @"identifier",
        @"request",
        @"outcome",
        @"disposition",
        @"ruleset",
        @"originalRuleset",
        @"created",
        @"organization",
        @"requestProvider",
        @"requestOrganization",
        @"form",
        @"notes",
        @"error",
    ];
}

+ (NSArray *)orderArrayForFHIRStatusResponseNotesComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"type",
        @"text",
    ];
}

+ (NSArray *)orderArrayForFHIRSubscription
{
    return @[
    
        @"id",
        @"meta",
        @"implicitRules",
        @"language",
        @"text",
        @"contained",
        @"extension",
        @"modifierExtension",
        @"criteria",
        @"contact",
        @"reason",
        @"status",
        @"error",
        @"channel",
        @"end",
        @"tag",
    ];
}

+ (NSArray *)orderArrayForFHIRSubscriptionChannelComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"type",
        @"url",
        @"payload",
        @"header",
    ];
}

+ (NSArray *)orderArrayForFHIRSubscriptionTagComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"term",
        @"scheme",
        @"description",
    ];
}

+ (NSArray *)orderArrayForFHIRSubstance
{
    return @[
    
        @"id",
        @"meta",
        @"implicitRules",
        @"language",
        @"text",
        @"contained",
        @"extension",
        @"modifierExtension",
        @"type",
        @"description",
        @"instance",
        @"ingredient",
    ];
}

+ (NSArray *)orderArrayForFHIRSubstanceIngredientComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"quantity",
        @"substance",
    ];
}

+ (NSArray *)orderArrayForFHIRSubstanceInstanceComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"identifier",
        @"expiry",
        @"quantity",
    ];
}

+ (NSArray *)orderArrayForFHIRSupply
{
    return @[
    
        @"id",
        @"meta",
        @"implicitRules",
        @"language",
        @"text",
        @"contained",
        @"extension",
        @"modifierExtension",
        @"kind",
        @"identifier",
        @"status",
        @"orderedItem",
        @"patient",
        @"dispense",
    ];
}

+ (NSArray *)orderArrayForFHIRSupplyDispenseComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"identifier",
        @"status",
        @"type",
        @"quantity",
        @"suppliedItem",
        @"supplier",
        @"whenPrepared",
        @"whenHandedOver",
        @"destination",
        @"receiver",
    ];
}

+ (NSArray *)orderArrayForFHIRSupportingDocumentation
{
    return @[
    
        @"id",
        @"meta",
        @"implicitRules",
        @"language",
        @"text",
        @"contained",
        @"extension",
        @"modifierExtension",
        @"identifier",
        @"ruleset",
        @"originalRuleset",
        @"created",
        @"target",
        @"provider",
        @"organization",
        @"request",
        @"response",
        @"author",
        @"subject",
        @"detail",
    ];
}

+ (NSArray *)orderArrayForFHIRSupportingDocumentationDetailComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"linkId",
        @"content",
        @"dateTime",
    ];
}

+ (NSArray *)orderArrayForFHIRValueSet
{
    return @[
    
        @"id",
        @"meta",
        @"implicitRules",
        @"language",
        @"text",
        @"contained",
        @"extension",
        @"modifierExtension",
        @"identifier",
        @"version",
        @"name",
        @"purpose",
        @"immutable",
        @"publisher",
        @"telecom",
        @"description",
        @"copyright",
        @"status",
        @"experimental",
        @"extensible",
        @"date",
        @"stableDate",
        @"define",
        @"compose",
        @"expansion",
    ];
}

+ (NSArray *)orderArrayForFHIRValueSetDefineComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"system",
        @"version",
        @"caseSensitive",
        @"concept",
    ];
}

+ (NSArray *)orderArrayForFHIRValueSetExpansionContainsComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"system",
        @"abstract_",
        @"version",
        @"code",
        @"display",
        @"contains",
    ];
}

+ (NSArray *)orderArrayForFHIRConceptDefinitionDesignationComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"language",
        @"use",
        @"value",
    ];
}

+ (NSArray *)orderArrayForFHIRConceptDefinitionComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"code",
        @"abstract_",
        @"display",
        @"definition",
        @"designation",
        @"concept",
    ];
}

+ (NSArray *)orderArrayForFHIRConceptSetComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"system",
        @"version",
        @"concept",
        @"filter",
    ];
}

+ (NSArray *)orderArrayForFHIRConceptReferenceComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"code",
        @"display",
        @"designation",
    ];
}

+ (NSArray *)orderArrayForFHIRConceptSetFilterComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"property",
        @"op",
        @"value",
    ];
}

+ (NSArray *)orderArrayForFHIRValueSetComposeComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"import",
        @"include",
        @"exclude",
    ];
}

+ (NSArray *)orderArrayForFHIRValueSetExpansionComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"identifier",
        @"timestamp",
        @"contains",
    ];
}

+ (NSArray *)orderArrayForFHIRVisionClaim
{
    return @[
    
        @"id",
        @"meta",
        @"implicitRules",
        @"language",
        @"text",
        @"contained",
        @"extension",
        @"modifierExtension",
        @"identifier",
        @"ruleset",
        @"originalRuleset",
        @"created",
        @"target",
        @"provider",
        @"organization",
        @"use",
        @"priority",
        @"fundsReserve",
        @"enterer",
        @"facility",
        @"prescription",
        @"payee",
        @"referral",
        @"diagnosis",
        @"condition",
        @"patient",
        @"coverage",
        @"exception",
        @"school",
        @"accident",
        @"accidentType",
        @"interventionException",
        @"item",
        @"additionalMaterials",
    ];
}

+ (NSArray *)orderArrayForFHIRItemsComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"sequence",
        @"type",
        @"provider",
        @"diagnosisLinkId",
        @"service",
        @"serviceDate",
        @"quantity",
        @"unitPrice",
        @"factor",
        @"points",
        @"net",
        @"udi",
        @"bodySite",
        @"subsite",
        @"modifier",
        @"detail",
    ];
}

+ (NSArray *)orderArrayForFHIRDetailComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"sequence",
        @"type",
        @"service",
        @"quantity",
        @"unitPrice",
        @"factor",
        @"points",
        @"net",
        @"udi",
        @"subDetail",
    ];
}

+ (NSArray *)orderArrayForFHIRCoverageComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"sequence",
        @"focal",
        @"coverage",
        @"businessArrangement",
        @"relationship",
        @"preauthref",
        @"claimResponse",
        @"originalRuleset",
    ];
}

+ (NSArray *)orderArrayForFHIRPayeeComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"type",
        @"provider",
        @"organization",
        @"person",
    ];
}

+ (NSArray *)orderArrayForFHIRDiagnosisComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"sequence",
        @"diagnosis",
    ];
}

+ (NSArray *)orderArrayForFHIRSubDetailComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"sequence",
        @"type",
        @"service",
        @"quantity",
        @"unitPrice",
        @"factor",
        @"points",
        @"net",
        @"udi",
    ];
}

+ (NSArray *)orderArrayForFHIRVisionPrescription
{
    return @[
    
        @"id",
        @"meta",
        @"implicitRules",
        @"language",
        @"text",
        @"contained",
        @"extension",
        @"modifierExtension",
        @"identifier",
        @"dateWritten",
        @"patient",
        @"prescriber",
        @"encounter",
        @"reason",
        @"dispense",
    ];
}

+ (NSArray *)orderArrayForFHIRVisionPrescriptionDispenseComponent
{
    return @[
    
        @"id",
        @"extension",
        @"modifierExtension",
        @"product",
        @"eye",
        @"sphere",
        @"cylinder",
        @"axis",
        @"prism",
        @"base_",
        @"add",
        @"power",
        @"backCurve",
        @"diameter",
        @"duration",
        @"color",
        @"brand",
        @"notes",
    ];
}


+ (NSArray *)orderArrayForType:(NSString *)className
{
    if([className isEqualToString:@"FHIRAddress"])
    {
        return [self orderArrayForFHIRAddress];
    }
    else if([className isEqualToString:@"FHIRAttachment"])
    {
        return [self orderArrayForFHIRAttachment];
    }
    else if([className isEqualToString:@"FHIRBackboneElement"])
    {
        return [self orderArrayForFHIRBackboneElement];
    }
    else if([className isEqualToString:@"FHIRCodeableConcept"])
    {
        return [self orderArrayForFHIRCodeableConcept];
    }
    else if([className isEqualToString:@"FHIRCoding"])
    {
        return [self orderArrayForFHIRCoding];
    }
    else if([className isEqualToString:@"FHIRContactPoint"])
    {
        return [self orderArrayForFHIRContactPoint];
    }
    else if([className isEqualToString:@"FHIRElement"])
    {
        return [self orderArrayForFHIRElement];
    }
    else if([className isEqualToString:@"FHIRElementDefinition"])
    {
        return [self orderArrayForFHIRElementDefinition];
    }
    else if([className isEqualToString:@"FHIRElementDefinitionSlicingComponent"])
    {
        return [self orderArrayForFHIRElementDefinitionSlicingComponent];
    }
    else if([className isEqualToString:@"FHIRTypeRefComponent"])
    {
        return [self orderArrayForFHIRTypeRefComponent];
    }
    else if([className isEqualToString:@"FHIRElementDefinitionMappingComponent"])
    {
        return [self orderArrayForFHIRElementDefinitionMappingComponent];
    }
    else if([className isEqualToString:@"FHIRElementDefinitionBindingComponent"])
    {
        return [self orderArrayForFHIRElementDefinitionBindingComponent];
    }
    else if([className isEqualToString:@"FHIRElementDefinitionConstraintComponent"])
    {
        return [self orderArrayForFHIRElementDefinitionConstraintComponent];
    }
    else if([className isEqualToString:@"FHIRExtension"])
    {
        return [self orderArrayForFHIRExtension];
    }
    else if([className isEqualToString:@"FHIRHumanName"])
    {
        return [self orderArrayForFHIRHumanName];
    }
    else if([className isEqualToString:@"FHIRIdentifier"])
    {
        return [self orderArrayForFHIRIdentifier];
    }
    else if([className isEqualToString:@"FHIRNarrative"])
    {
        return [self orderArrayForFHIRNarrative];
    }
    else if([className isEqualToString:@"FHIRPeriod"])
    {
        return [self orderArrayForFHIRPeriod];
    }
    else if([className isEqualToString:@"FHIRQuantity"])
    {
        return [self orderArrayForFHIRQuantity];
    }
    else if([className isEqualToString:@"FHIRRange"])
    {
        return [self orderArrayForFHIRRange];
    }
    else if([className isEqualToString:@"FHIRRatio"])
    {
        return [self orderArrayForFHIRRatio];
    }
    else if([className isEqualToString:@"FHIRReference"])
    {
        return [self orderArrayForFHIRReference];
    }
    else if([className isEqualToString:@"FHIRSampledData"])
    {
        return [self orderArrayForFHIRSampledData];
    }
    else if([className isEqualToString:@"FHIRTiming"])
    {
        return [self orderArrayForFHIRTiming];
    }
    else if([className isEqualToString:@"FHIRTimingRepeatComponent"])
    {
        return [self orderArrayForFHIRTimingRepeatComponent];
    }
    else if([className isEqualToString:@"FHIRBase64Binary"])
    {
        return [self orderArrayForFHIRBase64Binary];
    }
    else if([className isEqualToString:@"FHIRBoolean"])
    {
        return [self orderArrayForFHIRBoolean];
    }
    else if([className isEqualToString:@"FHIRCode"])
    {
        return [self orderArrayForFHIRCode];
    }
    else if([className isEqualToString:@"FHIRDate"])
    {
        return [self orderArrayForFHIRDate];
    }
    else if([className isEqualToString:@"FHIRDateTime"])
    {
        return [self orderArrayForFHIRDateTime];
    }
    else if([className isEqualToString:@"FHIRDecimal"])
    {
        return [self orderArrayForFHIRDecimal];
    }
    else if([className isEqualToString:@"FHIRId"])
    {
        return [self orderArrayForFHIRId];
    }
    else if([className isEqualToString:@"FHIRInstant"])
    {
        return [self orderArrayForFHIRInstant];
    }
    else if([className isEqualToString:@"FHIRInteger"])
    {
        return [self orderArrayForFHIRInteger];
    }
    else if([className isEqualToString:@"FHIROid"])
    {
        return [self orderArrayForFHIROid];
    }
    else if([className isEqualToString:@"FHIRString"])
    {
        return [self orderArrayForFHIRString];
    }
    else if([className isEqualToString:@"FHIRTime"])
    {
        return [self orderArrayForFHIRTime];
    }
    else if([className isEqualToString:@"FHIRUri"])
    {
        return [self orderArrayForFHIRUri];
    }
    else if([className isEqualToString:@"FHIRUuid"])
    {
        return [self orderArrayForFHIRUuid];
    }
    else if([className isEqualToString:@"FHIRXhtml"])
    {
        return [self orderArrayForFHIRXhtml];
    }
    else if([className isEqualToString:@"FHIRDomainResource"])
    {
        return [self orderArrayForFHIRDomainResource];
    }
    else if([className isEqualToString:@"FHIRParameters"])
    {
        return [self orderArrayForFHIRParameters];
    }
    else if([className isEqualToString:@"FHIRParametersParameterComponent"])
    {
        return [self orderArrayForFHIRParametersParameterComponent];
    }
    else if([className isEqualToString:@"FHIRParametersParameterPartComponent"])
    {
        return [self orderArrayForFHIRParametersParameterPartComponent];
    }
    else if([className isEqualToString:@"FHIRBaseResource"])
    {
        return [self orderArrayForFHIRBaseResource];
    }
    else if([className isEqualToString:@"FHIRResourceMetaComponent"])
    {
        return [self orderArrayForFHIRResourceMetaComponent];
    }
    else if([className isEqualToString:@"FHIRAlert"])
    {
        return [self orderArrayForFHIRAlert];
    }
    else if([className isEqualToString:@"FHIRAllergyIntolerance"])
    {
        return [self orderArrayForFHIRAllergyIntolerance];
    }
    else if([className isEqualToString:@"FHIRAllergyIntoleranceEventComponent"])
    {
        return [self orderArrayForFHIRAllergyIntoleranceEventComponent];
    }
    else if([className isEqualToString:@"FHIRAppointment"])
    {
        return [self orderArrayForFHIRAppointment];
    }
    else if([className isEqualToString:@"FHIRAppointmentParticipantComponent"])
    {
        return [self orderArrayForFHIRAppointmentParticipantComponent];
    }
    else if([className isEqualToString:@"FHIRAppointmentResponse"])
    {
        return [self orderArrayForFHIRAppointmentResponse];
    }
    else if([className isEqualToString:@"FHIRBasic"])
    {
        return [self orderArrayForFHIRBasic];
    }
    else if([className isEqualToString:@"FHIRBinary"])
    {
        return [self orderArrayForFHIRBinary];
    }
    else if([className isEqualToString:@"FHIRBundle"])
    {
        return [self orderArrayForFHIRBundle];
    }
    else if([className isEqualToString:@"FHIRBundleEntryDeletedComponent"])
    {
        return [self orderArrayForFHIRBundleEntryDeletedComponent];
    }
    else if([className isEqualToString:@"FHIRBundleEntryComponent"])
    {
        return [self orderArrayForFHIRBundleEntryComponent];
    }
    else if([className isEqualToString:@"FHIRBundleLinkComponent"])
    {
        return [self orderArrayForFHIRBundleLinkComponent];
    }
    else if([className isEqualToString:@"FHIRCarePlan"])
    {
        return [self orderArrayForFHIRCarePlan];
    }
    else if([className isEqualToString:@"FHIRCarePlanGoalComponent"])
    {
        return [self orderArrayForFHIRCarePlanGoalComponent];
    }
    else if([className isEqualToString:@"FHIRCarePlanParticipantComponent"])
    {
        return [self orderArrayForFHIRCarePlanParticipantComponent];
    }
    else if([className isEqualToString:@"FHIRCarePlanActivityComponent"])
    {
        return [self orderArrayForFHIRCarePlanActivityComponent];
    }
    else if([className isEqualToString:@"FHIRCarePlanActivitySimpleComponent"])
    {
        return [self orderArrayForFHIRCarePlanActivitySimpleComponent];
    }
    else if([className isEqualToString:@"FHIRCarePlan2"])
    {
        return [self orderArrayForFHIRCarePlan2];
    }
    else if([className isEqualToString:@"FHIRCarePlan2ParticipantComponent"])
    {
        return [self orderArrayForFHIRCarePlan2ParticipantComponent];
    }
    else if([className isEqualToString:@"FHIRClaimResponse"])
    {
        return [self orderArrayForFHIRClaimResponse];
    }
    else if([className isEqualToString:@"FHIRNotesComponent"])
    {
        return [self orderArrayForFHIRNotesComponent];
    }
    else if([className isEqualToString:@"FHIRItemsComponent"])
    {
        return [self orderArrayForFHIRItemsComponent];
    }
    else if([className isEqualToString:@"FHIRItemSubdetailComponent"])
    {
        return [self orderArrayForFHIRItemSubdetailComponent];
    }
    else if([className isEqualToString:@"FHIRAddedItemDetailAdjudicationComponent"])
    {
        return [self orderArrayForFHIRAddedItemDetailAdjudicationComponent];
    }
    else if([className isEqualToString:@"FHIRAddedItemAdjudicationComponent"])
    {
        return [self orderArrayForFHIRAddedItemAdjudicationComponent];
    }
    else if([className isEqualToString:@"FHIRDetailAdjudicationComponent"])
    {
        return [self orderArrayForFHIRDetailAdjudicationComponent];
    }
    else if([className isEqualToString:@"FHIRErrorsComponent"])
    {
        return [self orderArrayForFHIRErrorsComponent];
    }
    else if([className isEqualToString:@"FHIRAddedItemComponent"])
    {
        return [self orderArrayForFHIRAddedItemComponent];
    }
    else if([className isEqualToString:@"FHIRItemAdjudicationComponent"])
    {
        return [self orderArrayForFHIRItemAdjudicationComponent];
    }
    else if([className isEqualToString:@"FHIRAddedItemsDetailComponent"])
    {
        return [self orderArrayForFHIRAddedItemsDetailComponent];
    }
    else if([className isEqualToString:@"FHIRSubdetailAdjudicationComponent"])
    {
        return [self orderArrayForFHIRSubdetailAdjudicationComponent];
    }
    else if([className isEqualToString:@"FHIRItemDetailComponent"])
    {
        return [self orderArrayForFHIRItemDetailComponent];
    }
    else if([className isEqualToString:@"FHIRClinicalAssessment"])
    {
        return [self orderArrayForFHIRClinicalAssessment];
    }
    else if([className isEqualToString:@"FHIRClinicalAssessmentRuledOutComponent"])
    {
        return [self orderArrayForFHIRClinicalAssessmentRuledOutComponent];
    }
    else if([className isEqualToString:@"FHIRClinicalAssessmentInvestigationsComponent"])
    {
        return [self orderArrayForFHIRClinicalAssessmentInvestigationsComponent];
    }
    else if([className isEqualToString:@"FHIRClinicalAssessmentDiagnosisComponent"])
    {
        return [self orderArrayForFHIRClinicalAssessmentDiagnosisComponent];
    }
    else if([className isEqualToString:@"FHIRCommunication"])
    {
        return [self orderArrayForFHIRCommunication];
    }
    else if([className isEqualToString:@"FHIRCommunicationPayloadComponent"])
    {
        return [self orderArrayForFHIRCommunicationPayloadComponent];
    }
    else if([className isEqualToString:@"FHIRCommunicationRequest"])
    {
        return [self orderArrayForFHIRCommunicationRequest];
    }
    else if([className isEqualToString:@"FHIRCommunicationRequestPayloadComponent"])
    {
        return [self orderArrayForFHIRCommunicationRequestPayloadComponent];
    }
    else if([className isEqualToString:@"FHIRComposition"])
    {
        return [self orderArrayForFHIRComposition];
    }
    else if([className isEqualToString:@"FHIRSectionComponent"])
    {
        return [self orderArrayForFHIRSectionComponent];
    }
    else if([className isEqualToString:@"FHIRCompositionEventComponent"])
    {
        return [self orderArrayForFHIRCompositionEventComponent];
    }
    else if([className isEqualToString:@"FHIRCompositionAttesterComponent"])
    {
        return [self orderArrayForFHIRCompositionAttesterComponent];
    }
    else if([className isEqualToString:@"FHIRConceptMap"])
    {
        return [self orderArrayForFHIRConceptMap];
    }
    else if([className isEqualToString:@"FHIRConceptMapElementComponent"])
    {
        return [self orderArrayForFHIRConceptMapElementComponent];
    }
    else if([className isEqualToString:@"FHIRConceptMapElementMapComponent"])
    {
        return [self orderArrayForFHIRConceptMapElementMapComponent];
    }
    else if([className isEqualToString:@"FHIROtherElementComponent"])
    {
        return [self orderArrayForFHIROtherElementComponent];
    }
    else if([className isEqualToString:@"FHIRCondition"])
    {
        return [self orderArrayForFHIRCondition];
    }
    else if([className isEqualToString:@"FHIRConditionEvidenceComponent"])
    {
        return [self orderArrayForFHIRConditionEvidenceComponent];
    }
    else if([className isEqualToString:@"FHIRConditionDueToComponent"])
    {
        return [self orderArrayForFHIRConditionDueToComponent];
    }
    else if([className isEqualToString:@"FHIRConditionOccurredFollowingComponent"])
    {
        return [self orderArrayForFHIRConditionOccurredFollowingComponent];
    }
    else if([className isEqualToString:@"FHIRConditionStageComponent"])
    {
        return [self orderArrayForFHIRConditionStageComponent];
    }
    else if([className isEqualToString:@"FHIRConditionLocationComponent"])
    {
        return [self orderArrayForFHIRConditionLocationComponent];
    }
    else if([className isEqualToString:@"FHIRConformance"])
    {
        return [self orderArrayForFHIRConformance];
    }
    else if([className isEqualToString:@"FHIRConformanceRestComponent"])
    {
        return [self orderArrayForFHIRConformanceRestComponent];
    }
    else if([className isEqualToString:@"FHIRConformanceSoftwareComponent"])
    {
        return [self orderArrayForFHIRConformanceSoftwareComponent];
    }
    else if([className isEqualToString:@"FHIRConformanceMessagingComponent"])
    {
        return [self orderArrayForFHIRConformanceMessagingComponent];
    }
    else if([className isEqualToString:@"FHIRConformanceDocumentComponent"])
    {
        return [self orderArrayForFHIRConformanceDocumentComponent];
    }
    else if([className isEqualToString:@"FHIRConformanceRestResourceComponent"])
    {
        return [self orderArrayForFHIRConformanceRestResourceComponent];
    }
    else if([className isEqualToString:@"FHIRConformanceImplementationComponent"])
    {
        return [self orderArrayForFHIRConformanceImplementationComponent];
    }
    else if([className isEqualToString:@"FHIRConformanceMessagingEventComponent"])
    {
        return [self orderArrayForFHIRConformanceMessagingEventComponent];
    }
    else if([className isEqualToString:@"FHIRSystemInteractionComponent"])
    {
        return [self orderArrayForFHIRSystemInteractionComponent];
    }
    else if([className isEqualToString:@"FHIRResourceInteractionComponent"])
    {
        return [self orderArrayForFHIRResourceInteractionComponent];
    }
    else if([className isEqualToString:@"FHIRConformanceRestSecurityComponent"])
    {
        return [self orderArrayForFHIRConformanceRestSecurityComponent];
    }
    else if([className isEqualToString:@"FHIRConformanceRestSecurityCertificateComponent"])
    {
        return [self orderArrayForFHIRConformanceRestSecurityCertificateComponent];
    }
    else if([className isEqualToString:@"FHIRConformanceRestOperationComponent"])
    {
        return [self orderArrayForFHIRConformanceRestOperationComponent];
    }
    else if([className isEqualToString:@"FHIRConformanceRestResourceSearchParamComponent"])
    {
        return [self orderArrayForFHIRConformanceRestResourceSearchParamComponent];
    }
    else if([className isEqualToString:@"FHIRContract"])
    {
        return [self orderArrayForFHIRContract];
    }
    else if([className isEqualToString:@"FHIRContractSignerComponent"])
    {
        return [self orderArrayForFHIRContractSignerComponent];
    }
    else if([className isEqualToString:@"FHIRContractTermComponent"])
    {
        return [self orderArrayForFHIRContractTermComponent];
    }
    else if([className isEqualToString:@"FHIRContraindication"])
    {
        return [self orderArrayForFHIRContraindication];
    }
    else if([className isEqualToString:@"FHIRContraindicationMitigationComponent"])
    {
        return [self orderArrayForFHIRContraindicationMitigationComponent];
    }
    else if([className isEqualToString:@"FHIRCoverage"])
    {
        return [self orderArrayForFHIRCoverage];
    }
    else if([className isEqualToString:@"FHIRDataElement"])
    {
        return [self orderArrayForFHIRDataElement];
    }
    else if([className isEqualToString:@"FHIRDataElementMappingComponent"])
    {
        return [self orderArrayForFHIRDataElementMappingComponent];
    }
    else if([className isEqualToString:@"FHIRDataElementBindingComponent"])
    {
        return [self orderArrayForFHIRDataElementBindingComponent];
    }
    else if([className isEqualToString:@"FHIRDevice"])
    {
        return [self orderArrayForFHIRDevice];
    }
    else if([className isEqualToString:@"FHIRDeviceComponent"])
    {
        return [self orderArrayForFHIRDeviceComponent];
    }
    else if([className isEqualToString:@"FHIRDeviceComponentProductionSpecificationComponent"])
    {
        return [self orderArrayForFHIRDeviceComponentProductionSpecificationComponent];
    }
    else if([className isEqualToString:@"FHIRDeviceMetric"])
    {
        return [self orderArrayForFHIRDeviceMetric];
    }
    else if([className isEqualToString:@"FHIRDeviceMetricCalibrationInfoComponent"])
    {
        return [self orderArrayForFHIRDeviceMetricCalibrationInfoComponent];
    }
    else if([className isEqualToString:@"FHIRDeviceUseRequest"])
    {
        return [self orderArrayForFHIRDeviceUseRequest];
    }
    else if([className isEqualToString:@"FHIRDeviceUseStatement"])
    {
        return [self orderArrayForFHIRDeviceUseStatement];
    }
    else if([className isEqualToString:@"FHIRDiagnosticOrder"])
    {
        return [self orderArrayForFHIRDiagnosticOrder];
    }
    else if([className isEqualToString:@"FHIRDiagnosticOrderItemComponent"])
    {
        return [self orderArrayForFHIRDiagnosticOrderItemComponent];
    }
    else if([className isEqualToString:@"FHIRDiagnosticOrderEventComponent"])
    {
        return [self orderArrayForFHIRDiagnosticOrderEventComponent];
    }
    else if([className isEqualToString:@"FHIRDiagnosticReport"])
    {
        return [self orderArrayForFHIRDiagnosticReport];
    }
    else if([className isEqualToString:@"FHIRDiagnosticReportImageComponent"])
    {
        return [self orderArrayForFHIRDiagnosticReportImageComponent];
    }
    else if([className isEqualToString:@"FHIRDocumentManifest"])
    {
        return [self orderArrayForFHIRDocumentManifest];
    }
    else if([className isEqualToString:@"FHIRDocumentReference"])
    {
        return [self orderArrayForFHIRDocumentReference];
    }
    else if([className isEqualToString:@"FHIRDocumentReferenceContextComponent"])
    {
        return [self orderArrayForFHIRDocumentReferenceContextComponent];
    }
    else if([className isEqualToString:@"FHIRDocumentReferenceRelatesToComponent"])
    {
        return [self orderArrayForFHIRDocumentReferenceRelatesToComponent];
    }
    else if([className isEqualToString:@"FHIRDocumentReferenceServiceParameterComponent"])
    {
        return [self orderArrayForFHIRDocumentReferenceServiceParameterComponent];
    }
    else if([className isEqualToString:@"FHIRDocumentReferenceServiceComponent"])
    {
        return [self orderArrayForFHIRDocumentReferenceServiceComponent];
    }
    else if([className isEqualToString:@"FHIREligibilityRequest"])
    {
        return [self orderArrayForFHIREligibilityRequest];
    }
    else if([className isEqualToString:@"FHIREligibilityResponse"])
    {
        return [self orderArrayForFHIREligibilityResponse];
    }
    else if([className isEqualToString:@"FHIREncounter"])
    {
        return [self orderArrayForFHIREncounter];
    }
    else if([className isEqualToString:@"FHIREncounterHospitalizationComponent"])
    {
        return [self orderArrayForFHIREncounterHospitalizationComponent];
    }
    else if([className isEqualToString:@"FHIREncounterStatusHistoryComponent"])
    {
        return [self orderArrayForFHIREncounterStatusHistoryComponent];
    }
    else if([className isEqualToString:@"FHIREncounterLocationComponent"])
    {
        return [self orderArrayForFHIREncounterLocationComponent];
    }
    else if([className isEqualToString:@"FHIREncounterParticipantComponent"])
    {
        return [self orderArrayForFHIREncounterParticipantComponent];
    }
    else if([className isEqualToString:@"FHIREnrollmentRequest"])
    {
        return [self orderArrayForFHIREnrollmentRequest];
    }
    else if([className isEqualToString:@"FHIREnrollmentResponse"])
    {
        return [self orderArrayForFHIREnrollmentResponse];
    }
    else if([className isEqualToString:@"FHIREpisodeOfCare"])
    {
        return [self orderArrayForFHIREpisodeOfCare];
    }
    else if([className isEqualToString:@"FHIREpisodeOfCareStatusHistoryComponent"])
    {
        return [self orderArrayForFHIREpisodeOfCareStatusHistoryComponent];
    }
    else if([className isEqualToString:@"FHIREpisodeOfCareCareTeamComponent"])
    {
        return [self orderArrayForFHIREpisodeOfCareCareTeamComponent];
    }
    else if([className isEqualToString:@"FHIRExplanationOfBenefit"])
    {
        return [self orderArrayForFHIRExplanationOfBenefit];
    }
    else if([className isEqualToString:@"FHIRExtensionDefinition"])
    {
        return [self orderArrayForFHIRExtensionDefinition];
    }
    else if([className isEqualToString:@"FHIRExtensionDefinitionMappingComponent"])
    {
        return [self orderArrayForFHIRExtensionDefinitionMappingComponent];
    }
    else if([className isEqualToString:@"FHIRFamilyHistory"])
    {
        return [self orderArrayForFHIRFamilyHistory];
    }
    else if([className isEqualToString:@"FHIRFamilyHistoryRelationConditionComponent"])
    {
        return [self orderArrayForFHIRFamilyHistoryRelationConditionComponent];
    }
    else if([className isEqualToString:@"FHIRFamilyHistoryRelationComponent"])
    {
        return [self orderArrayForFHIRFamilyHistoryRelationComponent];
    }
    else if([className isEqualToString:@"FHIRGoal"])
    {
        return [self orderArrayForFHIRGoal];
    }
    else if([className isEqualToString:@"FHIRGroup"])
    {
        return [self orderArrayForFHIRGroup];
    }
    else if([className isEqualToString:@"FHIRGroupCharacteristicComponent"])
    {
        return [self orderArrayForFHIRGroupCharacteristicComponent];
    }
    else if([className isEqualToString:@"FHIRHealthcareService"])
    {
        return [self orderArrayForFHIRHealthcareService];
    }
    else if([className isEqualToString:@"FHIRServiceTypeComponent"])
    {
        return [self orderArrayForFHIRServiceTypeComponent];
    }
    else if([className isEqualToString:@"FHIRHealthcareServiceAvailableTimeComponent"])
    {
        return [self orderArrayForFHIRHealthcareServiceAvailableTimeComponent];
    }
    else if([className isEqualToString:@"FHIRHealthcareServiceNotAvailableTimeComponent"])
    {
        return [self orderArrayForFHIRHealthcareServiceNotAvailableTimeComponent];
    }
    else if([className isEqualToString:@"FHIRImagingObjectSelection"])
    {
        return [self orderArrayForFHIRImagingObjectSelection];
    }
    else if([className isEqualToString:@"FHIRStudyComponent"])
    {
        return [self orderArrayForFHIRStudyComponent];
    }
    else if([className isEqualToString:@"FHIRInstanceComponent"])
    {
        return [self orderArrayForFHIRInstanceComponent];
    }
    else if([className isEqualToString:@"FHIRSeriesComponent"])
    {
        return [self orderArrayForFHIRSeriesComponent];
    }
    else if([className isEqualToString:@"FHIRImagingStudy"])
    {
        return [self orderArrayForFHIRImagingStudy];
    }
    else if([className isEqualToString:@"FHIRImagingStudySeriesComponent"])
    {
        return [self orderArrayForFHIRImagingStudySeriesComponent];
    }
    else if([className isEqualToString:@"FHIRImagingStudySeriesInstanceComponent"])
    {
        return [self orderArrayForFHIRImagingStudySeriesInstanceComponent];
    }
    else if([className isEqualToString:@"FHIRImmunization"])
    {
        return [self orderArrayForFHIRImmunization];
    }
    else if([className isEqualToString:@"FHIRImmunizationVaccinationProtocolComponent"])
    {
        return [self orderArrayForFHIRImmunizationVaccinationProtocolComponent];
    }
    else if([className isEqualToString:@"FHIRImmunizationExplanationComponent"])
    {
        return [self orderArrayForFHIRImmunizationExplanationComponent];
    }
    else if([className isEqualToString:@"FHIRImmunizationReactionComponent"])
    {
        return [self orderArrayForFHIRImmunizationReactionComponent];
    }
    else if([className isEqualToString:@"FHIRImmunizationRecommendation"])
    {
        return [self orderArrayForFHIRImmunizationRecommendation];
    }
    else if([className isEqualToString:@"FHIRImmunizationRecommendationRecommendationDateCriterionComponent"])
    {
        return [self orderArrayForFHIRImmunizationRecommendationRecommendationDateCriterionComponent];
    }
    else if([className isEqualToString:@"FHIRImmunizationRecommendationRecommendationProtocolComponent"])
    {
        return [self orderArrayForFHIRImmunizationRecommendationRecommendationProtocolComponent];
    }
    else if([className isEqualToString:@"FHIRImmunizationRecommendationRecommendationComponent"])
    {
        return [self orderArrayForFHIRImmunizationRecommendationRecommendationComponent];
    }
    else if([className isEqualToString:@"FHIRInstitutionalClaim"])
    {
        return [self orderArrayForFHIRInstitutionalClaim];
    }
    else if([className isEqualToString:@"FHIRItemsComponent"])
    {
        return [self orderArrayForFHIRItemsComponent];
    }
    else if([className isEqualToString:@"FHIRDetailComponent"])
    {
        return [self orderArrayForFHIRDetailComponent];
    }
    else if([className isEqualToString:@"FHIRCoverageComponent"])
    {
        return [self orderArrayForFHIRCoverageComponent];
    }
    else if([className isEqualToString:@"FHIRPayeeComponent"])
    {
        return [self orderArrayForFHIRPayeeComponent];
    }
    else if([className isEqualToString:@"FHIRDiagnosisComponent"])
    {
        return [self orderArrayForFHIRDiagnosisComponent];
    }
    else if([className isEqualToString:@"FHIRSubDetailComponent"])
    {
        return [self orderArrayForFHIRSubDetailComponent];
    }
    else if([className isEqualToString:@"FHIRList"])
    {
        return [self orderArrayForFHIRList];
    }
    else if([className isEqualToString:@"FHIRListEntryComponent"])
    {
        return [self orderArrayForFHIRListEntryComponent];
    }
    else if([className isEqualToString:@"FHIRLocation"])
    {
        return [self orderArrayForFHIRLocation];
    }
    else if([className isEqualToString:@"FHIRLocationPositionComponent"])
    {
        return [self orderArrayForFHIRLocationPositionComponent];
    }
    else if([className isEqualToString:@"FHIRMedia"])
    {
        return [self orderArrayForFHIRMedia];
    }
    else if([className isEqualToString:@"FHIRMedication"])
    {
        return [self orderArrayForFHIRMedication];
    }
    else if([className isEqualToString:@"FHIRMedicationPackageContentComponent"])
    {
        return [self orderArrayForFHIRMedicationPackageContentComponent];
    }
    else if([className isEqualToString:@"FHIRMedicationPackageComponent"])
    {
        return [self orderArrayForFHIRMedicationPackageComponent];
    }
    else if([className isEqualToString:@"FHIRMedicationProductIngredientComponent"])
    {
        return [self orderArrayForFHIRMedicationProductIngredientComponent];
    }
    else if([className isEqualToString:@"FHIRMedicationProductComponent"])
    {
        return [self orderArrayForFHIRMedicationProductComponent];
    }
    else if([className isEqualToString:@"FHIRMedicationAdministration"])
    {
        return [self orderArrayForFHIRMedicationAdministration];
    }
    else if([className isEqualToString:@"FHIRMedicationAdministrationDosageComponent"])
    {
        return [self orderArrayForFHIRMedicationAdministrationDosageComponent];
    }
    else if([className isEqualToString:@"FHIRMedicationDispense"])
    {
        return [self orderArrayForFHIRMedicationDispense];
    }
    else if([className isEqualToString:@"FHIRMedicationDispenseDispenseDosageComponent"])
    {
        return [self orderArrayForFHIRMedicationDispenseDispenseDosageComponent];
    }
    else if([className isEqualToString:@"FHIRMedicationDispenseSubstitutionComponent"])
    {
        return [self orderArrayForFHIRMedicationDispenseSubstitutionComponent];
    }
    else if([className isEqualToString:@"FHIRMedicationDispenseDispenseComponent"])
    {
        return [self orderArrayForFHIRMedicationDispenseDispenseComponent];
    }
    else if([className isEqualToString:@"FHIRMedicationPrescription"])
    {
        return [self orderArrayForFHIRMedicationPrescription];
    }
    else if([className isEqualToString:@"FHIRMedicationPrescriptionDosageInstructionComponent"])
    {
        return [self orderArrayForFHIRMedicationPrescriptionDosageInstructionComponent];
    }
    else if([className isEqualToString:@"FHIRMedicationPrescriptionSubstitutionComponent"])
    {
        return [self orderArrayForFHIRMedicationPrescriptionSubstitutionComponent];
    }
    else if([className isEqualToString:@"FHIRMedicationPrescriptionDispenseComponent"])
    {
        return [self orderArrayForFHIRMedicationPrescriptionDispenseComponent];
    }
    else if([className isEqualToString:@"FHIRMedicationStatement"])
    {
        return [self orderArrayForFHIRMedicationStatement];
    }
    else if([className isEqualToString:@"FHIRMedicationStatementDosageComponent"])
    {
        return [self orderArrayForFHIRMedicationStatementDosageComponent];
    }
    else if([className isEqualToString:@"FHIRMessageHeader"])
    {
        return [self orderArrayForFHIRMessageHeader];
    }
    else if([className isEqualToString:@"FHIRMessageDestinationComponent"])
    {
        return [self orderArrayForFHIRMessageDestinationComponent];
    }
    else if([className isEqualToString:@"FHIRMessageSourceComponent"])
    {
        return [self orderArrayForFHIRMessageSourceComponent];
    }
    else if([className isEqualToString:@"FHIRMessageHeaderResponseComponent"])
    {
        return [self orderArrayForFHIRMessageHeaderResponseComponent];
    }
    else if([className isEqualToString:@"FHIRNamingSystem"])
    {
        return [self orderArrayForFHIRNamingSystem];
    }
    else if([className isEqualToString:@"FHIRNamingSystemContactComponent"])
    {
        return [self orderArrayForFHIRNamingSystemContactComponent];
    }
    else if([className isEqualToString:@"FHIRNamingSystemUniqueIdComponent"])
    {
        return [self orderArrayForFHIRNamingSystemUniqueIdComponent];
    }
    else if([className isEqualToString:@"FHIRNutritionOrder"])
    {
        return [self orderArrayForFHIRNutritionOrder];
    }
    else if([className isEqualToString:@"FHIRNutritionOrderItemSupplementComponent"])
    {
        return [self orderArrayForFHIRNutritionOrderItemSupplementComponent];
    }
    else if([className isEqualToString:@"FHIRNutritionOrderItemOralDietTextureComponent"])
    {
        return [self orderArrayForFHIRNutritionOrderItemOralDietTextureComponent];
    }
    else if([className isEqualToString:@"FHIRNutritionOrderItemComponent"])
    {
        return [self orderArrayForFHIRNutritionOrderItemComponent];
    }
    else if([className isEqualToString:@"FHIRNutritionOrderItemEnteralFormulaComponent"])
    {
        return [self orderArrayForFHIRNutritionOrderItemEnteralFormulaComponent];
    }
    else if([className isEqualToString:@"FHIRNutritionOrderItemOralDietComponent"])
    {
        return [self orderArrayForFHIRNutritionOrderItemOralDietComponent];
    }
    else if([className isEqualToString:@"FHIRNutritionOrderItemOralDietNutrientsComponent"])
    {
        return [self orderArrayForFHIRNutritionOrderItemOralDietNutrientsComponent];
    }
    else if([className isEqualToString:@"FHIRObservation"])
    {
        return [self orderArrayForFHIRObservation];
    }
    else if([className isEqualToString:@"FHIRObservationReferenceRangeComponent"])
    {
        return [self orderArrayForFHIRObservationReferenceRangeComponent];
    }
    else if([className isEqualToString:@"FHIRObservationRelatedComponent"])
    {
        return [self orderArrayForFHIRObservationRelatedComponent];
    }
    else if([className isEqualToString:@"FHIROperationDefinition"])
    {
        return [self orderArrayForFHIROperationDefinition];
    }
    else if([className isEqualToString:@"FHIROperationDefinitionParameterPartComponent"])
    {
        return [self orderArrayForFHIROperationDefinitionParameterPartComponent];
    }
    else if([className isEqualToString:@"FHIROperationDefinitionParameterComponent"])
    {
        return [self orderArrayForFHIROperationDefinitionParameterComponent];
    }
    else if([className isEqualToString:@"FHIROperationOutcome"])
    {
        return [self orderArrayForFHIROperationOutcome];
    }
    else if([className isEqualToString:@"FHIROperationOutcomeIssueComponent"])
    {
        return [self orderArrayForFHIROperationOutcomeIssueComponent];
    }
    else if([className isEqualToString:@"FHIROralHealthClaim"])
    {
        return [self orderArrayForFHIROralHealthClaim];
    }
    else if([className isEqualToString:@"FHIRItemsComponent"])
    {
        return [self orderArrayForFHIRItemsComponent];
    }
    else if([className isEqualToString:@"FHIROrthodonticPlanComponent"])
    {
        return [self orderArrayForFHIROrthodonticPlanComponent];
    }
    else if([className isEqualToString:@"FHIRDetailComponent"])
    {
        return [self orderArrayForFHIRDetailComponent];
    }
    else if([className isEqualToString:@"FHIRCoverageComponent"])
    {
        return [self orderArrayForFHIRCoverageComponent];
    }
    else if([className isEqualToString:@"FHIRPayeeComponent"])
    {
        return [self orderArrayForFHIRPayeeComponent];
    }
    else if([className isEqualToString:@"FHIRDiagnosisComponent"])
    {
        return [self orderArrayForFHIRDiagnosisComponent];
    }
    else if([className isEqualToString:@"FHIRProsthesisComponent"])
    {
        return [self orderArrayForFHIRProsthesisComponent];
    }
    else if([className isEqualToString:@"FHIRSubDetailComponent"])
    {
        return [self orderArrayForFHIRSubDetailComponent];
    }
    else if([className isEqualToString:@"FHIRMissingTeethComponent"])
    {
        return [self orderArrayForFHIRMissingTeethComponent];
    }
    else if([className isEqualToString:@"FHIROrder"])
    {
        return [self orderArrayForFHIROrder];
    }
    else if([className isEqualToString:@"FHIROrderWhenComponent"])
    {
        return [self orderArrayForFHIROrderWhenComponent];
    }
    else if([className isEqualToString:@"FHIROrderResponse"])
    {
        return [self orderArrayForFHIROrderResponse];
    }
    else if([className isEqualToString:@"FHIROrganization"])
    {
        return [self orderArrayForFHIROrganization];
    }
    else if([className isEqualToString:@"FHIROrganizationContactComponent"])
    {
        return [self orderArrayForFHIROrganizationContactComponent];
    }
    else if([className isEqualToString:@"FHIROther"])
    {
        return [self orderArrayForFHIROther];
    }
    else if([className isEqualToString:@"FHIRPatient"])
    {
        return [self orderArrayForFHIRPatient];
    }
    else if([className isEqualToString:@"FHIRContactComponent"])
    {
        return [self orderArrayForFHIRContactComponent];
    }
    else if([className isEqualToString:@"FHIRAnimalComponent"])
    {
        return [self orderArrayForFHIRAnimalComponent];
    }
    else if([className isEqualToString:@"FHIRPatientLinkComponent"])
    {
        return [self orderArrayForFHIRPatientLinkComponent];
    }
    else if([className isEqualToString:@"FHIRPaymentNotice"])
    {
        return [self orderArrayForFHIRPaymentNotice];
    }
    else if([className isEqualToString:@"FHIRPaymentReconciliation"])
    {
        return [self orderArrayForFHIRPaymentReconciliation];
    }
    else if([className isEqualToString:@"FHIRNotesComponent"])
    {
        return [self orderArrayForFHIRNotesComponent];
    }
    else if([className isEqualToString:@"FHIRDetailsComponent"])
    {
        return [self orderArrayForFHIRDetailsComponent];
    }
    else if([className isEqualToString:@"FHIRPendedRequest"])
    {
        return [self orderArrayForFHIRPendedRequest];
    }
    else if([className isEqualToString:@"FHIRPerson"])
    {
        return [self orderArrayForFHIRPerson];
    }
    else if([className isEqualToString:@"FHIRPersonLinkComponent"])
    {
        return [self orderArrayForFHIRPersonLinkComponent];
    }
    else if([className isEqualToString:@"FHIRPharmacyClaim"])
    {
        return [self orderArrayForFHIRPharmacyClaim];
    }
    else if([className isEqualToString:@"FHIRItemsComponent"])
    {
        return [self orderArrayForFHIRItemsComponent];
    }
    else if([className isEqualToString:@"FHIRDetailComponent"])
    {
        return [self orderArrayForFHIRDetailComponent];
    }
    else if([className isEqualToString:@"FHIRCoverageComponent"])
    {
        return [self orderArrayForFHIRCoverageComponent];
    }
    else if([className isEqualToString:@"FHIRPayeeComponent"])
    {
        return [self orderArrayForFHIRPayeeComponent];
    }
    else if([className isEqualToString:@"FHIRDiagnosisComponent"])
    {
        return [self orderArrayForFHIRDiagnosisComponent];
    }
    else if([className isEqualToString:@"FHIRSubDetailComponent"])
    {
        return [self orderArrayForFHIRSubDetailComponent];
    }
    else if([className isEqualToString:@"FHIRPractitioner"])
    {
        return [self orderArrayForFHIRPractitioner];
    }
    else if([className isEqualToString:@"FHIRPractitionerQualificationComponent"])
    {
        return [self orderArrayForFHIRPractitionerQualificationComponent];
    }
    else if([className isEqualToString:@"FHIRProcedure"])
    {
        return [self orderArrayForFHIRProcedure];
    }
    else if([className isEqualToString:@"FHIRProcedureRelatedItemComponent"])
    {
        return [self orderArrayForFHIRProcedureRelatedItemComponent];
    }
    else if([className isEqualToString:@"FHIRProcedurePerformerComponent"])
    {
        return [self orderArrayForFHIRProcedurePerformerComponent];
    }
    else if([className isEqualToString:@"FHIRProcedureRequest"])
    {
        return [self orderArrayForFHIRProcedureRequest];
    }
    else if([className isEqualToString:@"FHIRProfessionalClaim"])
    {
        return [self orderArrayForFHIRProfessionalClaim];
    }
    else if([className isEqualToString:@"FHIRItemsComponent"])
    {
        return [self orderArrayForFHIRItemsComponent];
    }
    else if([className isEqualToString:@"FHIRDetailComponent"])
    {
        return [self orderArrayForFHIRDetailComponent];
    }
    else if([className isEqualToString:@"FHIRCoverageComponent"])
    {
        return [self orderArrayForFHIRCoverageComponent];
    }
    else if([className isEqualToString:@"FHIRPayeeComponent"])
    {
        return [self orderArrayForFHIRPayeeComponent];
    }
    else if([className isEqualToString:@"FHIRDiagnosisComponent"])
    {
        return [self orderArrayForFHIRDiagnosisComponent];
    }
    else if([className isEqualToString:@"FHIRSubDetailComponent"])
    {
        return [self orderArrayForFHIRSubDetailComponent];
    }
    else if([className isEqualToString:@"FHIRProfile"])
    {
        return [self orderArrayForFHIRProfile];
    }
    else if([className isEqualToString:@"FHIRConstraintComponent"])
    {
        return [self orderArrayForFHIRConstraintComponent];
    }
    else if([className isEqualToString:@"FHIRProfileMappingComponent"])
    {
        return [self orderArrayForFHIRProfileMappingComponent];
    }
    else if([className isEqualToString:@"FHIRProvenance"])
    {
        return [self orderArrayForFHIRProvenance];
    }
    else if([className isEqualToString:@"FHIRProvenanceAgentComponent"])
    {
        return [self orderArrayForFHIRProvenanceAgentComponent];
    }
    else if([className isEqualToString:@"FHIRProvenanceEntityComponent"])
    {
        return [self orderArrayForFHIRProvenanceEntityComponent];
    }
    else if([className isEqualToString:@"FHIRQuestionnaire"])
    {
        return [self orderArrayForFHIRQuestionnaire];
    }
    else if([className isEqualToString:@"FHIRQuestionComponent"])
    {
        return [self orderArrayForFHIRQuestionComponent];
    }
    else if([className isEqualToString:@"FHIRGroupComponent"])
    {
        return [self orderArrayForFHIRGroupComponent];
    }
    else if([className isEqualToString:@"FHIRQuestionnaireAnswers"])
    {
        return [self orderArrayForFHIRQuestionnaireAnswers];
    }
    else if([className isEqualToString:@"FHIRQuestionAnswerComponent"])
    {
        return [self orderArrayForFHIRQuestionAnswerComponent];
    }
    else if([className isEqualToString:@"FHIRQuestionComponent"])
    {
        return [self orderArrayForFHIRQuestionComponent];
    }
    else if([className isEqualToString:@"FHIRGroupComponent"])
    {
        return [self orderArrayForFHIRGroupComponent];
    }
    else if([className isEqualToString:@"FHIRReadjudicate"])
    {
        return [self orderArrayForFHIRReadjudicate];
    }
    else if([className isEqualToString:@"FHIRItemsComponent"])
    {
        return [self orderArrayForFHIRItemsComponent];
    }
    else if([className isEqualToString:@"FHIRReferralRequest"])
    {
        return [self orderArrayForFHIRReferralRequest];
    }
    else if([className isEqualToString:@"FHIRRelatedPerson"])
    {
        return [self orderArrayForFHIRRelatedPerson];
    }
    else if([className isEqualToString:@"FHIRReversal"])
    {
        return [self orderArrayForFHIRReversal];
    }
    else if([className isEqualToString:@"FHIRPayeeComponent"])
    {
        return [self orderArrayForFHIRPayeeComponent];
    }
    else if([className isEqualToString:@"FHIRReversalCoverageComponent"])
    {
        return [self orderArrayForFHIRReversalCoverageComponent];
    }
    else if([className isEqualToString:@"FHIRRiskAssessment"])
    {
        return [self orderArrayForFHIRRiskAssessment];
    }
    else if([className isEqualToString:@"FHIRRiskAssessmentPredictionComponent"])
    {
        return [self orderArrayForFHIRRiskAssessmentPredictionComponent];
    }
    else if([className isEqualToString:@"FHIRSchedule"])
    {
        return [self orderArrayForFHIRSchedule];
    }
    else if([className isEqualToString:@"FHIRSearchParameter"])
    {
        return [self orderArrayForFHIRSearchParameter];
    }
    else if([className isEqualToString:@"FHIRSecurityEvent"])
    {
        return [self orderArrayForFHIRSecurityEvent];
    }
    else if([className isEqualToString:@"FHIRSecurityEventObjectDetailComponent"])
    {
        return [self orderArrayForFHIRSecurityEventObjectDetailComponent];
    }
    else if([className isEqualToString:@"FHIRSecurityEventObjectComponent"])
    {
        return [self orderArrayForFHIRSecurityEventObjectComponent];
    }
    else if([className isEqualToString:@"FHIRSecurityEventSourceComponent"])
    {
        return [self orderArrayForFHIRSecurityEventSourceComponent];
    }
    else if([className isEqualToString:@"FHIRSecurityEventEventComponent"])
    {
        return [self orderArrayForFHIRSecurityEventEventComponent];
    }
    else if([className isEqualToString:@"FHIRSecurityEventParticipantNetworkComponent"])
    {
        return [self orderArrayForFHIRSecurityEventParticipantNetworkComponent];
    }
    else if([className isEqualToString:@"FHIRSecurityEventParticipantComponent"])
    {
        return [self orderArrayForFHIRSecurityEventParticipantComponent];
    }
    else if([className isEqualToString:@"FHIRSlot"])
    {
        return [self orderArrayForFHIRSlot];
    }
    else if([className isEqualToString:@"FHIRSpecimen"])
    {
        return [self orderArrayForFHIRSpecimen];
    }
    else if([className isEqualToString:@"FHIRSpecimenCollectionComponent"])
    {
        return [self orderArrayForFHIRSpecimenCollectionComponent];
    }
    else if([className isEqualToString:@"FHIRSpecimenSourceComponent"])
    {
        return [self orderArrayForFHIRSpecimenSourceComponent];
    }
    else if([className isEqualToString:@"FHIRSpecimenTreatmentComponent"])
    {
        return [self orderArrayForFHIRSpecimenTreatmentComponent];
    }
    else if([className isEqualToString:@"FHIRSpecimenContainerComponent"])
    {
        return [self orderArrayForFHIRSpecimenContainerComponent];
    }
    else if([className isEqualToString:@"FHIRStatusRequest"])
    {
        return [self orderArrayForFHIRStatusRequest];
    }
    else if([className isEqualToString:@"FHIRStatusResponse"])
    {
        return [self orderArrayForFHIRStatusResponse];
    }
    else if([className isEqualToString:@"FHIRStatusResponseNotesComponent"])
    {
        return [self orderArrayForFHIRStatusResponseNotesComponent];
    }
    else if([className isEqualToString:@"FHIRSubscription"])
    {
        return [self orderArrayForFHIRSubscription];
    }
    else if([className isEqualToString:@"FHIRSubscriptionChannelComponent"])
    {
        return [self orderArrayForFHIRSubscriptionChannelComponent];
    }
    else if([className isEqualToString:@"FHIRSubscriptionTagComponent"])
    {
        return [self orderArrayForFHIRSubscriptionTagComponent];
    }
    else if([className isEqualToString:@"FHIRSubstance"])
    {
        return [self orderArrayForFHIRSubstance];
    }
    else if([className isEqualToString:@"FHIRSubstanceIngredientComponent"])
    {
        return [self orderArrayForFHIRSubstanceIngredientComponent];
    }
    else if([className isEqualToString:@"FHIRSubstanceInstanceComponent"])
    {
        return [self orderArrayForFHIRSubstanceInstanceComponent];
    }
    else if([className isEqualToString:@"FHIRSupply"])
    {
        return [self orderArrayForFHIRSupply];
    }
    else if([className isEqualToString:@"FHIRSupplyDispenseComponent"])
    {
        return [self orderArrayForFHIRSupplyDispenseComponent];
    }
    else if([className isEqualToString:@"FHIRSupportingDocumentation"])
    {
        return [self orderArrayForFHIRSupportingDocumentation];
    }
    else if([className isEqualToString:@"FHIRSupportingDocumentationDetailComponent"])
    {
        return [self orderArrayForFHIRSupportingDocumentationDetailComponent];
    }
    else if([className isEqualToString:@"FHIRValueSet"])
    {
        return [self orderArrayForFHIRValueSet];
    }
    else if([className isEqualToString:@"FHIRValueSetDefineComponent"])
    {
        return [self orderArrayForFHIRValueSetDefineComponent];
    }
    else if([className isEqualToString:@"FHIRValueSetExpansionContainsComponent"])
    {
        return [self orderArrayForFHIRValueSetExpansionContainsComponent];
    }
    else if([className isEqualToString:@"FHIRConceptDefinitionDesignationComponent"])
    {
        return [self orderArrayForFHIRConceptDefinitionDesignationComponent];
    }
    else if([className isEqualToString:@"FHIRConceptDefinitionComponent"])
    {
        return [self orderArrayForFHIRConceptDefinitionComponent];
    }
    else if([className isEqualToString:@"FHIRConceptSetComponent"])
    {
        return [self orderArrayForFHIRConceptSetComponent];
    }
    else if([className isEqualToString:@"FHIRConceptReferenceComponent"])
    {
        return [self orderArrayForFHIRConceptReferenceComponent];
    }
    else if([className isEqualToString:@"FHIRConceptSetFilterComponent"])
    {
        return [self orderArrayForFHIRConceptSetFilterComponent];
    }
    else if([className isEqualToString:@"FHIRValueSetComposeComponent"])
    {
        return [self orderArrayForFHIRValueSetComposeComponent];
    }
    else if([className isEqualToString:@"FHIRValueSetExpansionComponent"])
    {
        return [self orderArrayForFHIRValueSetExpansionComponent];
    }
    else if([className isEqualToString:@"FHIRVisionClaim"])
    {
        return [self orderArrayForFHIRVisionClaim];
    }
    else if([className isEqualToString:@"FHIRItemsComponent"])
    {
        return [self orderArrayForFHIRItemsComponent];
    }
    else if([className isEqualToString:@"FHIRDetailComponent"])
    {
        return [self orderArrayForFHIRDetailComponent];
    }
    else if([className isEqualToString:@"FHIRCoverageComponent"])
    {
        return [self orderArrayForFHIRCoverageComponent];
    }
    else if([className isEqualToString:@"FHIRPayeeComponent"])
    {
        return [self orderArrayForFHIRPayeeComponent];
    }
    else if([className isEqualToString:@"FHIRDiagnosisComponent"])
    {
        return [self orderArrayForFHIRDiagnosisComponent];
    }
    else if([className isEqualToString:@"FHIRSubDetailComponent"])
    {
        return [self orderArrayForFHIRSubDetailComponent];
    }
    else if([className isEqualToString:@"FHIRVisionPrescription"])
    {
        return [self orderArrayForFHIRVisionPrescription];
    }
    else if([className isEqualToString:@"FHIRVisionPrescriptionDispenseComponent"])
    {
        return [self orderArrayForFHIRVisionPrescriptionDispenseComponent];
    }
    else
        @throw [NSException exceptionWithName:@"Unknown Type" reason:[NSString stringWithFormat:@"Encountered unknown type %@", className] userInfo:nil];
}
@end
