﻿/*
  Copyright (c) 2011+, HL7, Inc.
  All rights reserved.
  
  Redistribution and use in source and binary forms, with or without modification, 
  are permitted provided that the following conditions are met:
  
   * Redistributions of source code must retain the above copyright notice, this 
     list of conditions and the following disclaimer.
   * Redistributions in binary form must reproduce the above copyright notice, 
     this list of conditions and the following disclaimer in the documentation 
     and/or other materials provided with the distribution.
   * Neither the name of HL7 nor the names of its contributors may be used to 
     endorse or promote products derived from this software without specific 
     prior written permission.
  
  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND 
  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
  WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
  IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
  INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT 
  NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR 
  PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
  WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
  POSSIBILITY OF SUCH DAMAGE.
  

 * Generated on Tue, Dec 30, 2014 10:55+0000 for FHIR v0.4.0
 */
/*
 * Insurance or medical plan
 *
 * [FhirReference("Coverage")]
 * [Serializable]
 */

#import "FHIRDomainResource.h"


@class FHIRReference;
@class FHIRPeriod;
@class FHIRCoding;
@class FHIRIdentifier;
@class FHIRString;
@class FHIRInteger;

@interface FHIRCoverage : FHIRDomainResource

/*
 * An identifier for the plan issuer
 */
@property (nonatomic, strong) FHIRReference *issuer;

/*
 * Coverage start and end dates
 */
@property (nonatomic, strong) FHIRPeriod *period;

/*
 * Type of coverage
 */
@property (nonatomic, strong) FHIRCoding *type;

/*
 * The primary coverage ID
 */
@property (nonatomic, strong) NSArray/*<Identifier>*/ *identifier;

/*
 * An identifier for the group
 */
@property (nonatomic, strong) FHIRString *groupElement;

@property (nonatomic, strong) NSString *group;

/*
 * An identifier for the plan
 */
@property (nonatomic, strong) FHIRString *planElement;

@property (nonatomic, strong) NSString *plan;

/*
 * An identifier for the subsection of the plan
 */
@property (nonatomic, strong) FHIRString *subplanElement;

@property (nonatomic, strong) NSString *subplan;

/*
 * The dependent number
 */
@property (nonatomic, strong) FHIRInteger *dependentElement;

@property (nonatomic, strong) NSNumber *dependent;

/*
 * The plan instance or sequence counter
 */
@property (nonatomic, strong) FHIRInteger *sequenceElement;

@property (nonatomic, strong) NSNumber *sequence;

/*
 * Plan holder information
 */
@property (nonatomic, strong) FHIRReference *subscriber;

/*
 * Insurer network
 */
@property (nonatomic, strong) FHIRIdentifier *network;

/*
 * Contract details
 */
@property (nonatomic, strong) NSArray/*<Reference>*/ *contract;

- (FHIRErrorList *)validate;

@end
