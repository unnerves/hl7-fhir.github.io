﻿/*
  Copyright (c) 2011+, HL7, Inc.
  All rights reserved.
  
  Redistribution and use in source and binary forms, with or without modification, 
  are permitted provided that the following conditions are met:
  
   * Redistributions of source code must retain the above copyright notice, this 
     list of conditions and the following disclaimer.
   * Redistributions in binary form must reproduce the above copyright notice, 
     this list of conditions and the following disclaimer in the documentation 
     and/or other materials provided with the distribution.
   * Neither the name of HL7 nor the names of its contributors may be used to 
     endorse or promote products derived from this software without specific 
     prior written permission.
  
  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND 
  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
  WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
  IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
  INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT 
  NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR 
  PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
  WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
  POSSIBILITY OF SUCH DAMAGE.
  

 * Generated on Tue, Dec 30, 2014 10:55+0000 for FHIR v0.4.0
 */
/*
 * null
 *
 * [FhirComposite("VisionPrescriptionDispenseComponent")]
 * [Serializable]
 */

#import "FHIRBackboneElement.h"

#import "FHIRVisionPrescription.h"

@class FHIRCoding;
@class FHIRCode;
@class FHIRDecimal;
@class FHIRInteger;
@class FHIRQuantity;
@class FHIRString;

@interface FHIRVisionPrescriptionDispenseComponent : FHIRBackboneElement

/*
 * Product to be supplied
 */
@property (nonatomic, strong) FHIRCoding *product;

/*
 * right | left
 */
@property (nonatomic, strong) FHIRCode/*<code>*/ *eyeElement;

@property (nonatomic) kVisionEyes eye;

/*
 * Lens sphere
 */
@property (nonatomic, strong) FHIRDecimal *sphereElement;

@property (nonatomic, strong) NSDecimalNumber *sphere;

/*
 * Lens cylinder
 */
@property (nonatomic, strong) FHIRDecimal *cylinderElement;

@property (nonatomic, strong) NSDecimalNumber *cylinder;

/*
 * Lens axis
 */
@property (nonatomic, strong) FHIRInteger *axisElement;

@property (nonatomic, strong) NSNumber *axis;

/*
 * Lens prism
 */
@property (nonatomic, strong) FHIRDecimal *prismElement;

@property (nonatomic, strong) NSDecimalNumber *prism;

/*
 * up | down | in | out
 */
@property (nonatomic, strong) FHIRCode/*<code>*/ *base_Element;

@property (nonatomic) kVisionBase base_;

/*
 * Lens add
 */
@property (nonatomic, strong) FHIRDecimal *addElement;

@property (nonatomic, strong) NSDecimalNumber *add;

/*
 * Contact Lens power
 */
@property (nonatomic, strong) FHIRDecimal *powerElement;

@property (nonatomic, strong) NSDecimalNumber *power;

/*
 * Contact lens back curvature
 */
@property (nonatomic, strong) FHIRDecimal *backCurveElement;

@property (nonatomic, strong) NSDecimalNumber *backCurve;

/*
 * Contact Lens diameter
 */
@property (nonatomic, strong) FHIRDecimal *diameterElement;

@property (nonatomic, strong) NSDecimalNumber *diameter;

/*
 * Lens wear duration
 */
@property (nonatomic, strong) FHIRQuantity *duration;

/*
 * Lens add
 */
@property (nonatomic, strong) FHIRString *colorElement;

@property (nonatomic, strong) NSString *color;

/*
 * Lens add
 */
@property (nonatomic, strong) FHIRString *brandElement;

@property (nonatomic, strong) NSString *brand;

/*
 * Notes for coatings
 */
@property (nonatomic, strong) FHIRString *notesElement;

@property (nonatomic, strong) NSString *notes;

- (FHIRErrorList *)validate;

@end
