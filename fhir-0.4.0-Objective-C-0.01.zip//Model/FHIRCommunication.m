﻿/*
  Copyright (c) 2011+, HL7, Inc.
  All rights reserved.
  
  Redistribution and use in source and binary forms, with or without modification, 
  are permitted provided that the following conditions are met:
  
   * Redistributions of source code must retain the above copyright notice, this 
     list of conditions and the following disclaimer.
   * Redistributions in binary form must reproduce the above copyright notice, 
     this list of conditions and the following disclaimer in the documentation 
     and/or other materials provided with the distribution.
   * Neither the name of HL7 nor the names of its contributors may be used to 
     endorse or promote products derived from this software without specific 
     prior written permission.
  
  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND 
  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
  WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
  IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
  INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT 
  NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR 
  PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
  WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
  POSSIBILITY OF SUCH DAMAGE.
  

 * Generated on Tue, Dec 30, 2014 10:55+0000 for FHIR v0.4.0
 */
/*
 * Communication
 */
#import "FHIRCommunication.h"

#import "FHIRIdentifier.h"
#import "FHIRCodeableConcept.h"
#import "FHIRReference.h"
#import "FHIRCommunicationPayloadComponent.h"
#import "FHIRCode.h"
#import "FHIRDateTime.h"

#import "FHIRErrorList.h"

@implementation FHIRCommunication

- (kCommunicationStatus )status
{
    return [FHIREnumHelper parseString:[self.statusElement value] enumType:kEnumTypeCommunicationStatus];
}

- (void )setStatus:(kCommunicationStatus )status
{
    [self setStatusElement:[[FHIRCode/*<code>*/ alloc] initWithValue:[FHIREnumHelper enumToString:status enumType:kEnumTypeCommunicationStatus]]];
}


- (NSString *)sent
{
    if(self.sentElement)
    {
        return [self.sentElement value];
    }
    return nil;
}

- (void )setSent:(NSString *)sent
{
    if(sent)
    {
        [self setSentElement:[[FHIRDateTime alloc] initWithValue:sent]];
    }
    else
    {
        [self setSentElement:nil];
    }
}


- (NSString *)received
{
    if(self.receivedElement)
    {
        return [self.receivedElement value];
    }
    return nil;
}

- (void )setReceived:(NSString *)received
{
    if(received)
    {
        [self setReceivedElement:[[FHIRDateTime alloc] initWithValue:received]];
    }
    else
    {
        [self setReceivedElement:nil];
    }
}


- (FHIRErrorList *)validate
{
    FHIRErrorList *result = [[FHIRErrorList alloc] init];
    
    [result addValidation:[super validate]];
    
    if(self.identifier != nil )
        for(FHIRIdentifier *elem in self.identifier)
            [result addValidationRange:[elem validate]];
    if(self.category != nil )
        [result addValidationRange:[self.category validate]];
    if(self.sender != nil )
        [result addValidationRange:[self.sender validate]];
    if(self.recipient != nil )
        for(FHIRReference *elem in self.recipient)
            [result addValidationRange:[elem validate]];
    if(self.payload != nil )
        for(FHIRCommunicationPayloadComponent *elem in self.payload)
            [result addValidationRange:[elem validate]];
    if(self.medium != nil )
        for(FHIRCodeableConcept *elem in self.medium)
            [result addValidationRange:[elem validate]];
    if(self.statusElement != nil )
        [result addValidationRange:[self.statusElement validate]];
    if(self.encounter != nil )
        [result addValidationRange:[self.encounter validate]];
    if(self.sentElement != nil )
        [result addValidationRange:[self.sentElement validate]];
    if(self.receivedElement != nil )
        [result addValidationRange:[self.receivedElement validate]];
    if(self.reason != nil )
        for(FHIRCodeableConcept *elem in self.reason)
            [result addValidationRange:[elem validate]];
    if(self.subject != nil )
        [result addValidationRange:[self.subject validate]];
    
    return result;
}

@end
