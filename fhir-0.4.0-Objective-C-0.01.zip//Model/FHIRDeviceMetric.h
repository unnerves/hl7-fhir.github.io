﻿/*
  Copyright (c) 2011+, HL7, Inc.
  All rights reserved.
  
  Redistribution and use in source and binary forms, with or without modification, 
  are permitted provided that the following conditions are met:
  
   * Redistributions of source code must retain the above copyright notice, this 
     list of conditions and the following disclaimer.
   * Redistributions in binary form must reproduce the above copyright notice, 
     this list of conditions and the following disclaimer in the documentation 
     and/or other materials provided with the distribution.
   * Neither the name of HL7 nor the names of its contributors may be used to 
     endorse or promote products derived from this software without specific 
     prior written permission.
  
  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND 
  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
  WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
  IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
  INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT 
  NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR 
  PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
  WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
  POSSIBILITY OF SUCH DAMAGE.
  

 * Generated on Tue, Dec 30, 2014 10:55+0000 for FHIR v0.4.0
 */
/*
 * Measurement, calculation or setting capability of a medical device
 *
 * [FhirReference("DeviceMetric")]
 * [Serializable]
 */

#import "FHIRBaseResource.h"


@class FHIRCodeableConcept;
@class FHIRIdentifier;
@class FHIRReference;
@class FHIRCode;
@class FHIRTiming;
@class FHIRDeviceMetricCalibrationInfoComponent;

@interface FHIRDeviceMetric : FHIRBaseResource

/*
 * Describes the state of a metric calibration
 */
typedef enum 
{
    kDeviceMetricCalibrationStateNotCalibrated, // The metric has not been calibrated.
    kDeviceMetricCalibrationStateCalibrationRequired, // The metric needs to be calibrated.
    kDeviceMetricCalibrationStateCalibrated, // The metric has been calibrated.
    kDeviceMetricCalibrationStateUnspecified, // The state of calibration of this metric is unspecified.
} kDeviceMetricCalibrationState;

/*
 * Describes the type of a metric calibration
 */
typedef enum 
{
    kDeviceMetricCalibrationTypeUnspecified, // TODO.
    kDeviceMetricCalibrationTypeOffset, // TODO.
    kDeviceMetricCalibrationTypeGain, // TODO.
    kDeviceMetricCalibrationTypeTwoPoint, // TODO.
} kDeviceMetricCalibrationType;

/*
 * Describes the operational status of the DeviceMetric
 */
typedef enum 
{
    kDeviceMetricOperationalStateOn, // The DeviceMetric is operating and will generate DeviceObservations.
    kDeviceMetricOperationalStateOff, // The DeviceMetric is not operating.
    kDeviceMetricOperationalStateStandby, // The DeviceMetric is operating, but will not generate any DeviceObservations.
} kDeviceMetricOperationalState;

/*
 * Describes the category of the metric
 */
typedef enum 
{
    kDeviceMetricCategoryMeasurement, // DeviceObservations generated for this DeviceMetric are measured.
    kDeviceMetricCategorySetting, // DeviceObservations generated for this DeviceMetric is a setting that will influence the behavior of the Device.
    kDeviceMetricCategoryCalculation, // DeviceObservations generated for this DeviceMetric are calculated.
    kDeviceMetricCategoryUnspecified, // The category of this DeviceMetric is unspecified.
} kDeviceMetricCategory;

/*
 * Type of metric
 */
@property (nonatomic, strong) FHIRCodeableConcept *type;

/*
 * Unique identifier of this DeviceMetric
 */
@property (nonatomic, strong) FHIRIdentifier *identifier;

/*
 * Unit of metric
 */
@property (nonatomic, strong) FHIRCodeableConcept *unit;

/*
 * Describes the link to the source Device
 */
@property (nonatomic, strong) FHIRReference *source;

/*
 * Describes the link to the parent DeviceComponent
 */
@property (nonatomic, strong) FHIRReference *parent;

/*
 * on | off | standby
 */
@property (nonatomic, strong) FHIRCode/*<code>*/ *operationalStateElement;

@property (nonatomic) kDeviceMetricOperationalState operationalState;

/*
 * Describes the physical principle of the measurement
 */
@property (nonatomic, strong) FHIRIdentifier *measurementMode;

/*
 * Describes the typical color of representation
 */
@property (nonatomic, strong) FHIRIdentifier *color;

/*
 * measurement | setting | calculation | unspecified
 */
@property (nonatomic, strong) FHIRCode/*<code>*/ *categoryElement;

@property (nonatomic) kDeviceMetricCategory category;

/*
 * Describes the measurement repetition time
 */
@property (nonatomic, strong) FHIRTiming *measurementPeriod;

/*
 * Describes the calibrations that have been performed or that are required to be performed
 */
@property (nonatomic, strong) NSArray/*<DeviceMetricCalibrationInfoComponent>*/ *calibrationInfo;

- (FHIRErrorList *)validate;

@end
