﻿/*
  Copyright (c) 2011+, HL7, Inc.
  All rights reserved.
  
  Redistribution and use in source and binary forms, with or without modification, 
  are permitted provided that the following conditions are met:
  
   * Redistributions of source code must retain the above copyright notice, this 
     list of conditions and the following disclaimer.
   * Redistributions in binary form must reproduce the above copyright notice, 
     this list of conditions and the following disclaimer in the documentation 
     and/or other materials provided with the distribution.
   * Neither the name of HL7 nor the names of its contributors may be used to 
     endorse or promote products derived from this software without specific 
     prior written permission.
  
  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND 
  ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
  WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
  IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, 
  INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT 
  NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR 
  PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, 
  WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE 
  POSSIBILITY OF SUCH DAMAGE.
  

 * Generated on Tue, Dec 30, 2014 10:55+0000 for FHIR v0.4.0
 */
/*
 * Procedure Request
 */
#import "FHIRProcedureRequest.h"

#import "FHIRIdentifier.h"
#import "FHIRReference.h"
#import "FHIRCodeableConcept.h"
#import "FHIRElement.h"
#import "FHIRCode.h"
#import "FHIRString.h"
#import "FHIRDateTime.h"

#import "FHIRErrorList.h"

@implementation FHIRProcedureRequest

- (kProcedureRequestStatus )status
{
    return [FHIREnumHelper parseString:[self.statusElement value] enumType:kEnumTypeProcedureRequestStatus];
}

- (void )setStatus:(kProcedureRequestStatus )status
{
    [self setStatusElement:[[FHIRCode/*<code>*/ alloc] initWithValue:[FHIREnumHelper enumToString:status enumType:kEnumTypeProcedureRequestStatus]]];
}


- (NSArray /*<NSString>*/ *)notes
{
    if(self.notesElement)
    {
        NSMutableArray *array = [NSMutableArray new];
        for(FHIRString *elem in self.notesElement)
            [array addObject:[elem value]];
        return [NSArray arrayWithArray:array];
    }
    return nil;
}

- (void )setNotes:(NSArray /*<NSString>*/ *)notes
{
    if(notes)
    {
        NSMutableArray *array = [NSMutableArray new];
        for(NSString *value in notes)
            [array addObject:[[FHIRString alloc] initWithValue:value]];
        [self setNotesElement:[NSArray arrayWithArray:array]];
    }
    else
    {
        [self setNotesElement:nil];
    }
}


- (NSString *)orderedOn
{
    if(self.orderedOnElement)
    {
        return [self.orderedOnElement value];
    }
    return nil;
}

- (void )setOrderedOn:(NSString *)orderedOn
{
    if(orderedOn)
    {
        [self setOrderedOnElement:[[FHIRDateTime alloc] initWithValue:orderedOn]];
    }
    else
    {
        [self setOrderedOnElement:nil];
    }
}


- (kProcedureRequestPriority )priority
{
    return [FHIREnumHelper parseString:[self.priorityElement value] enumType:kEnumTypeProcedureRequestPriority];
}

- (void )setPriority:(kProcedureRequestPriority )priority
{
    [self setPriorityElement:[[FHIRCode/*<code>*/ alloc] initWithValue:[FHIREnumHelper enumToString:priority enumType:kEnumTypeProcedureRequestPriority]]];
}


- (FHIRErrorList *)validate
{
    FHIRErrorList *result = [[FHIRErrorList alloc] init];
    
    [result addValidation:[super validate]];
    
    if(self.identifier != nil )
        for(FHIRIdentifier *elem in self.identifier)
            [result addValidationRange:[elem validate]];
    if(self.subject != nil )
        [result addValidationRange:[self.subject validate]];
    if(self.type != nil )
        [result addValidationRange:[self.type validate]];
    if(self.bodySite != nil )
        for(FHIRCodeableConcept *elem in self.bodySite)
            [result addValidationRange:[elem validate]];
    if(self.indication != nil )
        for(FHIRCodeableConcept *elem in self.indication)
            [result addValidationRange:[elem validate]];
    if(self.timing != nil )
        [result addValidationRange:[self.timing validate]];
    if(self.encounter != nil )
        [result addValidationRange:[self.encounter validate]];
    if(self.performer != nil )
        [result addValidationRange:[self.performer validate]];
    if(self.statusElement != nil )
        [result addValidationRange:[self.statusElement validate]];
    if(self.notesElement != nil )
        for(FHIRString *elem in self.notesElement)
            [result addValidationRange:[elem validate]];
    if(self.asNeeded != nil )
        [result addValidationRange:[self.asNeeded validate]];
    if(self.orderedOnElement != nil )
        [result addValidationRange:[self.orderedOnElement validate]];
    if(self.orderer != nil )
        [result addValidationRange:[self.orderer validate]];
    if(self.priorityElement != nil )
        [result addValidationRange:[self.priorityElement validate]];
    
    return result;
}

@end
